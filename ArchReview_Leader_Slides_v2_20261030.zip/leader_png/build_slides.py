# -*- coding: utf-8 -*-
"""リーダー向けスライド(1920x1080 PNG)生成スクリプト。HTML+CSS を Playwright(Chromium) で撮影する。"""
import os, sys
from playwright.sync_api import sync_playwright

OUT = os.path.dirname(os.path.abspath(__file__))
HTML_DIR = os.path.join(OUT, "html")
os.makedirs(HTML_DIR, exist_ok=True)

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1920px;height:1080px;background:#fff;word-break:auto-phrase;font-family:"Noto Sans CJK JP","Noto Sans JP","Yu Gothic","Meiryo",sans-serif;color:#1B1B1B;overflow:hidden}
.slide{position:relative;width:1920px;height:1080px;padding:64px 80px 56px 80px}
.msg{font-size:44px;font-weight:700;line-height:1.3;color:#1B1B1B;max-height:115px;overflow:hidden}
.title{font-size:32px;font-weight:700;color:#26890D;margin-top:16px}
.title-only{font-size:44px;font-weight:700;color:#26890D}
.body{position:absolute;left:80px;right:80px;top:290px;height:700px}
.body.up{top:250px;height:740px}
.body.top2{top:190px;height:800px}
.credit{position:absolute;right:80px;bottom:36px;font-size:20px;color:#8A8A8A}
.cards{display:flex;gap:24px}
.card{flex:1;border:2px solid #C9C9C9;border-radius:14px;background:#fff;padding:24px 26px}
.card.hi{background:#EEF6EA;border-color:#26890D}
.card.gray{background:#F4F4F4;border-color:#DDD}
.card .hd{display:flex;align-items:center;gap:14px;font-size:28px;font-weight:700;color:#1B1B1B;margin-bottom:14px}
.card .hd svg{width:40px;height:40px;flex:none}
.card ul{list-style:none}
.card li{position:relative;padding-left:26px;font-size:24px;line-height:1.5;margin-bottom:12px}
.card li:before{content:"";position:absolute;left:4px;top:16px;width:10px;height:10px;border-radius:50%;background:#26890D}
.card li b{color:#26890D}
.band{position:absolute;left:0;right:0;bottom:0;height:84px;border-radius:14px;background:#26890D;color:#fff;font-size:25px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0 32px;gap:28px}
.band .arrow{font-size:34px}
.chk{display:flex;gap:16px;align-items:flex-start;margin-bottom:18px}
.chk svg{width:40px;height:40px;flex:none;margin-top:2px}
.chk .t{font-size:24px;line-height:1.45}
.chk .t b{color:#26890D;font-weight:700}
.chk .t .sub{display:block;color:#555;font-size:22px;line-height:1.4;margin-top:2px}
table.cmp{width:100%;border-collapse:collapse;table-layout:fixed}
table.cmp th{font-size:30px;font-weight:700;text-align:left;padding:14px 18px;vertical-align:middle;border-bottom:2px solid #C9C9C9}
table.cmp td{padding:20px 18px;vertical-align:top;border-bottom:2px solid #DDD;font-size:24px;font-weight:700}
table.cmp tr:last-child td{border-bottom:2px solid #DDD}
table.cmp .adopt{background:#EEF6EA}
table.cmp .sym{font-size:34px;font-weight:700;line-height:1.1}
table.cmp .sym.g{color:#26890D}.table .sym.k{color:#1B1B1B}
table.cmp .sym.k{color:#1B1B1B}
table.cmp .sym.d{color:#8A8A8A}
table.cmp .note{font-size:20px;color:#555;font-weight:400;line-height:1.35;margin-top:4px}
table.cmp th .sub{display:block;font-size:20px;color:#555;font-weight:400;margin-top:2px}
.chip{display:inline-block;background:#26890D;color:#fff;border-radius:999px;font-size:20px;font-weight:700;padding:4px 16px;margin-left:12px;vertical-align:middle}
.flow{display:flex;align-items:stretch;gap:0}
.flow .box{flex:1;border:2px solid #C9C9C9;border-radius:14px;background:#fff;padding:18px 20px;min-height:126px}
.flow .box.gray{background:#F4F4F4;border-color:#DDD}
.flow .box.hi{background:#EEF6EA;border-color:#26890D}
.flow .box .h{font-size:26px;font-weight:700;line-height:1.3}
.flow .box .n{font-size:20px;color:#555;line-height:1.35;margin-top:6px}
.flow .tri{align-self:center;width:0;height:0;border-top:18px solid transparent;border-bottom:18px solid transparent;border-left:22px solid #BDBDBD;margin:0 8px;flex:none}
.label{font-size:24px;font-weight:700;color:#1B1B1B;margin-bottom:12px}
.nums{display:flex;gap:24px}
.num{flex:1;border:2px solid #C9C9C9;border-radius:14px;padding:20px 26px;background:#fff}
.num .v{font-size:40px;font-weight:700;color:#26890D;line-height:1.2}
.num .u{font-size:22px;color:#555;margin-top:4px}
.num .d{font-size:22px;color:#555;line-height:1.4;margin-top:8px}
.files{font-size:24px;line-height:1.55}
.files .p{color:#555;font-size:22px;margin-bottom:6px}
.note{font-size:20px;color:#666;line-height:1.4}
.nw{white-space:nowrap}
.cover-sub{font-size:32px;font-weight:700;color:#1B1B1B;margin-top:28px}
.cover-date{font-size:24px;color:#555;margin-top:18px}
"""

# ---- line icons (green, stroke only) ----
def icon(name):
    s = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#26890D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
    paths = {
        "monitor": '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
        "message": '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        "building": '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>',
        "hand": '<path d="M18 11V6a2 2 0 0 0-4 0v5M14 10V4a2 2 0 0 0-4 0v2M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.9-5.9-2.7l-3.2-4.1a2 2 0 0 1 3.2-2.4L8 15"/>',
        "check": '<path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/><path d="M22 4 12 14.01l-3-3"/>',
        "redo": '<path d="M21 2v6h-6"/><path d="M21 13a9 9 0 1 1-3-7.7L21 8"/>',
        "flag": '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><path d="M4 22v-7"/>',
        "warn": '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
        "folder": '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
        "book": '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
        "list": '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
        "layers": '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
        "db": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.7-4 3-9 3s-9-1.3-9-3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/>',
        "calendar": '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        "sparkle": '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
    }
    return f'<svg {s}>{paths[name]}</svg>'

CHK = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#26890D"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'

def page(body_html, msg=None, title=None, title_only=None, up=False, top2=False):
    head = ""
    if title_only:
        head = f'<div class="title-only">{title_only}</div>'
    else:
        head = f'<div class="msg">{msg}</div><div class="title">{title}</div>'
    cls = "body top2" if top2 else ("body up" if up else "body")
    body_html = body_html.replace('新UI', '<span class="nw">新UI</span>')
    if msg: msg = msg.replace('新UI', '<span class="nw">新UI</span>')
    return f'<!doctype html><html lang="ja"><head><meta charset="utf-8"><style>{CSS}</style></head><body><div class="slide">{head}<div class="{cls}">{body_html}</div><div class="credit">Created with AI</div></div></body></html>'

def card(hd, icon_name, items, hi=False, extra_cls="", style=""):
    lis = "".join(f"<li>{it}</li>" for it in items)
    return f'<div class="card {"hi" if hi else ""} {extra_cls}" style="{style}"><div class="hd">{icon(icon_name)}<span>{hd}</span></div><ul>{lis}</ul></div>'

def chk_card(hd, icon_name, items, hi=False, style=""):
    rows = "".join(f'<div class="chk">{CHK}<div class="t"><b>{a}</b><span class="sub">{b}</span></div></div>' for a, b in items)
    return f'<div class="card {"hi" if hi else ""}" style="{style}"><div class="hd">{icon(icon_name)}<span>{hd}</span></div>{rows}</div>'

def sym(mark, note):
    cls = {"◎": "g", "○": "k", "△": "d"}[mark]
    return f'<div class="sym {cls}">{mark}</div><div class="note">{note}</div>'

slides = []

# ---------- 0. 表紙 ----------
slides.append(("slide_01_cover", page(
    '<div style="position:absolute;left:0;top:0">'
    '<div class="cover-sub">現状のご報告と、今後の進め方のご相談</div>'
    '<div class="cover-date">2026年10月30日</div></div>',
    title_only="アーキテクチャレビューAgent 高度化", up=False)))

# ---------- 1. 現状とMSの回答 ----------
b = '<div class="cards" style="height:500px">'
b += card("いまのPoC(クラシックUI)", "monitor", [
    "<b>一通り動く:</b> Mermaid化 → ホスティング判定 → 構成図チェック → 票作成(Excel) → 回答回収 → ナレッジ文案",
    "<b>残る課題:</b> 表示の揺れ、材料の受け渡し失敗、翌日の再開不可、判定のゆれ",
    "今週から Anthropic モデルが使え、安定性は改善",
])
b += card("MSの回答(要点)", "message", [
    "クラシックは「指示文だけで親→子→フローを回す」使い方を想定していない。Topic・変数・フロー・外部保存で明示的に組む前提",
    "翌日再開は、案件ごとの状態を外部(Dataverse 等)に保存して読み戻す",
    "多工程・やり直しが要る業務なら、新UI(GitHub Copilot Harness)が選択肢",
], hi=True)
b += card("社内の状況", "building", [
    "新UIの本番利用は非推奨(PoC は可)。12月初旬の展開が目標、後ろ倒しの可能性あり",
    "Dataverse は共有環境では使えない。使うなら独自環境の払い出し申請が必要",
    "MSの指摘は、これまでの不安定さの原因認識と一致",
])
b += '</div>'
b += '<div class="band"><span>課題: 指示文だけでは表示・受け渡しが安定しない</span><span class="arrow">→</span><span>結論: 制御を仕組み(Topic・外部保存)に移すか、新UIに移る</span></div>'
slides.append(("slide_02_genjo", page(b,
    msg="クラシックUIのPoCは一通り動くが、「指示文だけで制御する」設計には限界があることがMSの回答でも裏付けられた",
    title="1. 現状とMSの回答")))

# ---------- 2. 選択肢 ----------
b = '<table class="cmp"><colgroup><col style="width:300px"><col style="width:440px"><col style="width:440px"><col style="width:580px"></colgroup>'
b += '<tr><th>観点</th><th>A 現行の継続<span class="sub">クラシック + 指示文</span></th><th>B クラシック + Topic化<span class="sub">MS推奨</span></th><th class="adopt">C 新UI<span class="chip">採用</span><span class="sub">GitHub Copilot Harness</span></th></tr>'
rows = [
    ("表示・受け渡しの安定", ("△", "指示文で対処。限界あり"), ("○", "Topic・変数で固定できる"), ("◎", "1体のAgent+スキルで構造的に解消")),
    ("翌日再開・複数案件", ("△", "会話が切れると貼り直し"), ("○", "外部保存で可"), ("◎", "SharePoint 保存で可(設計済み)")),
    ("追加の工数・費用", ("○", "小。ライセンス内"), ("△", "中〜大。2週間前後の作り直し"), ("○", "中。構築1〜2日+テスト2週間。クレジット従量制")),
    ("本番利用(社内ルール)", ("○", "今すぐ可"), ("○", "今すぐ可"), ("△", "12月初旬が目標(後ろ倒しの可能性)")),
]
for r in rows:
    b += f'<tr><td>{r[0]}</td><td>{sym(*r[1])}</td><td>{sym(*r[2])}</td><td class="adopt">{sym(*r[3])}</td></tr>'
b += '</table>'
b += '<div class="band"><span>本命は新UI(11月PoC → 12月本番)。Topic化は解禁が大きく遅れた場合の保険。現行は凍結し、修正は最小限</span></div>'
slides.append(("slide_03_sentakushi", page(b,
    msg="新UIを本命にし、Topic化は保険として保留、現行は凍結して工数を新UIに集中する",
    title="2. 進め方の選択肢", up=True)))

# ---------- 3. スケジュールと相談 ----------
b = '<div class="label">進め方(案)</div><div class="flow">'
b += '<div class="box"><div class="h">新UIで PoC 構築・テスト</div><div class="n">11月上旬〜中旬 ｜ 設計一式は作成済み<br>構築1〜2日+テスト2週間</div></div><div class="tri"></div>'
b += '<div class="box gray"><div class="h">判断ポイント</div><div class="n">11月下旬 ｜ PoC の結果と IT の展開時期で<br>本番の形を決める</div></div><div class="tri"></div>'
b += '<div class="box"><div class="h">新UIで本番開始</div><div class="n">12月〜 ｜ 解禁後に切り替え<br>解禁前はクラシック現行版で限定運用</div></div>'
b += '</div>'
b += '<div class="cards" style="margin-top:26px;height:400px">'
b += chk_card("決めていただきたいこと", "hand", [
    ("新UIを本命にする", "11月の工数を新UIの PoC に充て、クラシックは現行版で凍結"),
    ("Topic化は保険として保留", "新UIの解禁が大きく遅れた時にだけ着手"),
    ("Dataverse は申請しない", "翌日再開は SharePoint で代替(設計済み)"),
], hi=True)
b += chk_card("あわせてお願いしたいこと", "check", [
    ("Copilot クレジットの枠", "新UIは作成・テストも従量課金。PoC 用の枠と超過時の扱い"),
    ("IT への確認", "本番解禁の条件と、12月初旬の目標が動いた時の連絡"),
    ("施策側の目標時期", "本番開始をいつまでにするか、すり合わせ"),
])
b += '</div>'
slides.append(("slide_04_schedule", page(b,
    msg="11月に新UIでPoCを行い、12月の解禁に合わせて本番へ移る。<br>ご判断いただきたいことが3点、あわせてお願いが3点",
    title="3. スケジュールと相談事項", up=False)))

# ---------- Appendix 1 ----------
b = '<div class="label">クラシックのまま直す場合の優先順位(MSの回答)</div><div class="flow">'
steps = [
    ("出力の受け渡しを確認", "子Agent・フローの結果を後続に明示的に渡す"),
    ("重要な処理を Topic 化", "順序を指示文でなく Topic で固定する"),
    ("入出力を変数で管理", "会話の文脈に頼らず変数で渡す"),
    ("Retry・エラー処理", "フロー側で Run after・Try/Catch・Retry Policy"),
    ("案件状態を外部に保存", "Case ID・工程・結果・Retry 回数・状態"),
]
for i, (h, n) in enumerate(steps):
    b += f'<div class="box"><div class="h">{h}</div><div class="n">{n}</div></div>'
    if i < len(steps) - 1:
        b += '<div class="tri"></div>'
b += '</div>'
b += '<div class="cards" style="margin-top:30px;height:360px">'
b += card("推奨する作り(失敗した工程から再開)", "redo", [
    "工程ごとに結果を保存し、失敗したら Retry、上限を超えたら Failed として状態を保存",
    "最初からやり直さず、保存済みの結果を使って失敗した工程から再実行",
    "「失敗したら再実行して」と指示文に書くだけに頼らない",
])
b += card("今後についてのMSの見解", "flag", [
    "<b>クラシック:</b> 処理の範囲や手順が明確で、決められた流れに沿って確実に処理したいケース向き",
    "<b>新UI:</b> 長時間・多工程、複数ツール連携、結果を見て計画を修正、失敗時に別の方法を選ぶ処理向き",
    "重複・回答漏れは、部品ごとに文脈が分かれるクラシックの性質によるもの(公式ドキュメントの記載)",
])
b += '</div>'
b += '<div class="band"><span>MSの結論: すぐに全面変更ではなく、まずクラシックの明示的な制御で構造化し、要件を超えるなら新UIへの再設計を検討</span></div>'
slides.append(("slide_05_apx1_ms", page(b, title_only="Appendix 1. MSの回答の要点", top2=True)))

# ---------- Appendix 2 ----------
b = '<div class="cards" style="height:330px">'
b += card("効くこと(これまで困ってきた問題の大半)", "check", [
    "<b>表示の揺れ:</b> 生データ・JSON・二重表示・英語の前置き。出す内容を固定できる",
    "<b>指示語の振り分けと材料の受け渡し:</b> 変数で渡すので迷子が減る",
    "<b>失敗からの再開:</b> 結果を保存し、失敗した工程だけ再試行",
], hi=True)
b += card("効かないこと", "warn", [
    "<b>判定のゆれ:</b> AI の判定なので Topic にしても残る。減らすには判定ロジックをフローに寄せる",
    "<b>画像の読み取り精度、会話の時間切れ</b>(外部保存があれば再開は可)",
    "<b>Topic の選択自体:</b> 生成オーケストレーションがオンだと AI が選ぶ。完全固定にはオフ+トリガーフレーズが要る",
])
b += '</div>'
b += '<div class="label" style="margin-top:30px">作り直す場合の中身と工数(目安)</div><div class="nums">'
b += '<div class="num"><div class="v">13個</div><div class="u">全体変数(材料ごと)</div><div class="d">RITM・環境・CSP・確定図・一覧・判定・観点・チェック・編集指示・編集データ・Excelリンク・回答・文案</div></div>'
b += '<div class="num"><div class="v">12本</div><div class="u">Topic(指示語ごと)</div><div class="d">各 Topic に「変数の取得 → フロー/子の実行 → 結果の保存 → 成功判定 → 表示」の分岐を作る</div></div>'
b += '<div class="num"><div class="v">8〜13人日</div><div class="u">構築5〜8 + テスト3〜5</div><div class="d">保守は「文章を直す」から「フロー図を直す」に変わる。作り方を知る人が要る</div></div>'
b += '</div>'
b += '<div class="band"><span>Topic化は「表示・振り分け・受け渡し・再開」に効くが「判定のゆれ」には効かない。作り直しは2週間前後</span></div>'
slides.append(("slide_06_apx2_topic", page(b, title_only="Appendix 2. Topic化で効くこと・効かないこと", top2=True)))

# ---------- Appendix 3 ----------
b = '<div style="display:flex;gap:24px">'
b += '<div style="width:1060px"><table class="cmp"><colgroup><col style="width:260px"><col style="width:400px"><col style="width:400px"></colgroup>'
b += '<tr><th>項目</th><th class="adopt">SharePoint<span class="chip">採用</span></th><th>Dataverse</th></tr>'
rows = [
    ("社内での利用", ("◎", "利用中(参照データと同じ場所)<br>申請は不要"), ("△", "共有環境では不可<br>独自環境の払い出し申請が必要")),
    ("構築", ("○", "保存・取得のフロー2本(設計済み)"), ("△", "環境の払い出し・テーブル設計<br>Agent の移設")),
    ("向いている規模", ("○", "1日数件、数人で運用"), ("◎", "多数の同時更新、行単位の権限管理")),
    ("今回の判断", ("◎", "採用。運用・申請の負担なし"), ("△", "見送り。案件数が増えたら再検討")),
]
for r in rows:
    b += f'<tr><td>{r[0]}</td><td class="adopt">{sym(*r[1])}</td><td>{sym(*r[2])}</td></tr>'
b += '</table></div>'
files = ["00_status.md ― 案件の状態(環境・CSP・完了した工程・次の操作)", "01_mermaid.md ― 確定図", "02_inventory.md ― 構成図一覧",
         "03_hosting.md ― ホスティング判定結果", "04_check.md ― 構成図チェック結果", "05_edit.md / 05_ticket.json ― 編集指示・Excel用データ",
         "06_answers.md ― 回答回収結果", "07_knowledge.md ― ナレッジ文案"]
fl = "".join(f"<div>{f}</div>" for f in files)
b += f'<div class="card" style="flex:1;height:540px"><div class="hd">{icon("folder")}<span>案件フォルダの形(設計済み)</span></div><div class="files"><div class="p">SharePoint ／ 案件データ ／ RITM番号 ／</div>{fl}</div><div class="note" style="margin-top:16px">翌日は「RITMxxx の状況」と入力すれば続きが分かる。複数案件はフォルダが分かれるので混ざらない</div></div>'
b += '</div>'
b += '<div class="band" style="bottom:0"><span>要件は「案件ごとの状態と途中成果物を会話の外に保存し、案件IDで読み戻せること」。Dataverse 固有の要件ではない</span></div>'
slides.append(("slide_07_apx3_resume", page(b, title_only="Appendix 3. 翌日再開はSharePointで実現できる", top2=True)))

# ---------- Appendix 4 ----------
b = '<div class="cards" style="height:330px">'
b += card("準備状況(設計一式 v1.0 作成済み)", "layers", [
    "<b>作成済み:</b> 設計書・手順書・指示文・スキル・ツール設計・テスト案",
    "既存フロー(T1〜T5)はそのまま再利用。指示語はクラシック版と同じ",
    "<b>見込み:</b> 構築1〜2日、テスト2週間(同じ入力を3回流して一致率を測る)",
], hi=True)
b += card("リスクと確認事項", "warn", [
    "一部機能がプレビュー(使わない設計にしてある)<br>クラシックとの相互移行は不可(フローは共用可)",
    "課金は Copilot クレジットの従量制。作成・テスト・評価も消費する",
    "共同編集の可否と、本番解禁の条件(承認・DLP・KB更新)は<br>IT に確認",
])
b += '</div>'
b += '<div class="card gray" style="margin-top:30px;height:150px"><div class="hd">' + icon("building") + '<span>社内ITの回答</span></div><div style="font-size:24px;line-height:1.5">現時点で新UIの本番利用は非推奨。将来は利用可能にする方向で検討中。内部的には12月初旬の展開が目標だが、状況により後ろ倒しの可能性あり</div></div>'
b += '<div class="band"><span>新UI側は設計一式が揃っており、構築1〜2日・テスト2週間で結果が出せる。残る外部要因は本番解禁の時期だけ</span></div>'
slides.append(("slide_08_apx4_newui", page(b, title_only="Appendix 4. 新UIの準備状況とリスク", top2=True)))

# ---------- Appendix 5 ----------
b = '<div class="cards" style="height:430px">'
b += card("作り方の種類", "book", [
    "<b>クラシックUI:</b> 従来の作り方。決められた流れを確実に処理するのに向く(今のPoC)",
    "<b>新UI:</b> 新しい実行基盤。自分で段取りを組み、失敗しても立て直せる(社内はPoCのみ可)",
    "<b>指示文:</b> エージェントに渡す文章の指示。「長いメモを渡して任せる」イメージ",
])
b += card("クラシックUIの部品", "list", [
    "<b>Topic:</b> 処理の順番を固定する部品。「チェックリストで順番を強制する」イメージ",
    "<b>変数:</b> 途中結果に名前を付けて保存する箱。Topic 間やフローとの受け渡しに使う",
    "<b>エージェントフロー:</b> SharePoint・Teams・Excel を読み書きする自動処理。どちらのUIからも共用できる",
])
b += card("保存先・費用・品質", "db", [
    "<b>Dataverse／SharePoint:</b> どちらも保存先。Dataverse は独自環境の申請が必要、SharePoint は利用中",
    "<b>Copilot クレジット:</b> 新UIの従量課金の単位。作成・テスト・本番のすべてで消費する",
    "<b>判定のゆれ:</b> 同じ入力でもAIの結果が少し変わること。人の確認とフロー化で抑える",
])
b += '</div>'
slides.append(("slide_09_apx5_terms", page(b, title_only="Appendix 5. 用語の説明", top2=True)))

# ---------- render ----------
with sync_playwright() as p:
    browser = p.chromium.launch()
    pg = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
    for name, html in slides:
        hp = os.path.join(HTML_DIR, name + ".html")
        with open(hp, "w", encoding="utf-8") as f:
            f.write(html)
        pg.goto("file://" + hp)
        pg.wait_for_timeout(150)
        pg.screenshot(path=os.path.join(OUT, name + ".png"), clip={"x": 0, "y": 0, "width": 1920, "height": 1080})
        print("rendered", name)
    browser.close()
