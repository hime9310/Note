# -*- coding: utf-8 -*-
"""リーダー向けスライド(1920x1080 PNG)生成スクリプト。HTML+CSS を Playwright(Chromium) で撮影する。"""
import os, sys
from playwright.sync_api import sync_playwright

OUT = os.path.dirname(os.path.abspath(__file__))
HTML_DIR = os.path.join(OUT, "html")
os.makedirs(HTML_DIR, exist_ok=True)

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1920px;height:1080px;background:#fff;word-break:auto-phrase;font-family:"Noto Sans CJK JP","Noto Sans JP","Yu Gothic","Meiryo",sans-serif;color:#1B1B1B;overflow:hidden}
.slide{position:relative;width:1920px;height:1080px;padding:64px 80px 56px 80px}
.msg{font-size:44px;font-weight:700;line-height:1.3;color:#1B1B1B;max-height:115px;overflow:hidden}
.title{font-size:32px;font-weight:700;color:#26890D;margin-top:16px}
.title-only{font-size:44px;font-weight:700;color:#26890D}
.body{position:absolute;left:80px;right:80px;top:290px;height:700px}
.body.up{top:250px;height:740px}
.body.top2{top:190px;height:800px}
.credit{position:absolute;right:80px;bottom:36px;font-size:20px;color:#8A8A8A}
.cards{display:flex;gap:24px}
.card{flex:1;border:2px solid #C9C9C9;border-radius:14px;background:#fff;padding:24px 26px}
.card.hi{background:#EEF6EA;border-color:#26890D}
.card.gray{background:#F4F4F4;border-color:#DDD}
.card .hd{display:flex;align-items:center;gap:14px;font-size:28px;font-weight:700;color:#1B1B1B;margin-bottom:14px}
.card .hd svg{width:40px;height:40px;flex:none}
.card ul{list-style:none}
.card li{position:relative;padding-left:26px;font-size:24px;line-height:1.5;margin-bottom:12px}
.card li:before{content:"";position:absolute;left:4px;top:16px;width:10px;height:10px;border-radius:50%;background:#26890D}
.card li b{color:#26890D}
.band{position:absolute;left:0;right:0;bottom:0;height:84px;border-radius:14px;background:#26890D;color:#fff;font-size:25px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0 32px;gap:28px}
.band .arrow{font-size:34px}
.chk{display:flex;gap:16px;align-items:flex-start;margin-bottom:18px}
.chk svg{width:40px;height:40px;flex:none;margin-top:2px}
.chk .t{font-size:24px;line-height:1.45}
.chk .t b{color:#26890D;font-weight:700}
.chk .t .sub{display:block;color:#555;font-size:22px;line-height:1.4;margin-top:2px}
table.cmp{width:100%;border-collapse:collapse;table-layout:fixed}
table.cmp th{font-size:30px;font-weight:700;text-align:left;padding:14px 18px;vertical-align:middle;border-bottom:2px solid #C9C9C9}
table.cmp td{padding:20px 18px;vertical-align:top;border-bottom:2px solid #DDD;font-size:24px;font-weight:700}
table.cmp tr:last-child td{border-bottom:2px solid #DDD}
table.cmp .adopt{background:#EEF6EA}
table.cmp .sym{font-size:34px;font-weight:700;line-height:1.1}
table.cmp .sym.g{color:#26890D}.table .sym.k{color:#1B1B1B}
table.cmp .sym.k{color:#1B1B1B}
table.cmp .sym.d{color:#8A8A8A}
table.cmp .note{font-size:20px;color:#555;font-weight:400;line-height:1.35;margin-top:4px}
table.cmp th .sub{display:block;font-size:20px;color:#555;font-weight:400;margin-top:2px}
.chip{display:inline-block;background:#26890D;color:#fff;border-radius:999px;font-size:20px;font-weight:700;padding:4px 16px;margin-left:12px;vertical-align:middle}
.flow{display:flex;align-items:stretch;gap:0}
.flow .box{flex:1;border:2px solid #C9C9C9;border-radius:14px;background:#fff;padding:18px 20px;min-height:126px}
.flow .box.gray{background:#F4F4F4;border-color:#DDD}
.flow .box.hi{background:#EEF6EA;border-color:#26890D}
.flow .box .h{font-size:26px;font-weight:700;line-height:1.3}
.flow .box .n{font-size:20px;color:#555;line-height:1.35;margin-top:6px}
.flow .tri{align-self:center;width:0;height:0;border-top:18px solid transparent;border-bottom:18px solid transparent;border-left:22px solid #BDBDBD;margin:0 8px;flex:none}
.label{font-size:24px;font-weight:700;color:#1B1B1B;margin-bottom:12px}
.vflow .box{border:2px solid #C9C9C9;border-radius:14px;background:#fff;padding:18px 24px;min-height:120px}
.vflow .box.gray{background:#F4F4F4;border-color:#DDD}
.vflow .box .h{font-size:26px;font-weight:700;line-height:1.3}
.vflow .box .n{font-size:20px;color:#555;line-height:1.4;margin-top:6px}
.vflow .dtri{width:0;height:0;border-left:18px solid transparent;border-right:18px solid transparent;border-top:22px solid #BDBDBD;margin:10px auto}
.nums{display:flex;gap:24px}
.num{flex:1;border:2px solid #C9C9C9;border-radius:14px;padding:20px 26px;background:#fff}
.num .v{font-size:40px;font-weight:700;color:#26890D;line-height:1.2}
.num .u{font-size:22px;color:#555;margin-top:4px}
.num .d{font-size:22px;color:#555;line-height:1.4;margin-top:8px}
.files{font-size:24px;line-height:1.55}
.files .p{color:#555;font-size:22px;margin-bottom:6px}
.note{font-size:20px;color:#666;line-height:1.4}
.nw{white-space:nowrap}
.toc{list-style:none}
.toc li{display:flex;align-items:baseline;gap:28px;padding:34px 8px;border-bottom:2px solid #DDD}
.toc li:last-child{border-bottom:none}
.toc .n{font-size:30px;font-weight:700;color:#26890D;width:60px;flex:none}
.toc .t{font-size:30px;font-weight:700;color:#1B1B1B;width:520px;flex:none}
.toc .d{font-size:22px;color:#555;line-height:1.4}
table.def{width:100%;border-collapse:collapse;table-layout:fixed}
table.def th{font-size:28px;font-weight:700;text-align:left;padding:12px 18px;border-bottom:2px solid #C9C9C9;vertical-align:middle}
table.def td{font-size:24px;line-height:1.45;padding:12px 18px;border-bottom:2px solid #DDD;vertical-align:top;color:#1B1B1B}
table.def td.k{font-weight:700;color:#1B1B1B}
table.def .hi{background:#EEF6EA}
.lnk{border:2px dashed #C9C9C9;border-radius:10px;color:#8A8A8A;font-size:20px;display:flex;align-items:center;justify-content:center;width:420px;height:64px;flex:none}
.row{display:flex;align-items:flex-start;gap:24px;padding:22px 0;border-bottom:2px solid #DDD}
.row:last-child{border-bottom:none}
.row svg{width:40px;height:40px;flex:none;margin-top:2px}
.row .t{flex:1;font-size:24px;line-height:1.45}
.row .t b{color:#26890D}
.row .t .sub{display:block;color:#555;font-size:22px;line-height:1.4;margin-top:4px}
.cover-sub{font-size:32px;font-weight:700;color:#1B1B1B;margin-top:28px}
.cover-date{font-size:24px;color:#555;margin-top:18px}
"""

# ---- line icons (green, stroke only) ----
def icon(name):
    s = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#26890D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
    paths = {
        "monitor": '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
        "message": '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        "building": '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>',
        "hand": '<path d="M18 11V6a2 2 0 0 0-4 0v5M14 10V4a2 2 0 0 0-4 0v2M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.9-5.9-2.7l-3.2-4.1a2 2 0 0 1 3.2-2.4L8 15"/>',
        "check": '<path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/><path d="M22 4 12 14.01l-3-3"/>',
        "redo": '<path d="M21 2v6h-6"/><path d="M21 13a9 9 0 1 1-3-7.7L21 8"/>',
        "flag": '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><path d="M4 22v-7"/>',
        "warn": '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
        "folder": '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
        "book": '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
        "list": '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
        "layers": '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
        "db": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.7-4 3-9 3s-9-1.3-9-3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/>',
        "calendar": '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        "sparkle": '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
    }
    return f'<svg {s}>{paths[name]}</svg>'

CHK = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#26890D"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'

def page(body_html, msg=None, title=None, title_only=None, up=False, top2=False):
    head = ""
    if title_only:
        head = f'<div class="title-only">{title_only}</div>'
    else:
        head = f'<div class="msg">{msg}</div><div class="title">{title}</div>'
    cls = "body top2" if top2 else ("body up" if up else "body")
    body_html = body_html.replace('新UI', '<span class="nw">新UI</span>')
    if msg: msg = msg.replace('新UI', '<span class="nw">新UI</span>')
    return f'<!doctype html><html lang="ja"><head><meta charset="utf-8"><style>{CSS}</style></head><body><div class="slide">{head}<div class="{cls}">{body_html}</div><div class="credit">Created with AI</div></div></body></html>'

def card(hd, icon_name, items, hi=False, extra_cls="", style=""):
    lis = "".join(f"<li>{it}</li>" for it in items)
    return f'<div class="card {"hi" if hi else ""} {extra_cls}" style="{style}"><div class="hd">{icon(icon_name)}<span>{hd}</span></div><ul>{lis}</ul></div>'

def chk_card(hd, icon_name, items, hi=False, style=""):
    rows = "".join(f'<div class="chk">{CHK}<div class="t"><b>{a}</b><span class="sub">{b}</span></div></div>' for a, b in items)
    return f'<div class="card {"hi" if hi else ""}" style="{style}"><div class="hd">{icon(icon_name)}<span>{hd}</span></div>{rows}</div>'

def sym(mark, note):
    cls = {"◎": "g", "○": "k", "△": "d"}[mark]
    return f'<div class="sym {cls}">{mark}</div><div class="note">{note}</div>'

slides = []

# ---------- 0. 表紙 ----------
slides.append(("slide_01_cover", page(
    '<div style="position:absolute;left:0;top:0">'
    '<div class="cover-sub">現状のご報告と、今後の進め方のご相談</div>'
    '<div class="cover-date">2026年10月30日</div></div>',
    title_only="アーキテクチャレビューAgent 高度化")))

# ---------- 目次 ----------
toc = [
    ("1", "現状とMSの回答", "PoC の到達点と残る課題、MS 回答の抜粋、社内の状況"),
    ("2", "進め方の選択肢", "現行の継続 ／ クラシック+Topic化 ／ 新UI の比較と提案"),
    ("3", "スケジュールと相談事項", "11月の PoC、判断ポイント、後ろ倒しの備え、ご相談3点"),
    ("4", "新旧UIの定義と比較", "クラシックUI(Standard Harness)と新UI(GitHub Copilot Harness)の違い"),
    ("5", "New experience について", "① 新UI関連の社内動向(KBA の記載・社内問い合わせ・ウェビナー)"),
]
b = '<ul class="toc">' + "".join(f'<li><span class="n">{n}.</span><span class="t">{t}</span><span class="d">{d}</span></li>' for n, t, d in toc) + '</ul>'
slides.append(("slide_02_toc", page(b, title_only="目次", top2=True)))

# ---------- 1. 現状とMSの回答 ----------
b = '<div class="cards" style="height:570px">'
b += card("いまのPoC(クラシックUI)", "monitor", [
    "<b>一通りの動き:</b> Mermaid化 → 情報抽出 → ホスティング判定 → 観点抽出 → 構成図チェック → Excel(アーキテクチャレビュー票)作成 → 回答済みExcelの回収 → 2次チェック",
    "<b>残る課題:</b> 表示の揺れ、英語の前置き、判定の揺れなど、動作が不安定",
    "今週から Anthropic のモデルが使えるようになったが、大きな変化はなし",
])
b += card("MS回答の抜粋", "message", [
    "「ClassicUI(Standard Harness)では、必ず実行したい処理や順序は Topic・変数・Agent Flow を組み合わせて明示的に制御することをお勧めします」",
    "「情報が明示的に返されない設計では、重複や回答漏れが発生する可能性があります」",
    "「翌日の再開は、案件ごとの状態を Dataverse 等の外部データストアで管理する設計を推奨します」",
], hi=True)
b += card("社内の状況", "building", [
    "<span class=\"nw\">新UI</span>の本番利用は非推奨(PoC は可)。12月初旬の展開が目標、後ろ倒しの可能性あり",
    "Dataverse は共有環境では使えない。使うなら独自環境の払い出し申請が必要",
    "MS の指摘は、これまでの不安定さの原因認識と一致",
])
b += '</div>'
b += '<div class="band"><span>課題: 指示文だけでは安定しない</span><span class="arrow">→</span><span>MS: まず明示的な制御で構造化し、要件を超えるなら新UI(GitHub Copilot Harness)への再設計を検討</span></div>'
slides.append(("slide_03_genjo", page(b,
    msg="クラシックUIのPoCは一通り動くが不安定さが残り、MSの回答でも「指示文だけで制御する」設計の限界が示された",
    title="1. 現状とMSの回答")))

# ---------- 2. 選択肢 ----------
b = '<table class="cmp"><colgroup><col style="width:300px"><col style="width:440px"><col style="width:440px"><col style="width:580px"></colgroup>'
b += '<tr><th>観点</th><th>A 現行の継続<span class="sub">クラシック + 指示文</span></th><th>B クラシック + Topic化<span class="sub">MS推奨</span></th><th class="adopt">C 新UI<span class="chip">検討</span><span class="sub">GitHub Copilot Harness</span></th></tr>'
rows = [
    ("表示・受け渡しの安定", ("△", "指示文で対処。限界あり"), ("○", "Topic・変数で固定できる"), ("◎", "1体のAgent+スキルで構造的に解消")),
    ("翌日再開・複数案件", ("△", "会話が切れると貼り直し"), ("○", "外部保存で可(SharePoint 保存可能※)"), ("○", "外部保存で可(SharePoint 保存可能※)")),
    ("追加の工数", ("○", "小。修正の継続"), ("△", "中〜大。Topic の作り直しに時間を要する"), ("○", "中。設計・テストに時間を要する")),
    ("本番利用(社内ルール)", ("○", "今すぐ可"), ("○", "今すぐ可"), ("△", "12月初旬が目標(後ろ倒しの可能性)")),
]
for r in rows:
    b += f'<tr><td>{r[0]}</td><td>{sym(*r[1])}</td><td>{sym(*r[2])}</td><td class="adopt">{sym(*r[3])}</td></tr>'
b += '</table>'
b += ('<div class="note" style="position:absolute;left:0;right:0;bottom:104px">※ エージェント フロー(コネクタ)で SharePoint へのファイル保存・取得が可能。公式の説明: '
      '<span class="nw">learn.microsoft.com/ja-jp/microsoft-copilot-studio/flows-overview</span> ／ <span class="nw">learn.microsoft.com/ja-jp/connectors/sharepointonline/</span></div>')
b += '<div class="band"><span>提案: 新UIを軸に検討(11月に PoC → 解禁後に本番)。Topic化は解禁が大きく遅れた場合の保険。現行は凍結し、修正は最小限</span></div>'
slides.append(("slide_04_sentakushi", page(b,
    msg="新UIを軸に検討を進め、Topic化は保険として保留、現行は凍結する案としたい",
    title="2. 進め方の選択肢", up=True)))

# ---------- 3. スケジュールと相談 ----------
b = '<div style="display:flex;gap:30px">'
# left: vertical flow
b += '<div style="width:1000px"><div class="label">進め方(案)</div>'
b += '<div class="vflow">'
b += '<div class="box"><div class="h">新UIで PoC 構築・テスト</div><div class="n">11月 ｜ 設計・テストに時間を要する。クラシックは現行版で凍結</div></div>'
b += '<div class="dtri"></div>'
b += '<div class="box gray"><div class="h">判断ポイント</div><div class="n">11月下旬 ｜ PoC の結果と IT の展開時期で、本番の形を決める</div></div>'
b += '<div class="dtri"></div>'
b += '<div class="box"><div class="h">本番開始</div><div class="n">解禁どおり: 新UIで本番開始<br>後ろ倒し: クラシック現行版で限定運用を続け、Topic化の着手を判断</div></div>'
b += '</div></div>'
# right: consultation card
b += chk_card("ご相談したいこと(進め方)", "hand", [
    ("新UIを軸に検討を進める", "11月の工数を新UIの PoC に充て、クラシックは現行版で凍結"),
    ("Topic化は保険として保留", "新UIの解禁が大きく遅れた時に着手を判断"),
    ("Dataverse は申請せず、SharePoint 保存で進める", "翌日再開の要件は SharePoint で満たせる見込み"),
], hi=True, style="flex:1;height:505px")
b += '</div>'
b += '<div class="band"><span>後ろ倒しになっても、クラシック現行版で業務は継続できる(出力はすべて案で、Eng が確認してから使う)</span></div>'
slides.append(("slide_05_schedule", page(b,
    msg="11月に新UIで PoC を行い、社内の解禁に合わせて本番へ移る進め方を提案したい。<br>後ろ倒しになった場合の備えも含めて、3点ご相談",
    title="3. スケジュールと相談事項")))

# ---------- 4. 新旧UIの定義と比較 ----------
b = '<div class="cards" style="height:255px">'
b += card("クラシックUI(Standard Harness)", "list", [
    "Copilot Studio の従来の作り方。Topic・変数・エージェントフローで「決められた流れ」を確実に実行することを前提に設計",
    "<b>たとえ:</b> チェックリストどおりに進める担当者",
])
b += card("新UI(GitHub Copilot Harness ／ New experience)", "sparkle", [
    "2026年に公開された新しい実行基盤。指示文・スキル(手順書)・ツールを渡すと、AI が段取りを組んで実行し、失敗したら別の方法を試す",
    "<b>たとえ:</b> 自分で段取りを組み、立て直せる担当者",
])
b += '</div>'
b += '<table class="def" style="margin-top:16px"><colgroup><col style="width:300px"><col style="width:730px"><col style="width:730px"></colgroup>'
b += '<tr><th>観点</th><th>クラシックUI</th><th class="hi">新UI</th></tr>'
rows = [
    ("向いている処理", "処理の範囲と手順が決まっていて、同じ流れを確実に繰り返す業務", "工程が多く、結果を見て計画を直したり、失敗時に別の方法を選ぶ業務"),
    ("作り方の部品", "Topic、変数、子エージェント、エージェントフロー", "指示文、スキル(SKILL.md)、ツール(ワークフロー・コネクタ・MCP)"),
    ("失敗した時の動き", "人が Topic に分岐と再試行を組んでおく必要がある", "AI が結果を見て再試行や別の方法を選ぶ(評価・監視の機能あり)"),
    ("提供状況・社内ルール", "一般提供。社内で本番利用可", "一般提供は発表済みだが、一部機能はプレビュー。社内では <span class=\"nw\">PoC は可</span>、本番は非推奨(12月初旬の解禁が目標)"),
]
for k, a, c in rows:
    b += f'<tr><td class="k">{k}</td><td>{a}</td><td class="hi">{c}</td></tr>'
b += '</table>'
slides.append(("slide_06_ui_compare", page(b,
    msg="クラシックUIは「決められた流れを確実に処理する」基盤、新UIは「段取りを組んで試行錯誤する」基盤",
    title="4. 新旧UIの定義と比較")))

# ---------- 5. New experience について ① 社内動向 ----------
items = [
    ("社内 KBA の記載", "New experience はプレビュー機能のため非推奨。本番利用の可否はルール改定待ち"),
    ("社内問い合わせ(IT 部門への確認)", "現時点は非推奨だが、将来は利用可能にする方向で検討中。内部目標は 12月初旬の展開、後ろ倒しの可能性あり"),
    ("社内ウェビナー", "11月のウェビナーで、Copilot Studio 新UIを使ったデモを行う予定(社内メンバーの発言)"),
    ("本 PoC での利用", "PoC 用途は社内ルール上も可。新UIの設計・検証はこの枠内で進めている"),
]
b = '<div class="label">社内で確認できた動き(各項目のリンクは枠に貼り付け)</div>'
for a, c in items:
    b += f'<div class="row">{CHK}<div class="t"><b>{a}</b><span class="sub">{c}</span></div><div class="lnk">リンクを貼り付け</div></div>'
b += '<div class="band"><span>解禁の時期は社内 IT の判断次第。動きを継続して確認し、11月下旬の判断ポイントに反映する</span></div>'
slides.append(("slide_07_newui_trend", page(b,
    msg="社内でも新UIの利用に向けた動きが始まっており、本番解禁の時期だけが未確定",
    title="5. New experience について ― ① 新UI関連の社内動向", up=True)))

# ---------- render ----------
with sync_playwright() as p:
    browser = p.chromium.launch()
    pg = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
    for name, html in slides:
        hp = os.path.join(HTML_DIR, name + ".html")
        with open(hp, "w", encoding="utf-8") as f:
            f.write(html)
        pg.goto("file://" + hp)
        pg.wait_for_timeout(150)
        pg.screenshot(path=os.path.join(OUT, name + ".png"), clip={"x": 0, "y": 0, "width": 1920, "height": 1080})
        print("rendered", name)
    browser.close()
