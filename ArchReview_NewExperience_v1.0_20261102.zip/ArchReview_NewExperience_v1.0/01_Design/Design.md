# アーキテクチャレビューAgent 設計書(New experience 版 v1.0)

- 版: 1.0(PoC 実装用。エージェントを日本語設定・新ソリューションで作り直した版) ｜ 作成日: 2026-11-02 ｜ 作成: CMS Eng
- 位置づけ: 新UI(GitHub Copilot ハーネス)で進めることが決まったのを受け、ツールも含めてゼロから設計し直したもの。クラシック版の業務設計(工程・判定ルール・出力形式・指示語)は引き継ぎ、作り(1体+スキル、直接アクション、Python、SharePoint 保存)は新しくした
- 関連: 02_Setup/Setup.md(手順書)、03_Instructions/00_Agent.txt(指示文)、04_Skills/(スキル7本)、05_Tools/Tools.md(ツール)、06_Tests/TestSet.md(一連テスト)、01_参照データ/README(参照データの更新ルール)

---

## 1. 方針

| # | 方針 | 内容 |
|---|---|---|
| 1 | エージェントは1体、工程ごとにスキル7本 | 親子構造をやめる。クラシック版で苦労した「子に材料が渡らない」「表示が二重になる」が構造的に消える。接続エージェント(Preview)は使わない |
| 2 | 役割分担を固定する | LLM=判断と文章(記載有無の判定・区分・利用者向け文案)/ ツール=M365 との入出力(取る・書く)/ Python=取ってきたデータの処理(絞り込み・照合・検算・JSON 整形・状態ファイルの更新) |
| 3 | ツールは直接アクションを基本に | SharePoint・Excel Online・Teams のアクションを直接ツールにする(12本)。ワークフローはバイナリ(雛形 xlsx のコピー)を扱う Excel 作成の1本だけ。MCP・クラシック版のフローは使わない |
| 4 | 参照データは md と原本 Excel | 観点表・KO要件・Salus・Mermaid規則は md を直接読む。票のテンプレートは原本 xlsx(テーブル)を直接読む。md の手変換は観点表だけ(xlsx2md.py で生成) |
| 5 | 案件の状態は SharePoint のファイル | 案件ごとのフォルダ 02_案件データ/RITM番号/ に 00_status.md(状態)と成果物を置く。翌日・別の会話は「RITMxxx の状況」から再開。MS 推奨の「外部データストアに Case ID で保存」を Dataverse でなく SharePoint で実現 |
| 6 | Teams スレッドはリンクで指定 | 最初の指示でスレッドのリンクを貼り、Python が3つの ID を取り出して状態に保存。以降の工程はその ID で読む。仮スレッド固定をやめる |
| 7 | ナレッジは背景知識だけ | 社内環境の説明(dcs-env-definitions.md)をナレッジに登録し、判定・チェックの前に確認させる。分母になる一覧はナレッジでなくツールで取る。Web 検索は外す |
| 8 | 出力はすべて案 | 確定・承認・利用者連絡・ナレッジ登録は人。Teams への投稿はしない |

---

## 2. 全体構成

```
[Eng] プレビュー(PoC) / Teams(発行後)
  │ 指示語(クラシック版 v6.3.1 と同じ)。初回は 画像 + Teams スレッドのリンク
  ▼
[DTG_Architecture_Review_Poc](New experience・1体)
  ├ 指示文: 役割・厳守8・案件フォルダ・状態ファイルの形・対応表・出力形式・共通厳守事項
  ├ スキル(zip = SKILL.md + scripts/*.py + references/)
  │   diagram / extract / hosting / check / sheet / answers / knowledge
  ├ ツール(13本。05_Tools/Tools.md)
  │   SharePoint: 参照_構成図チェック観点取得 / 参照_ノックアウト要件取得 / 参照_SalusStatus取得 / 参照_Mermaid生成規則取得 / 案件_状態と成果物の取得 / 案件_状態と成果物の保存
  │   Excel:      レビュー票テンプレート_AWS_行取得 / _Azure / _GCP / 回答済みレビュー票_行取得
  │   Teams:      Teams_親投稿取得 / Teams_返信一覧取得
  │   ワークフロー: アーキテクチャレビュー票_Excel作成(雛形コピー → スクリプト実行 → リンク)
  ├ ナレッジ: 社内環境の説明(dcs-env-definitions.md)。Web 検索は削除
  ├ メモリ: オフ ｜ 接続されたエージェント: 使わない
  └ モデル: 画像入力に対応し長い手順に強いもの

[SharePoint] New experience/
  01_参照データ/  観点表.md / KO要件.md / salus.md / Mermaid規則.md / dcs-env.md / テンプレート xlsx(AWS/Azure/GCP) / 雛形(CSP名).xlsx
  02_案件データ/RITM番号/  00_status.md, 01_mermaid.md, 02_inventory.md, 03_thread.md, 03_hosting.md, 04_check.md, 05_edit.md, 05_ticket.json, 06_answers.md, 06_answer_rows.json, 07_knowledge.md (+ _1st 退避)
  送付用/  【案件名】(RITM)アーキテクチャレビュー票(CSP).xlsx
```

---

## 3. 工程表

| # | 工程 | 指示語 | スキル | 読む | ツール | Python | 書く |
|---|---|---|---|---|---|---|---|
| 1 | Mermaid化 | RITMxxx 添付した構成図をMermaid化して(+画像、+リンク) | diagram | ― | 参照_Mermaid生成規則取得、案件_状態と成果物の保存 | parse_teams_link、status_tool | 01、00(新規。フォルダも) |
| 2 | 抽出 | 構成図情報を抽出して | extract | 01、00 | 案件_状態と成果物の取得・作成 | check_r0、status_tool | 02、00 |
| 3 | 判定 / 再判定 | ホスティング判定して / ホスティング再判定して | hosting | 00、02、(06)、(03) | Teams×2、参照_ノックアウト要件取得、参照_SalusStatus取得、案件_状態と成果物の取得・作成 | teams_to_text、salus_match、check_hosting、status_tool | 03_thread、03(旧→03_1st)、00 |
| 4 | 1次 / 2次チェック | 構成図チェックして / 2次の構成図チェックして | check | 00、01、02、(03)、(03_thread)、(06)、(04) | 参照_構成図チェック観点取得、案件_状態と成果物の取得・作成 | filter_points、check_count、status_tool | 04(旧→04_1st)、00 |
| 5 | 編集指示 / 見直し / 修正反映 | アーキテクチャレビュー票の編集指示を作成して / 見直して | sheet | 00、04、(03)、(05)、(06) | レビュー票テンプレート_(CSP)_行取得、案件_状態と成果物の取得・作成 | build_ticket prepare / final、status_tool | 05_edit、05_ticket、00 |
| 6 | Excel 作成 | アーキテクチャレビュー票を作成して | sheet | 00、05_ticket | レビュー票テンプレート_(CSP)_行取得、アーキテクチャレビュー票_Excel作成 | build_ticket final、status_tool | (送付用 xlsx)、00 |
| 7 | 回答回収 | 回答を回収して | answers | 00、(05) | Teams×2、回答済みレビュー票_行取得、案件_状態と成果物の保存 | teams_to_text、answers_tool locate / prepare / verify、status_tool | 06、06_answer_rows、00 |
| 8 | ナレッジ文案 | ナレッジ文案を作成して | knowledge | 00、03、(02、04、05、06、03_thread) | 案件_状態と成果物の取得・作成、(Teams×2) | (teams_to_text)、status_tool | 07、00 |
| ― | 状況 / 環境・CSP の指定 / スレッドの指定 | RITMxxx の状況 / 環境は○○で進めて / スレッドは <リンク> | (指示文) | 00 | 案件_状態と成果物の取得・作成 | ― | 00 |

- 「構成図チェック観点を取得して」は無い(check の中で絞り込む)。2次チェックは チェックタイミング=2次 の観点だけ。構成図が直って戻ったら『構成図チェックして』を流し直す
- 直前の成果物への指摘は、直前のスキルを「修正」で再実行し同じファイルを上書き(ツール・スクリプトは再実行しない。hosting の修正だけ Teams を再取得)

---

## 4. データ設計

### 4.1 参照データ(01_参照データ。README に更新ルール)
| ファイル | 読み方 | 使う所 |
|---|---|---|
| 構成図チェック観点一覧.md(T_Points 16列 + T_GlobalServices + T_Vocab) | 参照_構成図チェック観点取得 → filter_points.py | check |
| ノックアウト要件一覧.md(ID / No. / 要因 / 具体的なケース / 判断区分 / 備考) | 参照_ノックアウト要件取得 → check_hosting.py | hosting |
| salus_status.md(サービス名 / status) | 参照_SalusStatus取得 → salus_match.py | hosting |
| Mermaid生成規則.md | 参照_Mermaid生成規則取得 | diagram |
| dcs-env-definitions.md | ナレッジ | hosting / check |
| アーキテクチャレビュー票(AWS/Azure/GCP).xlsx(T_アーキテクチャレビュー票) | レビュー票テンプレート_(CSP)_行取得 → build_ticket.py | sheet |
| アーキテクチャレビュー票(CSP名).xlsx(雛形 + Office スクリプト) | ワークフロー アーキテクチャレビュー票_Excel作成 | sheet |

### 4.2 案件データ(02_案件データ/RITM番号/)
| ファイル | 内容 | 書く | 読む |
|---|---|---|---|
| 00_status.md | 【案件状態】RITM / 対象環境・CSP / 完了した工程 / 次の操作 / Teamsスレッド(3 ID) / スレッドリンク / 更新 | 全スキル(status_tool.py)・指示文 | 全スキル・指示文 |
| 01_mermaid.md | 【確定図】Mermaid + 注釈情報 | diagram | extract、check |
| 02_inventory.md | 【構成図一覧】 | extract | hosting、check、knowledge |
| 03_thread.md | 【Teamsスレッド】本文と添付 | hosting | check、knowledge |
| 03_hosting.md / 03_hosting_1st.md | 【ホスティング判定結果】/ 再判定前の退避 | hosting | check、sheet、knowledge |
| 04_check.md / 04_check_1st.md | 【構成図チェック結果】/ 2次前の退避 | check | sheet、knowledge |
| 05_edit.md | 【編集指示】 | sheet | sheet、answers、knowledge |
| 05_ticket.json | 編集データ {"env","edit","add","drop"}(8キーの行) | sheet | sheet(Excel生成) |
| 06_answers.md / 06_answer_rows.json | 【回答回収結果】/ 回答済み票の行 | answers | hosting(再判定)、check(2次)、sheet(見直し)、knowledge |
| 07_knowledge.md | 【ナレッジ文案】 | knowledge | knowledge(修正) |

### 4.3 検算
| 記号 | 式 | スクリプト |
|---|---|---|
| R0 | サービス一覧 + 除外 = Mermaid のノード総数 | check_r0.py |
| (判定) | 非該当 + 個別 = KO 全行数 / TRUE + FALSE + 未照合 = サービス件数 | check_hosting.py、salus_match.py |
| (チェック) | 6区分の合計 = 適用行数(count)。[ ] の残り 0 | filter_points.py、check_count.py |
| R2 | ①+②+④+⑤ = テンプレート全行数 | build_ticket.py final |
| R3 | 書き込み件数 = ①+②+③ | build_ticket.py final(r3_expected)とアーキテクチャレビュー票_Excel作成(result) |
| R4 | 回答済み + 未回答 + 要確認 = 全行数 | answers_tool.py verify |

---

## 5. 出力形式(クラシック版 v6.3.1 と同じ)

| 成果物 | 1行目 | 見出しの順 |
|---|---|---|
| 【確定図】 | 状態: 完了 / 要確認 | Mermaid → 注釈情報 → 要確認 |
| 【構成図一覧】 | 状態: 完了 / 要確認 | 基本情報 → サービス一覧 → 除外ノード → NW情報 → 注釈情報 → 記載なし・方向不明 → 要確認 → 検算 |
| 【ホスティング判定結果】 | 状態: 完了 / 要確認 / 失敗 | 判定 → ノックアウト要件 照合 → Salus照合 → 要確認 → ヒアリング文 → 検算 |
| 【構成図チェック結果】 | 状態: 完了 / 要確認 | 結論 → 対応が必要な観点(区分ごと) → 問題なし・対象外 → 利用者への確認・依頼 → 観点ごとの判定 → 要確認 → 検算 |
| 【編集指示】 | 状態: 完了 / 要確認 | 条件 → ⑤環境対象外 → ①流用 → ②添削 → ③追記 → ④不要 → 検算 → 要確認 |
| 【Excel結果】 | 状態: 完了 / 要確認 | 書き込み件数 / ファイル / リンク / 検算R3 |
| 【回答回収結果】 | 状態: 完了(すべて解消) / 要確認 / 未着 | 集計 → 未回答 → 要確認 → 回答済み → 検算 |
| 【ナレッジ文案】 | 状態: 完了 / 要確認 | 文案(16行) → 要確認 |
| 【案件状態】 | RITM: | 対象環境・CSP / 完了した工程 / 次の操作 / Teamsスレッド / スレッドリンク / 更新 |

画面の表示: 返答は『【』から始め、成果物の全文 → 「---」 → 「次の操作:」1./2.。前置き・英語・JSON・ツールの生データを出さない(指示文の厳守8・出力形式)。

---

## 6. 観点表(T_Points)の読み方(check の中身)

- 絞り込み(Python): 有効=1 → 環境 ∈ {DCS共通, DCS <対象環境>} → 対象CSP ∋ CSP または 共通 → チェックタイミング = 1次/2次 または 両方
- トリガー(Python): 常時=実施 / 存在=トリガー対象のサービス(「/」区切り。@T_GlobalServices はその表の CSP のサービス)が【構成図一覧】にあれば実施、無ければ 対象外(利用なし) / 回答=「項目=値」に当たる回答が 06_answers.md(無ければ 03_thread.md)にあれば LLM が判定、無ければ 対象外(回答なし) / 存在かつ回答=両方
- 判定(LLM): 判定値は 記載あり / 記載なし / 方向不明 / 判定不能 / 対象外 の5語。区分は 区分表(判定値→記号)。無い判定値は B。表示名 A=問題なし / B=Eng目視確認 / C=利用者へ依頼 / D=票で確認 / E=対象外
- 指摘概要(票との対応): 観点の「指摘概要」列(共通: 文 / AWS: 文 …)をその CSP で選び、チェック結果の各行に (票: 文) として残す。sheet はこの文+環境でテンプレート行を探し、あれば ②添削、無ければ ③追記

---

## 7. テスト・運用

- テスト: 06_Tests/TestSet.md(一連 16 項目 → 安定性 3回 → 記録)
- 運用: 案件が来たら『RITMxxx 添付した構成図をMermaid化して』+画像+スレッドのリンク。以降は「次の操作」のとおり。翌日は『RITMxxx の状況』。失敗した会話では再指示せず新しい会話で同じ指示語
- 参照データの更新: 01_参照データ/README のルール。テンプレートの版が上がったら レビュー票テンプレート_(CSP)_行取得 のファイルを選び直す
- クレジット: 1工程 = ツール 2〜6回 + スクリプト 2〜4回 + LLM。活動トレースで回数を確認し、重複呼び出しは指示文で禁止

---

## 8. 未決・後回し

- 回答済みレビュー票_行取得 で Teams 添付のパスが AI 入力で通るか(通らなければ案件フォルダに置く運用)
- ファイルの作成 が上書きするか(フォルダの自動作成は確認済み。上書きしなければ ファイルの更新 で代替)
- 作業中の進捗表示(ハーネスの要約)が日本語になるか(厳守8 で指示。変わらなければ Teams での見え方で判断)
- Python の実行環境(zip のスクリプトが動くか。動かなければ LLM 版に切り替え)
- 案件一覧が欲しくなったら SharePoint リスト(1案件1行)を追加
- T5 相当(回答済み票の回収)を Teams 添付以外(メール・直接アップロード)に広げる
- 一括モード、Mgmt 事前相談スキル、申し送り(サービス提供対象リソース一覧)
