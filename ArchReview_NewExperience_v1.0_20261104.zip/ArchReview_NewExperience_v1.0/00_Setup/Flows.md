# エージェント フロー(ワークフロー)4本の作り方(v1.0 / 2026-11-04)

すべて New experience のワークフロー デザイナーで新規作成する(ソリューション CMS_Eng_ArchitectureReview の中)。式は書かない。値は「Please enter your input」欄に文字を打つか、前のノードの出力トークンを選ぶ。文字とトークンは同じ欄に混ぜてよい(例: `Title eq '` + トークン + `'`)。
作ったら エージェントの 作成 > ツール > 追加 > ワークフロー でツールとして追加し、名前を下の名前にそろえる。

| # | 名前 | 役割 | 入力 → 出力 |
|---|---|---|---|
| F1 | 案件状態_取得 | List の行を読む | RITM番号 → 項目ID, 状態テキスト(無ければ「未作成」) |
| F2 | 案件状態_作成 | List に行を作る(Mermaid化の初回だけ) | RITM番号, 案件名, 案件フォルダ, Teams_team, Teams_channel, Teams_message, スレッドリンク → 項目ID |
| F3 | 案件状態_更新 | List の行を書き換える | 項目ID + 列の値(status_tool.py の出力のキーと同名) → 結果 |
| F4 | アーキテクチャレビュー票_Excel作成 | 雛形から Excel を作り行を書く | RITM番号, CSP, rowsJson, fileName → result, fileLink, fileName |

共通: SharePoint のノードの サイトのアドレス=JP CMS、リスト名=アーキテクチャレビュー案件状態管理。

---

## F1 案件状態_取得

| 順 | ノード | 設定 |
|---|---|---|
| 1 | When an agent calls the flow | 入力(テキスト): RITM番号。説明「案件の RITM 番号(RITM1234567 の形)」 |
| 2 | 変数 > 変数を初期化する。名前: 項目ID | 種類=文字列、値=(空) |
| 3 | 変数 > 変数を初期化する。名前: 状態テキスト | 種類=文字列、値=`未作成` |
| 4 | コネクタ > SharePoint > 複数の項目の取得。名前: 行の取得 | サイト、リスト名、フィルター クエリ=`Title eq '`[RITM番号]`'`(トークンの前後に半角の ' を打つ)、上位件数=1 |
| 5 | Loop(それぞれに適用)。対象=行の取得 の value | 中に 6 と 7 を置く |
| 6 | 変数 > 変数の設定。項目ID | 値=[ID](行の取得の ID トークン) |
| 7 | 変数 > 変数の設定。状態テキスト | 値=下の「状態テキストの雛形」をそのまま貼り、[ ] の所をトークンに置き換える |
| 8 | Respond to the agent | 出力(テキスト): 項目ID=[変数 項目ID]、状態テキスト=[変数 状態テキスト] |

状態テキストの雛形(7 の値。改行もそのまま):
```
【案件状態】RITM: [RITM番号(Title)]
- 項目ID: [ID]
- 案件名: [案件名]
- 状態: [状態 Value] ｜ 現在の工程: [現在の工程 Value]
- 対象環境: [対象環境 Value] ｜ CSP: [CSP Value]
- 完了した工程: [完了した工程]
- 次の操作: [次の操作]
- Teamsスレッド: team=[Teams_team] ｜ channel=[Teams_channel] ｜ message=[Teams_message]
- スレッドリンク: [スレッドリンク]
- 案件フォルダ: [案件フォルダ]
- 票リンク: [票リンク]
- 最終エラー: [最終エラー] ｜ 再試行回数: [再試行回数]
- 更新: [更新日時] [更新者 DisplayName]
```
- 選択肢の列は「○○ Value」のトークンを選ぶ(「○○」だけだとオブジェクトになる)
- 行が無いときは Loop が回らないので、状態テキストは `未作成`、項目ID は空のまま返る(これが「未登録」の判定になる)
- テスト: RITM番号=(List に手で入れた RITM0000000)→ 状態テキストにその行が入る。存在しない RITM → 未作成

## F2 案件状態_作成

| 順 | ノード | 設定 |
|---|---|---|
| 1 | When an agent calls the flow | 入力(テキスト): RITM番号 / 案件名 / 案件フォルダ / Teams_team / Teams_channel / Teams_message / スレッドリンク(説明はそれぞれ「List の同名の列に入れる値。無ければ空」) |
| 2 | コネクタ > SharePoint > 項目の作成。名前: 行の作成 | サイト、リスト名、RITM番号(Title)=[RITM番号]、案件名=[案件名]、案件フォルダ=[案件フォルダ]、Teams_team/Teams_channel/Teams_message/スレッドリンク=各トークン。状態=進行中、現在の工程=Mermaid化、対象環境=未定、CSP=未定、完了した工程=`なし`、再試行回数=0 |
| 3 | Respond to the agent | 出力: 項目ID=[行の作成 の ID](出力の種類は 数値。選べなければテキスト) |

- 同じ RITM番号 で2回実行すると、List の一意制約でエラーになる(= 重複を防ぐ仕組み。Agent は 取得 で無いときだけ 作成 を呼ぶ)
- テスト: RITM番号=RITM0000001 ほかは空 → List に行ができ、項目ID が返る。テスト後に行を削除

## F3 案件状態_更新

| 順 | ノード | 設定 |
|---|---|---|
| 1 | When an agent calls the flow | 入力: 項目ID(数値)、RITM番号 / 案件名 / 状態 / 現在の工程 / 次の操作 / 完了した工程 / 対象環境 / CSP / Teams_team / Teams_channel / Teams_message / スレッドリンク / 案件フォルダ / 票リンク / 最終エラー(以上テキスト)、再試行回数(数値)。説明は「scripts/status_tool.py の出力の同名キーの値をそのまま」 |
| 2 | コネクタ > SharePoint > 項目の更新。名前: 行の更新 | サイト、リスト名、ID=[項目ID]、RITM番号(Title)=[RITM番号]、他の列=同名のトークン(選択肢の列は「○○ Value」の欄にトークン) |
| 3 | Respond to the agent | 出力(テキスト): 結果=`更新済み `[行の更新 の RITM番号(Title)] |

- 入力名は status_tool.py の出力キーと完全に同じにする(Agent がキー名で対応づける)
- テスト: F2 で作った行の 項目ID と、`状態=進行中 現在の工程=抽出 次の操作=『ホスティング判定して』 完了した工程=Mermaid化(完了)｜抽出(完了) 対象環境=Hub CSP=AWS 再試行回数=0`(他は空)→ List の行が書き換わる

## F4 アーキテクチャレビュー票_Excel作成

| 順 | ノード | 設定 |
|---|---|---|
| 1 | When an agent calls the flow | 入力(テキスト): RITM番号 / CSP / rowsJson / fileName。説明: RITM番号「案件のRITM番号」、CSP「AWS / Azure / GCP」、rowsJson「Excel に書く行の JSON 配列(1行)」、fileName「作成する Excel のファイル名」 |
| 2 | コネクタ > SharePoint > ファイル コンテンツの取得(パスを使用)。名前: 雛形取得 | サイト、ファイル パス=01_参照データ/【案件名】(RITMxxxxxxx)アーキテクチャレビュー票(CSP名).xlsx(ピッカーで選ぶ)、コンテンツ タイプの推測=いいえ |
| 3 | コネクタ > SharePoint > ファイルの作成。名前: 票ファイル作成 | サイト、フォルダーのパス=…/New experience/送付用、ファイル名=[fileName]、ファイル コンテンツ=[雛形取得 の ファイル コンテンツ] |
| 4 | コネクタ > Excel Online (Business) > スクリプトの実行。名前: 行追加 | 場所=Group - JP CMS、ドキュメント ライブラリ=Documents、ファイル=[票ファイル作成 の Id]、スクリプト=アーキテクチャレビュー_行追加、rowsJson=[rowsJson] |
| 5 | コネクタ > SharePoint > ファイル プロパティの取得。名前: 票ファイル情報 | サイト、ライブラリ名=ドキュメント、ID=[票ファイル作成 の Item Id] |
| 6 | Respond to the agent | 出力(テキスト): result=[行追加 の result]、fileLink=[票ファイル情報 の Link]、fileName=[fileName] |

- テスト: RITM番号=RITM1234567、CSP=AWS、fileName=【案件名】(RITM1234567)アーキテクチャレビュー票(AWS).xlsx、rowsJson=`[{"No.":"1","ステータス":"New","環境":"DCS共通","対応区分":"対応必須","カテゴリ":"テスト","指摘概要":"テスト","指摘内容":"テスト行","対応ガイドライン・参考資料":""}]` → 送付用に Excel ができ 1 行書かれ、fileLink に URL が入る
- 行追加 の result がオブジェクトで返る場合は、Respond の result にその中の値(result)を選ぶ
- Office スクリプト「アーキテクチャレビュー_行追加」が一覧に出ないときは、スクリプトを保存したアカウントでサインインし直す
- 雛形のファイル名・送付用のパスを変えたら 2・3 を直す
