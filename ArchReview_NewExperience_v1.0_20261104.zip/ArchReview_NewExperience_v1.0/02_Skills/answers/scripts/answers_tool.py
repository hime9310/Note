# -*- coding: utf-8 -*-
"""answers 用: 回答済みアーキテクチャレビュー票の場所の特定・行の整形・検算。

使い方:
  locate : python scripts/answers_tool.py locate --thread work/thread.json [--ritm RITM1234567]
           → スレッドの添付から回答済み票(xlsx)を選び、Excel ツールに渡す 場所(site_url) / ライブラリ / パス を作る
  prepare: python scripts/answers_tool.py prepare --rows work/answer_rows.json
           → 票の行を「No｜環境｜指摘概要｜回答内容｜回答者｜回答日」に整え、回答内容が空欄の行を 未回答 にする
  verify : python scripts/answers_tool.py verify --result work/06_answers.md --rows work/answer_rows.json
           → 【回答回収結果】の 回答済み + 未回答 + 要確認 = 全行数 か(R4)
"""
import argparse
import os
import re
import sys
from urllib.parse import unquote, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, get, parse_sections, read_input, read_json_input, rows_from_json, section, split_fields  # noqa: E402


def cmd_locate(a):
    """teams_to_text.py の出力(attachments)から、いちばん新しい回答済み票(xlsx)を選ぶ。"""
    obj = read_json_input(a.thread)
    atts = obj.get("attachments", []) if isinstance(obj, dict) else obj
    xlsx = [x for x in atts if str(x.get("name", "")).lower().endswith((".xlsx", ".xlsm"))]
    if a.ritm:
        xlsx = [x for x in xlsx if a.ritm in x.get("name", "")] or xlsx   # RITM 番号入りを優先
    xlsx = [x for x in xlsx if "レビュー票" in x.get("name", "")] or xlsx   # 「レビュー票」入りを優先
    xlsx.sort(key=lambda x: x.get("at", ""))
    if not xlsx:
        dump({"found": False, "reason": "スレッドに xlsx の添付がありません", "candidates": [x.get("name") for x in atts]})
        return
    x = xlsx[-1]
    # 添付 URL(https://xxx.sharepoint.com/sites/Site/Shared Documents/folder/file.xlsx)を サイト / ライブラリ / 相対パス に分ける
    p = urlparse(x.get("url", ""))
    path = unquote(p.path)
    m = re.match(r"^(/sites/[^/]+|/teams/[^/]+)?/([^/]+)/(.*)$", path)
    site_url = f"{p.scheme}://{p.netloc}{m.group(1) or ''}" if m else ""
    dump({"found": True, "name": x.get("name"), "by": x.get("by"), "at": x.get("at"), "url": x.get("url", ""),
          "site_url": site_url, "library": m.group(2) if m else "", "file_path": "/" + m.group(3) if m else "",
          "library_hint": "Shared Documents は画面上の『ドキュメント』(Documents)", "table": "T_アーキテクチャレビュー票"})


def rows_prepared(rows):
    """Excel の行を必要な列だけに整え、回答内容が空欄なら 未回答 にする。"""
    out = []
    for r in rows:
        if not isinstance(r, dict) or not get(r, "No.", "No").strip():
            continue
        ans = get(r, "回答内容", "回答").strip()
        out.append({"no": get(r, "No.", "No").strip(), "env": get(r, "環境"), "summary": get(r, "指摘概要"),
                    "kind": get(r, "対応区分"), "answer": ans, "answered_by": get(r, "回答者"), "answered_at": get(r, "回答日"),
                    "status": "未回答" if not ans else "要仕分け(回答済み or 要確認)"})
    return out


def cmd_prepare(a):
    rows = rows_prepared(rows_from_json(read_json_input(a.rows)))
    dump({"total": len(rows),
          "unanswered": [r["no"] for r in rows if r["status"] == "未回答"],
          "to_classify": [r["no"] for r in rows if r["status"] != "未回答"],
          "rows": rows,
          "lines": [f"- {r['no']}｜{r['env']}｜{r['summary']}｜{r['answer'] or '(空欄)'}｜{r['answered_by']}｜{r['answered_at']}" for r in rows],
          "rule": "回答内容が空欄 → 未回答。文があるものは LLM が 回答済み(内容あり)/ 要確認(不十分・質問返し・前提変更)に仕分ける。構成図の修正・再提出の記述があれば 構成図修正: あり"})


def cmd_verify(a):
    """【回答回収結果】の3つの節の行数の合計 = 票の行数 か(R4)。抜けた No も出す。"""
    rows = rows_prepared(rows_from_json(read_json_input(a.rows)))
    sec = parse_sections(read_input(a.result))
    counts, nos_in = {}, set()
    for key in ("未回答", "要確認", "回答済み"):
        lines = [x for x in section(sec, key) if x.strip() and x.strip() != "なし"]
        counts[key] = len(lines)
        for x in lines:
            nos_in.add(split_fields(x)[0].replace("No.", "").strip())
    total = sum(counts.values())
    missing = [r["no"] for r in rows if r["no"] not in nos_in]
    dump({"rows_total": len(rows), "counts": counts, "sum": total, "missing_no": missing,
          "r4_line": f"R4: {total} / {len(rows)}", "ok": total == len(rows) and not missing})


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("locate"); p.add_argument("--thread", required=True); p.add_argument("--ritm")
    p = sub.add_parser("prepare"); p.add_argument("--rows", required=True)
    p = sub.add_parser("verify"); p.add_argument("--result", required=True); p.add_argument("--rows", required=True)
    a = ap.parse_args()
    {"locate": cmd_locate, "prepare": cmd_prepare, "verify": cmd_verify}[a.cmd](a)


if __name__ == "__main__":
    main()
