# -*- coding: utf-8 -*-
"""hosting / answers / knowledge 用: Teams のツール返り値(親投稿の詳細 + 返信の一覧。JSON)をスレッド本文のテキストにする。

使い方: python scripts/teams_to_text.py --parent work/teams_parent.json --replies work/teams_replies.json [--out work/03_thread.md]
出力(JSON): {"posts": 投稿数, "text": "<スレッド本文>", "attachments": [{"name","url","by","at","post"}], "csp_hint": "AWS|Azure|GCP|不明"}
--out を付けると、案件フォルダに保存する用の Markdown(03_thread.md の中身)も書き出す。
返り値の JSON の形は問わない(body.content を持つものを投稿とみなして集める)。
"""
import argparse
import html
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, read_json_input  # noqa: E402


def strip_html(s):
    """投稿本文の HTML をプレーンテキストにする(改行・箇条書きは残す)。"""
    if not s:
        return ""
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"</(p|div|li|tr|h\d)>", "\n", s, flags=re.I)
    s = re.sub(r"<li[^>]*>", "- ", s, flags=re.I)
    s = re.sub(r"<attachment[^>]*>.*?</attachment>", "", s, flags=re.I | re.S)  # 添付の目印タグは消す
    s = re.sub(r"<[^>]+>", "", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t ]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def find_messages(obj, found):
    """JSON の中から body.content を持つオブジェクト(=投稿)を全部集める。"""
    if isinstance(obj, dict):
        if isinstance(obj.get("body"), dict) and "content" in obj["body"]:
            found.append(obj)
            return
        for v in obj.values():
            find_messages(v, found)
    elif isinstance(obj, list):
        for v in obj:
            find_messages(v, found)


def author(m):
    """投稿者の表示名。"""
    fr = m.get("from") or {}
    if isinstance(fr, dict):
        for k in ("user", "application", "device"):
            if isinstance(fr.get(k), dict) and fr[k].get("displayName"):
                return fr[k]["displayName"]
    return m.get("fromDisplayName") or m.get("userDisplayName") or "(不明)"


def attachments(m):
    """投稿の添付(名前・URL)。"""
    out = []
    for a in m.get("attachments") or []:
        if isinstance(a, dict):
            out.append({"name": a.get("name") or "", "url": a.get("contentUrl") or a.get("content_url") or ""})
    return out


def to_posts(parent_obj, replies_obj):
    """親投稿 → 返信(時刻順)の一覧にする。"""
    posts = []
    for src, kind in ((parent_obj, "parent"), (replies_obj, "reply")):
        found = []
        find_messages(src, found)
        for m in found:
            posts.append({
                "kind": kind,
                "at": m.get("createdDateTime") or m.get("lastModifiedDateTime") or "",
                "by": author(m),
                "text": strip_html((m.get("body") or {}).get("content", "")),
                "attachments": attachments(m),
            })
    posts.sort(key=lambda p: (0 if p["kind"] == "parent" else 1, p["at"]))
    return posts


def csp_hint(text):
    """本文に出てくる CSP 名から、CSP の手がかりを返す(1つに絞れなければ '不明' か 'AWS/Azure')。"""
    t = text.lower()
    hits = [k for k, ok in (("AWS", bool(re.search(r"\baws\b|amazon", t))),
                            ("Azure", "azure" in t),
                            ("GCP", bool(re.search(r"\bgcp\b|google cloud", t)))) if ok]
    return hits[0] if len(hits) == 1 else ("不明" if not hits else "/".join(hits))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--parent", help="Teams_親投稿取得 の返り値(JSON)")
    ap.add_argument("--replies", help="Teams_返信一覧取得 の返り値(JSON)")
    ap.add_argument("--out", help="03_thread.md として保存する本文の書き出し先")
    a = ap.parse_args()

    posts = to_posts(read_json_input(a.parent) if a.parent else None,
                     read_json_input(a.replies) if a.replies else None)

    # 本文: [番号] 投稿者 日時 / 本文 / (添付: 名前)
    lines, atts = [], []
    for i, p in enumerate(posts, 1):
        lines.append(f"[{i}] {p['by']} {p['at'][:16].replace('T', ' ')}".strip())
        lines.append(p["text"] or "(本文なし)")
        for at in p["attachments"]:
            lines.append(f"(添付: {at['name']})")
            atts.append({"name": at["name"], "url": at["url"], "by": p["by"], "at": p["at"], "post": i})
        lines.append("")
    text = "\n".join(lines).strip()
    result = {"posts": len(posts), "text": text, "attachments": atts, "csp_hint": csp_hint(text)}

    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write("【Teamsスレッド】状態: 完了\n")
            f.write(f"- 投稿数: {len(posts)} ｜ 添付: {len(atts)}件 ｜ CSPの手がかり: {result['csp_hint']}\n")
            f.write("## 本文\n" + text + "\n")
            if atts:
                f.write("## 添付\n")
                for at in atts:
                    f.write(f"- {at['name']}｜{at['by']}｜{at['at'][:10]}｜{at['url']}\n")
        result["out"] = a.out
    dump(result)


if __name__ == "__main__":
    main()
