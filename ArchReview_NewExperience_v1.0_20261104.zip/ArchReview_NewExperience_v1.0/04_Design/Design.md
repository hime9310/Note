# アーキテクチャレビューAgent 設計書(New experience 版 v1.0 / 2026-11-04)

- 位置づけ: 新UI(GitHub Copilot ハーネス)でゼロから作り直した版。クラシック版の業務設計(工程・判定ルール・出力形式・指示語)は引き継ぎ、作り(1体+スキル、直接アクション、エージェント フロー、Python、SharePoint 保存)は新しい。案件の状態は MS の推奨どおり SharePoint List に持つ
- 作る手順は 00_Setup/(Setup.md・List.md・Tools.md・Flows.md)。この文書は「なぜそうなっているか」と「中身の仕様」

---

## 1. 方針

| # | 方針 | 内容 |
|---|---|---|
| 1 | エージェント1体+スキル8本 | 親子構造をやめる(子に材料が渡らない・表示が二重になる問題が構造的に消える)。接続エージェント・メモリは使わない |
| 2 | 役割分担を固定 | LLM=判断と文章 / ツール・フロー=M365 との入出力 / Python=取ってきたデータの処理(絞り込み・照合・検算・状態の値作り)。LLM に数えさせない・推測させない |
| 3 | 状態は List、成果物はファイル | 案件の状態(どこまで・環境・CSP・Teams・エラー)は SharePoint List「アーキテクチャレビュー案件状態管理」の1行。成果物(md / Excel)は案件フォルダ。Eng は List のビューで全案件を一覧できる |
| 4 | List の読み書きはエージェント フロー | 取得 / 作成 / 更新 の3本。LLM は List の列を直接触らず、status_tool.py が作った値をフローに渡すだけ |
| 5 | ツールは直接アクション | SharePoint・Excel Online・Teams の12本。フローはバイナリや List を扱う4本だけ。MCP・クラシック版のフローは使わない |
| 6 | 参照データは md と原本 Excel | 観点表・KO要件・Salus・Mermaid規則は md を読む。票のテンプレートは原本 xlsx(テーブル)を読む。列名のゆれはスクリプトが吸収し、ファイルは書き換えない |
| 7 | Teams スレッドはリンクで指定 | 最初の指示でリンクを貼り、Python が3つの ID を取り出して List に保存。以降はその ID で親投稿と返信を読む |
| 8 | ナレッジは背景知識だけ | dcs-env-definitions.md を登録し、判定・チェックの前に確認させる。分母になる一覧はツールで取る。Web 検索は外す |
| 9 | 出力はすべて案 | 確定・承認・利用者連絡・ナレッジ登録は人。Teams への投稿はしない |

---

## 2. 全体構成

```
[Eng] プレビュー(PoC) / Teams(発行後)
  │ 指示語(クラシック版と同じ)。初回は 画像 + Teams スレッドのリンク
  ▼
[DTG_Architecture_Review_Agent](New experience・1体・プライマリ言語 Japanese・ソリューション CMS_Eng_ArchitectureReview)
  ├ 指示文: 役割・厳守8・案内文・案件フォルダ・案件状態(List)・対応表・出力形式・共通厳守事項
  ├ スキル(zip = SKILL.md + scripts/*.py + references/)
  │   diagram / extract / hosting / check / sheet / answers / knowledge / status
  ├ ツール(直接アクション12本。00_Setup/Tools.md)
  │   SharePoint: 参照_構成図チェック観点取得 / 参照_ノックアウト要件取得 / 参照_SalusStatus取得 / 参照_Mermaid生成規則取得 / 案件_成果物取得 / 案件_成果物保存
  │   Excel:      レビュー票テンプレート_AWS_行取得 / _Azure / _GCP / 回答済みレビュー票_行取得
  │   Teams:      Teams_親投稿取得 / Teams_返信一覧取得
  ├ エージェント フロー(4本。00_Setup/Flows.md)
  │   案件状態_取得 / 案件状態_作成 / 案件状態_更新 / アーキテクチャレビュー票_Excel作成
  ├ ナレッジ: 社内環境の説明(dcs-env-definitions.md)
  └ あいさつメッセージ・推奨プロンプト(設定)

[SharePoint] JP CMS
  List: アーキテクチャレビュー案件状態管理(1案件=1行)
  New experience/
    01_参照データ/  観点表.md / KO要件.md / salus_status.md / Mermaid生成規則.md / dcs-env.md / テンプレート xlsx(AWS/Azure/GCP) / 雛形(CSP名).xlsx
    02_案件データ/RITM番号/  01_mermaid.md, 02_inventory.md, 03_thread.md, 03_hosting.md, 04_check.md, 05_edit.md, 05_ticket.json, 06_answers.md, 06_answer_rows.json, 07_knowledge.md (+ _1st 退避)
    送付用/  【案件名】(RITM)アーキテクチャレビュー票(CSP).xlsx
```

1工程の流れ(どのスキルも同じ): 案件状態_取得(List) → 成果物の取得(ファイル) → 参照データ・Teams(ツール) → スクリプトで絞り込み・下ごしらえ → LLM が判定・文章 → スクリプトで検算 → 案件_成果物保存(ファイル) → status_tool.py → 案件状態_更新(List) → 返答(【名称】状態: … → --- → 次の操作)。

---

## 3. 案件状態(SharePoint List)

### 3.1 列(00_Setup/List.md に作り方)
| 表示名(内部名) | 入るもの | 書く所 |
|---|---|---|
| RITM番号(Title。一意) | 案件の鍵 | 作成時 |
| 案件名(CaseName) | 任意の名前(Eng が後から入れてもよい) | 作成時 / Eng |
| 状態(Status) | 進行中 / 要確認 / 失敗 / 未着 / 完了 | 各工程の最後(status_tool.py) |
| 現在の工程(CurrentStep) | Mermaid化 / 抽出 / 判定 / 1次チェック / 票作成 / Excel / 回答回収 / 再判定 / 2次チェック / ナレッジ文案 | 同上 |
| 次の操作(NextAction) | 直近の成果物の次の操作の1番 | 同上 |
| 完了した工程(DoneSteps) | 工程名(状態)｜…(同じ工程をやり直すと置き換わる) | 同上 |
| 対象環境(TargetEnv)/ CSP | Hub / Disconnected / 未定、AWS / Azure / GCP / 未定 | 抽出(CSP)・判定(環境)・status(手動指定) |
| Teams_team / Teams_channel / Teams_message / スレッドリンク | スレッドの3つの ID とリンク | diagram(初回)・status(スレッド設定) |
| 案件フォルダ / 票リンク | 成果物の場所、作った Excel のリンク | diagram / sheet(Excel生成) |
| 最終エラー / 再試行回数 | 失敗の理由 / 失敗後にやり直して成功した回数 | status_tool.py |

### 3.2 状態の決まり方(status_tool.py)
- 工程の結果 完了 → 状態=進行中(工程がナレッジ文案なら 完了)。要確認 → 要確認。失敗 → 失敗(最終エラーに理由)。未着 → 未着
- 失敗の後に同じ工程(または次の工程)が成功したら 再試行回数+1、最終エラーを空に戻す
- 「環境は○○で進めて」などの値の変更は、状態・工程を変えず、その列だけ書き換える

### 3.3 フローの役割分担
| フロー | いつ | 中身 |
|---|---|---|
| 案件状態_取得 | 全工程の最初 | Title eq 'RITM' で1件取り、状態テキスト(人が読める12行)と項目IDを返す。無ければ「未作成」 |
| 案件状態_作成 | Mermaid化で未作成のときだけ | 行を作り項目IDを返す。重複は List の一意制約が防ぐ |
| 案件状態_更新 | 全工程の最後 | 項目IDの行を、status_tool.py の出力(列と同名のキー)で書き換える |

「無ければ作成・あれば更新」の分岐をフローに持たせない(式が要る)。分岐は Agent 側で「取得の結果が未作成なら作成」と1行で済ませる。

---

## 4. スキル(02_Skills)

### 4.1 zip の構成と SKILL.md の読み方
```
<skill>_v1.0.zip
└ <skill>/
   ├ SKILL.md      … 先頭3行(name / description)が起動条件、本文が手順
   ├ scripts/*.py  … このスキルが使う Python(標準ライブラリだけ)
   └ references/   … 参考表(knowledge だけ)
```
- description に指示語を書いてあり、ハーネスはこれを見てスキルを起動する。指示語を変えるときは description と指示文の対応表を同時に直す
- 本文の節は共通: 役割 / 処理名 / 材料の取得 / 手順 / 出力 / 保存 / 次の操作 / 個別厳守。ツール・フローは本文に「ツール『名前』」と文字で書いて呼ぶ

### 4.2 一覧
| スキル | 指示語 | 読む材料 | ツール / フロー | スクリプト | 出力 → 保存先 |
|---|---|---|---|---|---|
| diagram | RITMxxx 添付した構成図をMermaid化して(+画像、+リンク)/ 指摘 | 添付画像、Mermaid生成規則.md | 案件状態_取得、案件状態_作成、参照_Mermaid生成規則取得、案件_成果物保存、案件状態_更新 | parse_teams_link、status_tool | 【確定図】→ 01_mermaid.md、List の行(新規) |
| extract | 構成図情報を抽出して / 指摘 | 01_mermaid.md | 案件状態_取得、案件_成果物取得・保存、案件状態_更新 | check_r0、status_tool | 【構成図一覧】→ 02_inventory.md |
| hosting | ホスティング判定して / 再判定して / 指摘 | 02、Teams スレッド、KO要件、Salus、(06)、ナレッジ | 案件状態_取得、Teams×2、参照_ノックアウト要件取得、参照_SalusStatus取得、案件_成果物取得・保存、案件状態_更新 | teams_to_text、check_hosting、salus_match、status_tool | 【ホスティング判定結果】→ 03_hosting.md、03_thread.md(再判定で旧→03_hosting_1st.md) |
| check | 構成図チェックして / 2次の構成図チェックして / 指摘 | 01、02、(03、03_thread、06)、観点表、ナレッジ | 案件状態_取得、参照_構成図チェック観点取得、案件_成果物取得・保存、案件状態_更新 | filter_points、check_count、status_tool | 【構成図チェック結果】→ 04_check.md(2次で旧→04_check_1st.md) |
| sheet | 編集指示を作成して / 見直して / 指摘 / アーキテクチャレビュー票を作成して | 04、(03、05、06)、テンプレート行 | 案件状態_取得、レビュー票テンプレート_(CSP)_行取得、案件_成果物取得・保存、アーキテクチャレビュー票_Excel作成、案件状態_更新 | build_ticket、status_tool | 【編集指示】→ 05_edit.md、05_ticket.json /【Excel結果】→ 送付用 xlsx、List の票リンク |
| answers | 回答を回収して | Teams スレッド(返信の添付)、回答済み票の行、(05) | 案件状態_取得、Teams×2、回答済みレビュー票_行取得、案件_成果物取得・保存、案件状態_更新 | teams_to_text、answers_tool、status_tool | 【回答回収結果】→ 06_answers.md、06_answer_rows.json |
| knowledge | ナレッジ文案を作成して / 指摘 | 03、(02、04、05、06、03_thread) | 案件状態_取得、案件_成果物取得・保存、(Teams×2)、案件状態_更新 | (teams_to_text)、status_tool | 【ナレッジ文案】→ 07_knowledge.md、List の状態=完了 |
| status | RITMxxx の状況 / 環境は○○で進めて / CSPは○○で進めて / スレッドは <リンク> | List | 案件状態_取得、案件状態_更新 | status_tool、parse_teams_link | 状態テキストを返す / List の列だけ変更 |

### 4.3 各スキルの要点
- diagram: 画像を Mermaid と注釈情報に書き起こす。本文はクラシック版の Mermaid化指示文そのまま。前段で RITM・画像・リンクを確認し、List に行が無ければ作る
- extract: 確定図から「事実の一覧」だけを作る(判定しない)。check_r0.py でノード数と一覧の件数の一致を検算(R0)
- hosting: ノックアウト要件を全行判定し、Salus 照合は salus_match.py で機械的に。check_hosting.py で全行数との一致を検算。不確実なら「判定不能(見込み)」で Eng に返す。再判定は回答(06_answers.md)と返信を根拠に加える
- check: filter_points.py が観点表を 環境・CSP・1次/2次・トリガー で絞って下書きを作り、LLM は [ ] を埋めるだけ。check_count.py で件数を検算
- sheet: build_ticket.py prepare がテンプレート行を仕分けの候補にし、LLM が ①流用 ②添削 ③追記 ④不要 を決めて 05_ticket.json に書く。final が最終行と期待件数を作り、フローが Excel を生成。検算 R2・R3
- answers: スレッド返信の添付(回答済み票)を answers_tool.py locate で特定し、行を 回答済み / 未回答 / 要確認 に仕分け(R4)
- knowledge: 成果物から技術相談ナレッジ List の 16 項目(references/knowledge_fields.md)の文案を作る。登録は人
- status: List の行を読んで返す、または 対象環境・CSP・Teams の値だけ書き換える(工程は行わない)

### 4.4 共通スクリプト
| スクリプト | 役割 | 同梱先 |
|---|---|---|
| md_tables.py | ツールの返り値(md / JSON / base64 包み)を読み、表・節・列名のゆれを扱う共通部品 | 全スキル |
| status_tool.py | 案件状態_取得 の状態テキストを読み、案件状態_更新 に渡す値(JSON)を作る。状態・再試行回数の決まり方は 3.2 | 全スキル |
| teams_to_text.py | Teams の返り値(JSON)から本文・投稿者・添付を取り出し、03_thread.md の中身にする | hosting / answers / knowledge |
| parse_teams_link.py | スレッドのリンクから team / channel / message を取り出す(返信リンクでも親投稿の ID) | diagram / status |
スキル固有: check_r0(extract)、check_hosting・salus_match(hosting)、filter_points・check_count(check)、build_ticket(sheet)、answers_tool(answers)。すべて標準ライブラリだけ、入力はファイルパス、出力は JSON。

---

## 5. 工程と検算

| # | 工程 | 指示語 | 書く(ファイル / List) | 検算 |
|---|---|---|---|---|
| 1 | Mermaid化 | RITMxxx 添付した構成図をMermaid化して | 01 / 行の作成、Teams の ID | ― |
| 2 | 抽出 | 構成図情報を抽出して | 02 / CSP | R0: サービス一覧 + 除外 = ノード総数(check_r0) |
| 3 | 判定 / 再判定 | ホスティング判定して / 再判定して | 03_thread、03(旧→_1st)/ 対象環境 | 非該当 + 個別 = KO 全行数、TRUE + FALSE + 未照合 = サービス件数(check_hosting、salus_match) |
| 4 | 1次 / 2次チェック | 構成図チェックして / 2次の構成図チェックして | 04(旧→_1st) | 6区分の合計 = 適用行数、[ ] の残り 0(filter_points、check_count) |
| 5 | 編集指示 | 編集指示を作成して / 見直して | 05_edit、05_ticket | R2: ①+②+④+⑤ = テンプレート全行数(build_ticket final) |
| 6 | Excel 作成 | アーキテクチャレビュー票を作成して | 送付用 xlsx / 票リンク | R3: 書き込み件数 = ①+②+③(build_ticket final と Excel作成 の result) |
| 7 | 回答回収 | 回答を回収して | 06、06_answer_rows、03_thread | R4: 回答済み + 未回答 + 要確認 = 全行数(answers_tool verify) |
| 8 | ナレッジ文案 | ナレッジ文案を作成して | 07 / 状態=完了 | ― |
| ― | 状況 / 値の変更 / スレッド設定 | RITMxxx の状況 / 環境は○○で進めて / スレッドは <リンク> | List の列だけ | ― |

- 直前の成果物への指摘は、直前のスキルを「修正」で再実行し同じファイルを上書き(ツール・スクリプトは再実行しない。hosting の修正だけ Teams を再取得)
- 2次チェックは チェックタイミング=2次(または両方)の観点だけ。構成図が直って戻ったら Mermaid化からやり直す

---

## 6. 出力形式(クラシック版と同じ)

| 成果物 | 1行目 | 見出しの順 |
|---|---|---|
| 【確定図】 | 状態: 完了 / 要確認 | Mermaid → 注釈情報 → 要確認 |
| 【構成図一覧】 | 状態: 完了 / 要確認 | 基本情報 → サービス一覧 → 除外ノード → NW情報 → 注釈情報 → 記載なし・方向不明 → 要確認 → 検算 |
| 【ホスティング判定結果】 | 状態: 完了 / 要確認 | 判定 → ノックアウト要件 照合 → Salus照合 → 要確認 → ヒアリング文 → 検算 |
| 【構成図チェック結果】 | 状態: 完了 / 要確認 | 結論 → 対応が必要な観点 → 問題なし・対象外 → 利用者への確認・依頼 → 観点ごとの判定 → 要確認 → 検算 |
| 【編集指示】 | 状態: 完了 / 要確認 | 条件 → ⑤ → ① → ② → ③ → ④ → 検算 → 要確認 |
| 【Excel結果】 | 状態: 完了 / 要確認 | 書き込み件数 / ファイル / リンク / 検算R3 |
| 【回答回収結果】 | 状態: 完了(すべて解消) / 要確認 / 未着 | 集計 → 未回答 → 要確認 → 回答済み → 検算 |
| 【ナレッジ文案】 | 状態: 完了 / 要確認 | 文案(16行) → 要確認 |
| 【案件状態】 | RITM: … | 項目ID / 案件名 / 状態・現在の工程 / 対象環境・CSP / 完了した工程 / 次の操作 / Teamsスレッド / リンク類 / 最終エラー・再試行回数 / 更新 |
| 【案内】 | 状態: 待機 | 挨拶1行 → 次の操作2つ |

画面の表示: 返答は『【』から始め、成果物の全文 → 「---」 → 「次の操作:」1./2.。前置き・英語・JSON・ツールの生データを出さない(指示文の厳守8・出力形式)。

---

## 7. 観点表(T_Points)の読み方(check の中身)

- 絞り込み(Python): 有効=1 → 環境 ∈ {DCS共通, DCS <対象環境>} → 対象CSP ∋ CSP または 共通 → チェックタイミング = 1次/2次 または 両方
- トリガー(Python): 常時=実施 / 存在=トリガー対象のサービス(「/」区切り。@T_GlobalServices はその表の CSP のサービス)が【構成図一覧】にあれば実施、無ければ 対象外(利用なし) / 回答=「項目=値」に当たる回答が 06_answers.md(無ければ 03_thread.md)にあれば LLM が判定、無ければ 対象外(回答なし) / 存在かつ回答=両方
- 判定(LLM): 判定値は 記載あり / 記載なし / 方向不明 / 判定不能 / 対象外 の5語。区分は 区分表(判定値→記号)。無い判定値は B。表示名 A=問題なし / B=Eng目視確認 / C=利用者へ依頼 / D=票で確認 / E=対象外
- 指摘概要(票との対応): 観点の「指摘概要」列(共通: 文 / AWS: 文 …)をその CSP で選び、チェック結果の各行に (票: 文) として残す。sheet はこの文+環境でテンプレート行を探し、あれば ②添削、無ければ ③追記

---

## 8. 直すときの目安

| 変えたいこと | 直す場所 |
|---|---|
| 指示語を増やす・変える | SKILL.md の description と本文、指示文の対応表 |
| 判定の基準・区分 | 観点表・ノックアウト要件一覧(参照データ側。スキルは変えない) |
| 出力の見出し・行の形 | 該当スキルの「出力」節(検算スクリプトが見出しを読むので、同じ名前の行は残す) |
| ツール名・フロー名 | 指示文と全 SKILL.md(Tools.md / Flows.md の名前に合わせる) |
| List の列を足す | List.md → Flows.md(F1 の雛形、F2・F3 の入力)→ status_tool.py の FIELDS → 指示文の「案件状態」節 |
| Excel の列・テーブル名 | build_ticket.py / answers_tool.py の列名、Office スクリプト |

---

## 9. 未決・後回し

- 回答済みレビュー票_行取得 で Teams 添付のパスが AI 入力で通るか(通らなければ案件フォルダに置く運用)
- 作業中の進捗表示(ハーネスの要約)が日本語になるか(厳守8 で指示。Japanese 設定でも英語の例あり。Teams での見え方で判断)
- 発行後の Teams で画像添付が Agent に渡るか
- クレジット: 1工程 60〜350、1周 2,000〜3,000 の見込み。流れの確認は Sonnet、判定の質は Opus で
- 一括モード、Mgmt 事前相談スキル、申し送り(サービス提供対象リソース一覧)
