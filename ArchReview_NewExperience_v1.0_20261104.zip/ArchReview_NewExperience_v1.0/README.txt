アーキテクチャレビューAgent New experience 版 v1.0 (2026-11-04)
ファイル名は半角英数字(中身は UTF-8)。

以前お渡しした ArchReview_NewExperience_v1.0_20261102 は破棄してください。本セットが、案件状態を SharePoint List で持つ設計(MS 推奨)に合わせた v1.0 です。

■ 読む順(作る人の順)
1. README.txt(このファイル)
2. 00_Setup/Setup.md … やることの手順。0 SharePoint(フォルダ・List) → 1 ソリューション → 2 エージェント → 3 指示文 → 4 スキル8本 → 5 エージェント フロー4本 → 6 ツール12本 → 7 ナレッジ・あいさつ → 8 動作確認 → 9 一連テスト → 10 困ったとき
   00_Setup/List.md  … List「アーキテクチャレビュー案件状態管理」の列(英語で作って表示名を日本語に)
   00_Setup/Tools.md … 直接アクション12本の設定値(名前・AI の説明・入力の固定/AI)
   00_Setup/Flows.md … エージェント フロー4本の作り方(ノード表。式は不要)
3. 01_Instructions/00_Agent.txt … エージェントの指示文(全文を貼る)
4. 02_Skills/ … スキル8本(zip と展開済みフォルダ)。diagram だけ Mermaid化の指示文を貼ってから zip にする
5. 03_Tests/TestSet.md … 一連テスト 18 項目 + 発行後の確認 + 安定性
6. 04_Design/Design.md … 設計書(方針・全体構成・List・フロー・スキル詳細・工程と検算・出力形式・観点表の読み方・直す場所・未決)

■ v1.0(11/02 版)からの変更
- 案件状態を 00_status.md(ファイル)から SharePoint List の1行に変更。読み書きはエージェント フロー(案件状態_取得 / 作成 / 更新)
- スキル status(状況確認・環境/CSP の指定・スレッド設定)を追加(7本 → 8本)
- ツール名変更: 案件_状態と成果物の取得 → 案件_成果物取得、案件_状態と成果物の保存 → 案件_成果物保存
- status_tool.py を List 用に作り直し。salus_match.py が Salus 一覧の列名(list_name など)を自動で探す
- Python 全体にコメントを付けて簡素化(動作は同じ。標準ライブラリだけ)
- 指示文: エージェント名 DTG_Architecture_Review_Agent、案内文、List の節
- Teams_返信一覧取得 のアクション名を明記(「チャネル メッセージの返信の一覧」。Get messages ではない)

■ 変えない前提
- 出力はすべて案。Teams への投稿はしない。Web 検索・推測はしない
- MCP は使わない。コネクタは SharePoint / Excel Online (Business) / Microsoft Teams だけ
- 参照データは読むだけ。案件フォルダは Agent が自動で作る
- 指示語はクラシック版と同じ
