﻿---
name: answers
description: 回答回収。指示語「回答を回収して」(処理名: 回答回収)のとき使う。Teams スレッドの返信に添付された回答済みアーキテクチャレビュー票(Excel)を見つけて行を読み、回答済み / 未回答 / 要確認 に仕分けた【回答回収結果】を 06_answers.md に保存する。回答の可否や解消の判断はしない(Engが行う)。
---

# 役割
回答済みのアーキテクチャレビュー票を取得して仕分け、【回答回収結果】を返す。回答の可否・解消の判断はしない。ホスティング判定・構成図チェック・票作成はしない。

# 材料の取得
1. ツール「案件_ファイル取得」で 00_status.md(work/00_status.md)を取得し、Teams スレッドの3つの ID と RITM を読む。05_edit.md があれば取得する(送付した票の行の照合用。無ければ無いまま進める)。
2. 指示文に『回答済みの票のパスは ○○』のようにファイルの場所が書かれていれば、手順 3 を飛ばしてその場所を使う。
3. ツール「Teams_親投稿取得」と「Teams_返信一覧取得」を1回ずつ実行し、返り値を work/teams_parent.json、work/teams_replies.json に保存する。`python scripts/teams_to_text.py --parent work/teams_parent.json --replies work/teams_replies.json > work/thread.json` を実行し、続けて `python scripts/answers_tool.py locate --thread work/thread.json --ritm <RITM>` で回答済み票(xlsx)の場所(site_url / library / file_path)を得る。found が false なら「【回答回収結果】状態: 未着」とだけ返し、保存しない。
4. ツール「票_回答行取得」を 場所=site_url、ドキュメント ライブラリ=library(既定ライブラリなら「ドキュメント」)、ファイル=file_path、テーブル=T_アーキテクチャレビュー票 で1回だけ実行し、返り値を work/answer_rows.json に保存する。エラーなら「状態: 失敗」「- 理由(ファイルの場所を『回答済みの票のパスは ○○』と入力してもらう)」の2行。
5. `python scripts/answers_tool.py prepare --rows work/answer_rows.json` を実行し、total(全行数)、unanswered(回答内容が空欄の No)、lines(No｜環境｜指摘概要｜回答内容｜回答者｜回答日)を得る。

# 手順
1. 全行数は prepare の total。
2. 全行を仕分ける: 回答内容が空欄 → [未回答](prepare の unanswered のとおり)。文があるもの → [回答済み](内容あり)または [要確認](不十分・質問返し・前提変更)。
3. 回答に構成図の修正・再提出の記述があれば「構成図修正: あり」、無ければ「なし」。
4. 状態: すべて回答済みで要確認が無ければ 完了(すべて解消)、それ以外は 要確認。
5. 検算R4: 出力を work/06_answers.md に書き、`python scripts/answers_tool.py verify --result work/06_answers.md --rows work/answer_rows.json` を実行する。ok が false なら counts / missing_no を直して再実行(最大2回)。合わなければ不一致のまま書き「## 要確認」に「検算不一致」と書く。

# 出力(見出しと順は固定。1項目1行の箇条書き)
【回答回収結果】状態: 完了(すべて解消) or 要確認 or 未着
## 集計
- 構成図修正: あり or なし
- RITM: / 対象ファイル: (name)
- 回答済みNN・未回答NN・要確認NN(全NN行)
## 未回答(No昇順・全件)
- No｜指摘概要
## 要確認
- No｜指摘概要｜何が不十分か
## 回答済み
- No｜指摘概要｜回答の要点
## 検算
- R4: NN / NN

# 保存(出力を作った後、返す前に行う)
1. ツール「案件_ファイル作成」で 06_answers.md(出力の全文)と 06_answer_rows.json(work/answer_rows.json の中身)を保存する。
2. `python scripts/status_tool.py --current work/00_status.md --ritm <RITM> --step "回答回収(状態)" --next "<下の該当する1番>"` の出力を 00_status.md として保存する。

# 次の操作(出力の後に指示文の出力形式で書く)
- 未着: 1. 回答済みの票をスレッドに添付 2. 添付後にもう一度『回答を回収して』
- 構成図修正あり: 1. 修正後の構成図を添付して『RITMxxx 添付した構成図をMermaid化して』 2. その後『構成図情報を抽出して』→『ホスティング再判定して』→『構成図チェックして』→『2次の構成図チェックして』の順に入力
- 構成図修正なし(要確認・未回答あり): 1.『ホスティング再判定して』 2. 続けて『2次の構成図チェックして』
- 完了(すべて解消): 1. 最終確認とクローズ 2. 済んだら『ナレッジ文案を作成して』

# 個別厳守
- R4の分母はツールが返した行数(No. が空の行は数えない)。Noを列挙するときは昇順・全件(範囲でまとめない)。
- 回答の可否・解消の判断はしない(Engが行う)。回答の要点は原文の要約で、評価を書かない。
