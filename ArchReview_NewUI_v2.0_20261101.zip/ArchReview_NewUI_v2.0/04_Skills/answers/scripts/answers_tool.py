# -*- coding: utf-8 -*-
"""answers 用: 回答済みアーキテクチャレビュー票の取り込みと検算。
使い方:
  locate : python scripts/answers_tool.py locate --thread work/thread.json [--ritm RITM1234567]
           → スレッドの添付から回答済み票(xlsx)を選び、Excel ツールに渡す 場所/ライブラリ/パス を作る
  prepare: python scripts/answers_tool.py prepare --rows work/answer_rows.json
           → 票の行を「No｜環境｜指摘概要｜回答内容｜回答者｜回答日」に整え、空欄を 未回答 として仕分けの材料にする
  verify : python scripts/answers_tool.py verify --result work/06_answers.md --rows work/answer_rows.json
           → 【回答回収結果】の 回答済み+未回答+要確認 = 全行数 を確かめる
"""
import argparse
import re
import sys
import os
from urllib.parse import urlparse, unquote

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input, read_json_input, rows_from_json, parse_sections, split_fields, get, first_int, dump  # noqa: E402


def cmd_locate(a):
    obj = read_json_input(a.thread)
    atts = obj.get("attachments", []) if isinstance(obj, dict) else obj
    xlsx = [x for x in atts if str(x.get("name", "")).lower().endswith((".xlsx", ".xlsm"))]
    if a.ritm:
        pref = [x for x in xlsx if a.ritm in x.get("name", "")]
        xlsx = pref or xlsx
    pref = [x for x in xlsx if "レビュー票" in x.get("name", "")]
    xlsx = pref or xlsx
    xlsx.sort(key=lambda x: x.get("at", ""))
    if not xlsx:
        dump({"found": False, "reason": "スレッドに xlsx の添付がありません", "candidates": [x.get("name") for x in atts]})
        return
    x = xlsx[-1]
    url = x.get("url", "")
    p = urlparse(url)
    path = unquote(p.path)
    site_url, library, rel = "", "", ""
    m = re.match(r"^(/sites/[^/]+|/teams/[^/]+)?/([^/]+)/(.*)$", path)
    if m:
        site_url = f"{p.scheme}://{p.netloc}{m.group(1) or ''}"
        library = m.group(2)
        rel = "/" + m.group(3)
    dump({"found": True, "name": x.get("name"), "by": x.get("by"), "at": x.get("at"), "url": url,
          "site_url": site_url, "library": library, "library_hint": "Shared Documents は画面上『ドキュメント』(Documents)の既定ライブラリ",
          "file_path": rel, "table": "T_アーキテクチャレビュー票"})


def rows_prepared(rows):
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        no = get(r, "No.", "No")
        if not no.strip():
            continue
        ans = get(r, "回答内容", "回答").strip()
        out.append({"no": no.strip(), "env": get(r, "環境"), "summary": get(r, "指摘概要"), "kind": get(r, "対応区分"),
                    "answer": ans, "answered_by": get(r, "回答者"), "answered_at": get(r, "回答日"),
                    "status": "未回答" if not ans else "要仕分け(回答済み or 要確認)"})
    return out


def cmd_prepare(a):
    rows = rows_prepared(rows_from_json(read_json_input(a.rows)))
    lines = [f"- {r['no']}｜{r['env']}｜{r['summary']}｜{r['answer'] if r['answer'] else '(空欄)'}｜{r['answered_by']}｜{r['answered_at']}" for r in rows]
    dump({"total": len(rows), "unanswered": [r["no"] for r in rows if r["status"] == "未回答"],
          "to_classify": [r["no"] for r in rows if r["status"] != "未回答"],
          "rows": rows, "lines": lines,
          "rule": "回答内容が空欄 → 未回答。文があるものは LLM が 回答済み(内容あり)/ 要確認(不十分・質問返し・前提変更)に仕分ける。構成図の修正・再提出の記述があれば 構成図修正: あり"})


def cmd_verify(a):
    rows = rows_prepared(rows_from_json(read_json_input(a.rows)))
    text = read_input(a.result)
    sec = parse_sections(text)
    counts = {}
    for key in ("未回答", "要確認", "回答済み"):
        for k, v in sec.items():
            if k.startswith(key):
                counts[key] = len([x for x in v if x.strip() and x.strip() != "なし"])
                break
    total = sum(counts.values())
    stated = None
    for line in sec.get("集計", []):
        m = re.search(r"全\s*(\d+)\s*行", line)
        if m:
            stated = int(m.group(1))
    nos_in = set()
    for key in ("未回答", "要確認", "回答済み"):
        for k, v in sec.items():
            if k.startswith(key):
                for x in v:
                    f = split_fields(x)
                    if f and f[0] != "なし":
                        nos_in.add(f[0].replace("No.", "").strip())
    missing = [r["no"] for r in rows if r["no"] not in nos_in]
    dump({"rows_total": len(rows), "counts": counts, "sum": total, "stated_total": stated, "missing_no": missing,
          "r4_line": f"R4: {total} / {len(rows)}", "ok": total == len(rows) and not missing})


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("locate"); p.add_argument("--thread", required=True); p.add_argument("--ritm")
    p = sub.add_parser("prepare"); p.add_argument("--rows", required=True)
    p = sub.add_parser("verify"); p.add_argument("--result", required=True); p.add_argument("--rows", required=True)
    a = ap.parse_args()
    {"locate": cmd_locate, "prepare": cmd_prepare, "verify": cmd_verify}[a.cmd](a)


if __name__ == "__main__":
    main()
