# -*- coding: utf-8 -*-
"""全スキル共通: 案件状態ファイル 00_status.md を作る・更新する(内容は標準出力に出す。保存はツールで行う)。
使い方:
  新規: python scripts/status_tool.py --ritm RITM1234567 --step "Mermaid化(完了)" --next "『構成図情報を抽出して』" \
          [--thread-line "- Teamsスレッド: team=… ｜ channel=… ｜ message=…"] [--link "<リンク>"]
  更新: python scripts/status_tool.py --current work/00_status.md --ritm RITM1234567 --step "判定(完了)" \
          --next "『構成図チェックして』" [--env Hub] [--csp AWS]
--step は「工程名(状態)」。同じ工程名が既にあれば置き換える。--env/--csp を付けたときだけ対象環境・CSP を書き換える。
"""
import argparse
import datetime
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input  # noqa: E402


def parse_status(text):
    d = {"ritm": "", "env": "未定", "csp": "未定", "steps": [], "next": "", "thread": "", "link": "", "extra": []}
    for line in text.split("\n"):
        line = line.strip()
        m = re.match(r"【案件状態】RITM:\s*(\S+)", line)
        if m:
            d["ritm"] = m.group(1)
        elif line.startswith("- 対象環境"):
            m = re.search(r"対象環境:\s*([^｜|]+)[｜|]\s*CSP:\s*(.+)$", line)
            if m:
                d["env"], d["csp"] = m.group(1).strip(), m.group(2).strip()
        elif line.startswith("- 完了した工程"):
            body = line.split(":", 1)[-1].strip()
            d["steps"] = [x.strip() for x in re.split(r"[｜|]", body) if x.strip() and x.strip() != "なし"]
        elif line.startswith("- 次の操作"):
            d["next"] = line.split(":", 1)[-1].strip()
        elif line.startswith("- Teamsスレッド"):
            d["thread"] = line
        elif line.startswith("- スレッドリンク"):
            d["link"] = line.split(":", 1)[-1].strip()
        elif line.startswith("- 更新"):
            pass
        elif line.startswith("- "):
            d["extra"].append(line)
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--current")
    ap.add_argument("--ritm", required=True)
    ap.add_argument("--step", required=True, help="例: 判定(完了)")
    ap.add_argument("--next", required=True)
    ap.add_argument("--env")
    ap.add_argument("--csp")
    ap.add_argument("--thread-line")
    ap.add_argument("--link")
    a = ap.parse_args()
    d = parse_status(read_input(a.current)) if a.current and os.path.exists(a.current) else parse_status("")
    d["ritm"] = a.ritm
    if a.env:
        d["env"] = a.env.replace("DCS", "").strip()
    if a.csp:
        d["csp"] = a.csp.strip()
    name = re.sub(r"[(（].*$", "", a.step).strip()
    d["steps"] = [s for s in d["steps"] if re.sub(r"[(（].*$", "", s).strip() != name] + [a.step]
    d["next"] = a.next
    if a.thread_line:
        d["thread"] = a.thread_line if a.thread_line.startswith("- ") else "- " + a.thread_line
    if a.link:
        d["link"] = a.link
    today = datetime.date.today().isoformat()
    lines = [f"【案件状態】RITM: {d['ritm']}",
             f"- 対象環境: {d['env']} ｜ CSP: {d['csp']}",
             f"- 完了した工程: {'｜'.join(d['steps']) if d['steps'] else 'なし'}",
             f"- 次の操作: {d['next']}"]
    if d["thread"]:
        lines.append(d["thread"])
    if d["link"]:
        lines.append(f"- スレッドリンク: {d['link']}")
    lines += d["extra"]
    lines.append(f"- 更新: {name} {today}")
    sys.stdout.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
