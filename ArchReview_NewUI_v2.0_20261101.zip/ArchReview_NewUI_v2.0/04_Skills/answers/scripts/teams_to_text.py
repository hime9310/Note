# -*- coding: utf-8 -*-
"""hosting / answers 用: Teams のツール返り値(親投稿の詳細 + 返信の一覧。JSON)をスレッド本文のテキストにする。
使い方: python scripts/teams_to_text.py --parent work/teams_parent.json --replies work/teams_replies.json [--out work/03_thread.md]
出力(JSON): {"text": "<スレッド本文>", "posts": N, "attachments": [{"name","url","by","at"}], "csp_hint": "AWS|Azure|GCP|不明"}
--out を付けると本文を Markdown で書き出す(案件フォルダの 03_thread.md に保存する用)。
"""
import argparse
import html
import json
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_json_input, dump  # noqa: E402


def strip_html(s):
    if not s:
        return ""
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"</(p|div|li|tr|h\d)>", "\n", s, flags=re.I)
    s = re.sub(r"<li[^>]*>", "- ", s, flags=re.I)
    s = re.sub(r"<attachment[^>]*>.*?</attachment>", "", s, flags=re.I | re.S)
    s = re.sub(r"<[^>]+>", "", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t ]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def _find_messages(obj, found):
    """返り値の形に関係なく、body.content を持つオブジェクトを集める。"""
    if isinstance(obj, dict):
        body = obj.get("body")
        if isinstance(body, dict) and ("content" in body):
            found.append(obj)
            return
        for v in obj.values():
            _find_messages(v, found)
    elif isinstance(obj, list):
        for v in obj:
            _find_messages(v, found)


def _author(m):
    fr = m.get("from") or {}
    if isinstance(fr, dict):
        for k in ("user", "application", "device"):
            u = fr.get(k)
            if isinstance(u, dict) and u.get("displayName"):
                return u["displayName"]
    return m.get("fromDisplayName") or m.get("userDisplayName") or "(不明)"


def _attachments(m):
    out = []
    for a in m.get("attachments") or []:
        if not isinstance(a, dict):
            continue
        out.append({
            "name": a.get("name") or "",
            "url": a.get("contentUrl") or a.get("content_url") or "",
            "type": a.get("contentType") or "",
        })
    return out


def to_posts(parent_obj, replies_obj):
    posts = []
    for src, kind in ((parent_obj, "parent"), (replies_obj, "reply")):
        if src is None:
            continue
        found = []
        _find_messages(src, found)
        for m in found:
            body = m.get("body") or {}
            text = strip_html(body.get("content", ""))
            posts.append({
                "kind": kind,
                "id": str(m.get("id", "")),
                "at": m.get("createdDateTime") or m.get("lastModifiedDateTime") or "",
                "by": _author(m),
                "text": text,
                "attachments": _attachments(m),
            })
    # 親→返信の順、同種は時刻順
    posts.sort(key=lambda p: (0 if p["kind"] == "parent" else 1, p["at"]))
    return posts


def csp_hint(text):
    t = text.lower()
    hits = {"AWS": bool(re.search(r"\baws\b|amazon", t)), "Azure": "azure" in t, "GCP": bool(re.search(r"\bgcp\b|google cloud", t))}
    found = [k for k, v in hits.items() if v]
    return found[0] if len(found) == 1 else ("不明" if not found else "/".join(found))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--parent")
    ap.add_argument("--replies")
    ap.add_argument("--out")
    a = ap.parse_args()
    parent = read_json_input(a.parent) if a.parent else None
    replies = read_json_input(a.replies) if a.replies else None
    posts = to_posts(parent, replies)
    lines = []
    atts = []
    for i, p in enumerate(posts, 1):
        head = f"[{i}] {p['by']} {p['at'][:16].replace('T', ' ')}".strip()
        lines.append(head)
        lines.append(p["text"] if p["text"] else "(本文なし)")
        for at in p["attachments"]:
            lines.append(f"(添付: {at['name']})")
            atts.append({"name": at["name"], "url": at["url"], "by": p["by"], "at": p["at"], "post": i})
        lines.append("")
    text = "\n".join(lines).strip()
    result = {"posts": len(posts), "text": text, "attachments": atts, "csp_hint": csp_hint(text)}
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write("【Teamsスレッド】状態: 完了\n")
            f.write(f"- 投稿数: {len(posts)} ｜ 添付: {len(atts)}件 ｜ CSPの手がかり: {result['csp_hint']}\n")
            f.write("## 本文\n")
            f.write(text + "\n")
            if atts:
                f.write("## 添付\n")
                for at in atts:
                    f.write(f"- {at['name']}｜{at['by']}｜{at['at'][:10]}｜{at['url']}\n")
        result["out"] = a.out
    dump(result)


if __name__ == "__main__":
    main()
