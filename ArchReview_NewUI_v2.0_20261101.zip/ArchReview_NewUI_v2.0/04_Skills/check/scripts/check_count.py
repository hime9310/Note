# -*- coding: utf-8 -*-
"""check 用 検算: 埋めた【構成図チェック結果】を読み、[ ] の残り・区分の件数・検算行を確かめる。
使い方: python scripts/check_count.py --result work/04_check.md --count 6
出力(JSON): 区分ごとの件数(観点ごとの判定の行から数えたもの)、検算行の案、残っている [ ]、ok。
"""
import argparse
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input, parse_sections, first_int, dump  # noqa: E402

NAMES = ["票で確認", "利用者へ依頼", "Eng目視確認", "要人手確認", "問題なし", "対象外"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--count", type=int, required=True, help="filter_points の count(適用行数)")
    a = ap.parse_args()
    text = read_input(a.result)
    sec = parse_sections(text)
    rows = []
    for k, v in sec.items():
        if k.startswith("観点ごとの判定"):
            rows = v
            break
    counts = {n: 0 for n in NAMES}
    unknown = []
    nos = []
    for line in rows:
        m = re.match(r"No\.?\s*(\d+)\s+(.*?)\s*→\s*([^(（｜|]+)", line)
        if not m:
            unknown.append(line[:60])
            continue
        nos.append(m.group(1))
        label = m.group(3).strip()
        hit = None
        for n in NAMES:
            if label.startswith(n):
                hit = n
                break
        if hit:
            counts[hit] += 1
        else:
            unknown.append(line[:60])
    placeholders = re.findall(r"\[[^\]\n]{1,40}\]", text)
    placeholders = [p for p in placeholders if not re.fullmatch(r"\[(x|X|\d+)\]", p)]
    total = sum(counts.values())
    need = counts["票で確認"] + counts["利用者へ依頼"] + counts["Eng目視確認"] + counts["要人手確認"]
    status_ok = True
    first = text.strip().split("\n")[0] if text.strip() else ""
    want_status = "要確認" if (counts["Eng目視確認"] or counts["要人手確認"]) else "完了"
    if "要確認" in first and want_status == "完了" and "検算不一致" not in text:
        status_ok = True  # Eng が要確認にした理由があるかもしれないので誤りとはしない
    if want_status == "要確認" and "要確認" not in first:
        status_ok = False
    dup = sorted({n for n in nos if nos.count(n) > 1})
    result = {
        "rows": len(rows), "count": a.count, "counts": counts, "need_action": need,
        "placeholders_left": placeholders, "unparsed_rows": unknown, "duplicate_no": dup,
        "expected_status": want_status, "status_line": first,
        "kensan_line": f"- 票で確認{counts['票で確認']} + 利用者へ依頼{counts['利用者へ依頼']} + Eng目視確認{counts['Eng目視確認']} + 要人手確認{counts['要人手確認']} + 問題なし{counts['問題なし']} + 対象外{counts['対象外']} = {total}(適用行数 {a.count} と一致)",
        "conclusion_line": f"- 対応が必要 {need}件(票で確認{counts['票で確認']}・利用者へ依頼{counts['利用者へ依頼']}・Eng目視確認{counts['Eng目視確認']}・要人手確認{counts['要人手確認']}) ｜ 問題なし {counts['問題なし']}件 ｜ 対象外 {counts['対象外']}件",
        "ok": (total == a.count == len(rows)) and not placeholders and not unknown and not dup and status_ok,
    }
    dump(result)


if __name__ == "__main__":
    main()
