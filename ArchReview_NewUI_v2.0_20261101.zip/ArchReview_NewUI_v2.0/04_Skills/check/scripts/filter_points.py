# -*- coding: utf-8 -*-
"""check 用: 構成図チェック観点一覧(md)を 環境・CSP・1次/2次・有効 で絞り、トリガーを機械的に評価して
「判定材料」と「【構成図チェック結果】の下書き」を作る。
使い方:
  python scripts/filter_points.py --points work/points.md --ritm RITM1234567 --env Hub --csp AWS --phase 1次 \
      --inventory work/02_inventory.md [--answers work/06_answers.md] [--thread work/03_thread.md] [--out-draft work/draft.md]
出力(JSON): count(適用行数), materials(LLM が判定する行), prefilled(トリガー不成立で対象外にした行), draft(下書き全文)。
トリガー種別: 常時=実施 / 存在=一覧にサービスがあれば実施 / 回答=回答回収結果(無ければスレッド本文)に該当があれば要判定 / 存在かつ回答=両方。
"""
import argparse
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import (read_input, parse_tables, parse_sections, split_fields, normalize, cell_lines,  # noqa: E402
                       get, find_table, first_int, dump)

SYMBOL_NAMES = {"A": "問題なし", "B": "Eng目視確認", "C": "利用者へ依頼", "D": "票で確認", "E": "対象外"}
JUDGE_VALUES = ["記載あり", "記載なし", "方向不明", "判定不能", "対象外"]


def parse_rule(s):
    """'記載あり→A; 記載なし→B' → {'記載あり': 'A', ...}"""
    rule = {}
    for part in re.split(r"[;；\n]", s or ""):
        if "→" in part or "->" in part:
            k, v = re.split(r"→|->", part, maxsplit=1)
            rule[k.strip()] = v.strip()[:1].upper()
    return rule


def pick_ticket(cell, csp):
    """指摘概要のセル('共通: 文' / 'AWS: 文' …)から、この CSP の文を選ぶ。"""
    lines = cell_lines(cell)
    if not lines or lines[0] == "なし":
        return "なし"
    common, mine = "", ""
    for ln in lines:
        m = re.match(r"^(共通|AWS|Azure|GCP)\s*[:：]\s*(.*)$", ln, re.I)
        if not m:
            common = common or ln
            continue
        tag, text = m.group(1), m.group(2).strip()
        if tag == "共通":
            common = text
        elif tag.lower() == csp.lower():
            mine = text
    return mine or common or "なし"


def inventory_services(text):
    sec = parse_sections(text)
    out = []
    for line in sec.get("サービス一覧", []):
        f = split_fields(line)
        if len(f) >= 2:
            out.append({"node": f[0], "label": f[1], "formal": f[2] if len(f) > 2 and f[2] != "-" else "", "place": f[3] if len(f) > 3 else ""})
    return out


def exists(target, services):
    nt = normalize(target)
    if len(nt) < 2:
        return []
    hits = []
    for s in services:
        for name in (s["label"], s["formal"], s["node"]):
            nn = normalize(name)
            if nn and (nt in nn or (len(nn) >= 3 and nn in nt)):
                hits.append(s["node"])
                break
    return hits


def answer_rows(text):
    """06_answers.md の 回答済み / 要確認 / 未回答 から (No, 指摘概要, 要点, 区分) を集める。"""
    rows = []
    if not text:
        return rows
    sec = parse_sections(text)
    for key, kind in (("回答済み", "回答済み"), ("要確認", "要確認"), ("未回答", "未回答")):
        for k, v in sec.items():
            if k.startswith(key):
                for line in v:
                    f = split_fields(line)
                    if len(f) >= 2 and f[0] != "なし":
                        rows.append({"no": f[0], "summary": f[1], "text": f[2] if len(f) > 2 else "", "kind": kind})
    return rows


def find_answer(ticket, item, answers):
    keys = [normalize(x) for x in (ticket, item) if x and x != "なし"]
    for a in answers:
        ns = normalize(a["summary"])
        for k in keys:
            if k and (k in ns or ns in k):
                return a
    return None


def thread_hits(item, thread_text):
    if not thread_text:
        return []
    key = re.split(r"[=＝]", item)[0]
    toks = []
    for t in re.findall(r"[A-Za-z0-9]+|[぀-鿿]+", key):
        if len(t) >= 2:
            toks.append(t)
            if re.match(r"[぀-鿿]", t) and len(t) > 4:
                toks.append(t[:4])
    hits = []
    for line in thread_text.split("\n"):
        if line.strip() and any(t.lower() in line.lower() for t in toks):
            hits.append(line.strip())
    return hits[:5]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--points", required=True)
    ap.add_argument("--ritm", required=True)
    ap.add_argument("--env", required=True, help="Hub または Disconnected")
    ap.add_argument("--csp", required=True, help="AWS / Azure / GCP")
    ap.add_argument("--phase", required=True, help="1次 または 2次")
    ap.add_argument("--inventory", required=True)
    ap.add_argument("--answers")
    ap.add_argument("--thread")
    ap.add_argument("--out-draft")
    a = ap.parse_args()

    env = a.env.replace("DCS", "").strip()
    env_full = f"DCS {env}"
    csp = a.csp.strip()
    phase = "2次" if "2" in a.phase else "1次"

    tables = parse_tables(read_input(a.points))
    main_t = find_table(tables, header_keywords=["チェック観点", "トリガー種別"]) or tables[0]
    gs_t = find_table(tables, title_keywords=["代表サービス"], header_keywords=["サービス"])
    global_services = []
    if gs_t:
        for r in gs_t["rows"]:
            c = get(r, "CSP")
            n = get(r, "サービス", "サービス名")
            if n and (not c or normalize(c) == normalize(csp)):
                global_services.append(n)

    services = inventory_services(read_input(a.inventory))
    answers = answer_rows(read_input(a.answers)) if a.answers and os.path.exists(a.answers) else []
    thread = read_input(a.thread) if a.thread and os.path.exists(a.thread) else ""

    applicable = []
    for r in main_t["rows"]:
        no = get(r, "No")
        if not no:
            continue
        if normalize(get(r, "有効", default="1")) in ("0", "false", ""):
            continue
        env_cell = normalize(get(r, "環境"))
        if env_cell not in (normalize("DCS共通"), normalize(env_full)):
            continue
        csps = [normalize(x) for x in re.split(r"[,、/\s]+", get(r, "対象CSP")) if x]
        if csps and normalize("共通") not in csps and normalize(csp) not in csps:
            continue
        timing = normalize(get(r, "チェックタイミング"))
        if timing not in (normalize(phase), normalize("両方")):
            continue
        applicable.append(r)

    applicable.sort(key=lambda r: first_int(get(r, "No"), 0))

    materials, prefilled, draft_rows = [], [], []
    for r in applicable:
        no = get(r, "No")
        name = get(r, "チェック観点")
        ttype = normalize(get(r, "トリガー種別")) or normalize("常時")
        target = get(r, "トリガー対象")
        ticket = pick_ticket(get(r, "指摘概要"), csp)
        rule = parse_rule(get(r, "区分表"))
        exist_parts, answer_parts = [], []
        for part in [p.strip() for p in re.split(r"[;；]", target) if p.strip()]:
            if part.startswith("存在"):
                exist_parts.append(re.sub(r"^存在\s*[:：]\s*", "", part))
            elif part.startswith("回答"):
                answer_parts.append(re.sub(r"^回答\s*[:：]\s*", "", part))
            elif ttype == normalize("存在"):
                exist_parts.append(part)
            elif ttype == normalize("回答"):
                answer_parts.append(part)
            elif ttype == normalize("存在かつ回答"):
                (answer_parts if "=" in part or "＝" in part else exist_parts).append(part)

        status, evidence = "実施", ""
        # 存在
        if ttype in (normalize("存在"), normalize("存在かつ回答")) or exist_parts:
            hit_nodes, miss = [], []
            for ep in exist_parts:
                cands = global_services if ep.strip().startswith("@") else [x for x in re.split(r"/", ep) if x.strip()]
                found = []
                for c in cands:
                    found += exists(c, services)
                if found:
                    hit_nodes += sorted(set(found))
                else:
                    miss.append(ep if not ep.startswith("@") else f"{ep}({len(cands)}件)")
            if not hit_nodes:
                status = "対象外(利用なし)"
                evidence = "存在: " + " / ".join(miss or exist_parts) + " の記載なし"
            else:
                evidence = "存在: " + ", ".join(dict.fromkeys(hit_nodes))
        # 回答
        if status == "実施" and (ttype in (normalize("回答"), normalize("存在かつ回答")) or answer_parts):
            item = answer_parts[0] if answer_parts else target
            ans = find_answer(ticket, item, answers)
            if ans:
                status = "要判定(回答)"
                evidence = (evidence + " ｜ " if evidence else "") + f"回答: No.{ans['no']} {ans['summary']}: {ans['text']}"[:200]
            else:
                th = thread_hits(item, thread)
                if th:
                    status = "要判定(スレッド)"
                    evidence = (evidence + " ｜ " if evidence else "") + "スレッド: " + " / ".join(th)[:200]
                else:
                    status = "対象外(回答なし)"
                    evidence = (evidence + " ｜ " if evidence else "") + f"回答: 「{item}」に該当する回答なし"

        ticket_tag = f"(票: {ticket})" if ticket != "なし" else "(票: なし)"
        if status.startswith("対象外"):
            prefilled.append({"no": no, "name": name, "status": status, "evidence": evidence})
            draft_rows.append(f"- No.{no} {name} → {status}{ticket_tag}｜構成図の状態: トリガー不成立({evidence})｜次の対応: なし")
        else:
            materials.append({
                "no": no, "name": name, "category": get(r, "大分類"), "trigger": status, "evidence": evidence,
                "criteria": get(r, "判断基準"), "method": get(r, "AI判定方法"), "output": get(r, "AI出力内容"),
                "rule": rule, "rule_text": get(r, "区分表"), "action": get(r, "対応内容"), "ticket": ticket,
                "note": get(r, "備考"),
            })
            draft_rows.append(f"- No.{no} {name} → [区分]{ticket_tag}｜構成図の状態: [判定と根拠]｜次の対応: [対応]")

    n = len(applicable)
    e_pre = len(prefilled)
    nl = "\n"
    draft = nl.join([
        "【構成図チェック結果】状態: [完了 or 要確認]",
        "## 結論",
        f"- 処理: {phase}チェック ｜ {a.ritm} ｜ 環境: {env} ｜ CSP: {csp} ｜ 関わる観点: {n}件",
        "- 対応が必要 [NN]件(票で確認[NN]・利用者へ依頼[NN]・Eng目視確認[NN]・要人手確認[NN]) ｜ 問題なし [NN]件 ｜ 対象外 [NN]件",
        "- 次にEngがやること: [1〜2文]",
        "## 対応が必要な観点(区分ごと)",
        "- 票で確認([NN]件): [No.X 観点名, …]",
        "- 利用者へ依頼([NN]件): [No.X 観点名, …]",
        "- Eng目視確認([NN]件): [No.X 観点名, …]",
        "- 要人手確認([NN]件): [No.X 観点名, …]",
        "## 問題なし・対象外",
        "- 問題なし([NN]件): [No列挙]",
        f"- 対象外([NN]件): [No列挙(利用なし / 回答なし)。トリガー不成立の{e_pre}件を含む]",
        "## 利用者への確認・依頼(票に入る文案)",
        "- [No.X(票: 指摘概要 or なし)｜カテゴリ: サービス名｜指摘概要: 件名｜指摘内容: 文案]",
        "## 観点ごとの判定(No順。1観点1行)",
        nl.join(draft_rows),
        "## 要確認",
        "- [検算不一致・反映できない指摘・回答が無く対象外にした旨など。無ければ「なし」]",
        "## 検算",
        f"- 票で確認[NN] + 利用者へ依頼[NN] + Eng目視確認[NN] + 要人手確認[NN] + 問題なし[NN] + 対象外[NN] = [NN](適用行数 {n} と一致)",
    ])
    result = {
        "ritm": a.ritm, "env": env, "csp": csp, "phase": phase, "count": n,
        "to_judge": len(materials), "prefilled_count": e_pre,
        "judge_values": JUDGE_VALUES, "symbol_names": SYMBOL_NAMES,
        "rule_default": "区分表に無い判定値は B(Eng目視確認)。トリガー不成立は E(対象外)。",
        "materials": materials, "prefilled": prefilled, "draft": draft,
    }
    if a.out_draft:
        with open(a.out_draft, "w", encoding="utf-8") as f:
            f.write(draft + "\n")
        result["out_draft"] = a.out_draft
    dump(result)


if __name__ == "__main__":
    main()
