# -*- coding: utf-8 -*-
"""diagram 用: Teams スレッドのリンクから チーム(groupId)・チャネル ID・メッセージ ID を取り出す。
使い方: python scripts/parse_teams_link.py --url "<リンク>"
出力(JSON): {"team": ..., "channel": ..., "message": ..., "ok": true/false, "reason": ...}
リンクの例:
https://teams.microsoft.com/l/message/19%3Aabc...%40thread.tacv2/1700000000000?tenantId=...&groupId=xxxx&parentMessageId=1700000000000&teamName=...&channelName=...
"""
import argparse
import re
import sys
import os
from urllib.parse import unquote, urlparse, parse_qs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump  # noqa: E402


def parse(url):
    url = url.strip().strip("<>\"'")
    out = {"team": "", "channel": "", "message": "", "ok": False, "reason": "", "url": url}
    try:
        p = urlparse(url)
        qs = {k: v[0] for k, v in parse_qs(p.query).items()}
        path = unquote(p.path)
        m = re.search(r"/l/message/([^/]+)/(\d+)", path)
        if m:
            out["channel"] = m.group(1)
            out["message"] = m.group(2)
        # channel 直リンク(/l/channel/<id>/...)の場合
        if not out["channel"]:
            m2 = re.search(r"/l/channel/([^/]+)/", path)
            if m2:
                out["channel"] = m2.group(1)
        out["team"] = qs.get("groupId", "")
        # 返信のリンクを貼られた場合は親投稿(parentMessageId)を正とする
        if qs.get("parentMessageId"):
            out["message"] = qs["parentMessageId"]
        out["team_name"] = qs.get("teamName", "")
        out["channel_name"] = qs.get("channelName", "")
        if out["team"] and out["channel"] and out["message"]:
            out["ok"] = True
        else:
            missing = [k for k in ("team", "channel", "message") if not out[k]]
            out["reason"] = "リンクから取り出せない項目: " + ", ".join(missing)
    except Exception as e:  # pragma: no cover
        out["reason"] = f"解析エラー: {e}"
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    a = ap.parse_args()
    r = parse(a.url)
    r["status_line"] = f"- Teamsスレッド: team={r['team']} ｜ channel={r['channel']} ｜ message={r['message']}"
    dump(r)


if __name__ == "__main__":
    main()
