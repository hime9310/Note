# -*- coding: utf-8 -*-
"""extract 用 検算 R0: Mermaid のノード数 = 【構成図一覧】のサービス一覧 + 除外ノード。
使い方: python scripts/check_r0.py --mermaid work/01_mermaid.md --inventory work/02_inventory.md
出力(JSON): mermaid のノード一覧、一覧側の件数、不足・過剰ノード、ok。
"""
import argparse
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input, parse_sections, split_fields, first_int, dump  # noqa: E402

NODE_DEF = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(\[|\(|\{|>)")
EDGE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(-->|<-->|---|-\.->|==>|-.->)\s*(?:\|[^|]*\|\s*)?([A-Za-z_][A-Za-z0-9_]*)")
SKIP_WORDS = {"subgraph", "end", "flowchart", "graph", "classDef", "class", "style", "linkStyle", "direction"}


def mermaid_nodes(text):
    code = text
    m = re.search(r"```mermaid\s*\n(.*?)```", text, re.S)
    if m:
        code = m.group(1)
    defined, referenced = [], []
    for raw in code.split("\n"):
        line = raw.strip().rstrip(";")
        if not line or line.startswith("%%"):
            continue
        first = line.split()[0] if line.split() else ""
        if first in SKIP_WORDS:
            continue
        e = EDGE.match(line)
        if e:
            referenced += [e.group(1), e.group(3)]
            continue
        d = NODE_DEF.match(line)
        if d and d.group(1) not in SKIP_WORDS:
            defined.append(d.group(1))
    nodes = []
    for n in defined + referenced:
        if n not in nodes:
            nodes.append(n)
    return nodes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mermaid", required=True)
    ap.add_argument("--inventory", required=True)
    a = ap.parse_args()

    nodes = mermaid_nodes(read_input(a.mermaid))
    inv = read_input(a.inventory)
    sec = parse_sections(inv)
    services = [split_fields(x)[0] for x in sec.get("サービス一覧", []) if "｜" in x or "|" in x]
    excluded = [split_fields(x)[0] for x in sec.get("除外ノード", []) if "｜" in x or "|" in x]
    listed = set(services) | set(excluded)
    missing = [n for n in nodes if n not in listed]
    extra = [n for n in listed if n not in nodes and not n.endswith("(Eng追加)")]

    # 一覧の見出し件数との照合
    def heading_count(name):
        for k in sec.keys():
            if k.startswith(name) and "(" in k:
                return first_int(k.split("(", 1)[1])
        return None

    result = {
        "mermaid_node_count": len(nodes),
        "mermaid_nodes": nodes,
        "service_count": len(services),
        "excluded_count": len(excluded),
        "service_heading_count": heading_count("サービス一覧"),
        "excluded_heading_count": heading_count("除外ノード"),
        "missing_in_inventory": missing,
        "extra_in_inventory": extra,
        "r0_line": f"R0: サービス一覧{len(services)} + 除外{len(excluded)} = ノード総数{len(nodes)}",
        "ok": not missing and not extra and len(services) + len(excluded) == len(nodes),
    }
    dump(result)


if __name__ == "__main__":
    main()
