# -*- coding: utf-8 -*-
"""hosting 用: ノックアウト要件一覧の全行数と ID を数え、【ホスティング判定結果】の検算を確かめる。
使い方:
  事前: python scripts/check_hosting.py --ko work/ko.md                      → 全行数と ID 一覧(判定の材料)
  事後: python scripts/check_hosting.py --ko work/ko.md --result work/03_hosting.md [--inventory work/02_inventory.md]
出力(JSON): ko_total, ko_ids, 判定結果に出てきた ID の過不足、検算の一致、ok。
"""
import argparse
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input, parse_tables, parse_sections, split_fields, get, find_table, first_int, dump  # noqa: E402


def ko_rows(text):
    tables = parse_tables(text)
    t = find_table(tables, header_keywords=["ID", "判断区分"]) or (tables[0] if tables else {"rows": []})
    rows = []
    for r in t["rows"]:
        kid = get(r, "ID")
        if kid:
            rows.append({"id": kid.strip(), "category": get(r, "判断区分"), "case": get(r, "具体的なケース"), "note": get(r, "備考"),
                         "ai_no_judge": bool(re.search(r"AI(は|による).{0,8}(判断|判定)(は|を)?(行わず|しない)|利用者に確認|人が行う", get(r, "備考")))})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ko", required=True)
    ap.add_argument("--result")
    ap.add_argument("--inventory")
    a = ap.parse_args()
    rows = ko_rows(read_input(a.ko))
    out = {"ko_total": len(rows), "ko_ids": [r["id"] for r in rows],
           "ai_no_judge_ids": [r["id"] for r in rows if r["ai_no_judge"]]}
    if not a.result:
        dump(out)
        return

    res = read_input(a.result)
    sec = parse_sections(res)
    ko_sec = []
    for k, v in sec.items():
        if k.startswith("ノックアウト要件"):
            ko_sec = v
            break
    non = 0
    individual = []
    for line in ko_sec:
        if line.startswith("非該当"):
            ids = re.findall(r"KO-\d+", line)
            non = first_int(line.split(":")[0], 0) if "件" in line.split(":")[0] else len(ids)
            out["non_ids"] = ids
            out["non_count_stated"] = first_int(line, 0)
            out["non_count_listed"] = len(ids)
        elif re.match(r"KO-\d+", line):
            individual.append(split_fields(line)[0])
    stated_total = None
    for k in sec.keys():
        if k.startswith("ノックアウト要件") and "全" in k:
            stated_total = first_int(k.split("全", 1)[1])
    out["result_non_count"] = non
    out["result_individual_ids"] = individual
    out["result_total_stated"] = stated_total
    listed = set(out.get("non_ids", [])) | set(individual)
    out["missing_ids"] = [r["id"] for r in rows if r["id"] not in listed]
    out["unknown_ids"] = sorted(listed - set(out["ko_ids"]))
    out["ko_check_line"] = f"ノックアウト要件: 非該当{len(out.get('non_ids', []))} + 個別{len(individual)} = {len(out.get('non_ids', [])) + len(individual)}(ツールの全行数{len(rows)}と一致)"
    ok = (len(out.get("non_ids", [])) + len(individual) == len(rows)) and not out["missing_ids"] and not out["unknown_ids"]

    if a.inventory:
        inv = parse_sections(read_input(a.inventory))
        svc = [x for x in inv.get("サービス一覧", []) if "｜" in x or "|" in x]
        out["inventory_service_count"] = len(svc)
        sal = []
        for k, v in sec.items():
            if k.startswith("Salus"):
                sal = v
                break
        counts = {}
        for line in sal:
            m = re.match(r"(TRUE|FALSE|未照合)\((\d+)件\)", line.replace(" ", ""))
            if m:
                counts[m.group(1)] = int(m.group(2))
        out["salus_counts"] = counts
        out["salus_ok"] = sum(counts.values()) == len(svc)
        ok = ok and out["salus_ok"]
    out["ok"] = ok
    dump(out)


if __name__ == "__main__":
    main()
