# -*- coding: utf-8 -*-
"""hosting 用: 【構成図一覧】のサービス一覧を Salus Status 一覧と機械的に照合する。
使い方: python scripts/salus_match.py --inventory work/02_inventory.md --salus work/salus.md
出力(JSON): TRUE / FALSE / 未照合 のサービス名と件数、未照合の候補(LLM が確認する用)、検算行。
照合の順: 正式名の完全一致 → 表示ラベルの完全一致 → 部分一致(どちらかがどちらかを含む)。空白・大文字小文字・記号は無視。
"""
import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input, parse_tables, parse_sections, split_fields, normalize, get, find_table, dump  # noqa: E402

GENERIC = {"amazon", "aws", "azure", "microsoft", "google", "cloud", "gcp", "service", "services"}


def tokens(name):
    import re
    import unicodedata
    s = unicodedata.normalize("NFKC", name).lower()
    return [t for t in re.split(r"[^a-z0-9぀-鿿]+", s) if t and t not in GENERIC]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inventory", required=True)
    ap.add_argument("--salus", required=True)
    a = ap.parse_args()

    inv = parse_sections(read_input(a.inventory))
    services = []
    for line in inv.get("サービス一覧", []):
        f = split_fields(line)
        if len(f) < 2:
            continue
        node, label = f[0], f[1]
        formal = f[2] if len(f) > 2 and f[2] not in ("-", "") else ""
        services.append({"node": node, "label": label, "formal": formal})

    tables = parse_tables(read_input(a.salus))
    st = find_table(tables, header_keywords=["サービス名", "status"]) or (tables[0] if tables else {"rows": []})
    salus = []
    for r in st["rows"]:
        name = get(r, "サービス名", "サービス", "service")
        status = get(r, "status", "ステータス").strip().upper()
        if name:
            salus.append({"name": name, "status": "TRUE" if status in ("TRUE", "〇", "○", "YES", "1") else ("FALSE" if status else "")})
    index = {normalize(s["name"]): s for s in salus}

    result = {"TRUE": [], "FALSE": [], "未照合": [], "candidates": []}
    for s in services:
        hit = None
        for key in (s["formal"], s["label"]):
            if key and normalize(key) in index:
                hit = index[normalize(key)]
                break
        if hit is None:
            for key in (s["formal"], s["label"]):
                nk = normalize(key)
                if not nk or len(nk) < 3:
                    continue
                part = [x for x in salus if nk in normalize(x["name"]) or normalize(x["name"]) in nk]
                if len(part) == 1:
                    hit = part[0]
                    break
        display = s["formal"] or s["label"]
        if hit:
            result[hit["status"] or "未照合"].append(f"{display}(Salus: {hit['name']})" if normalize(hit["name"]) != normalize(display) else display)
        else:
            result["未照合"].append(display)
            toks = set(tokens(display))
            cands = [x["name"] for x in salus if toks & set(tokens(x["name"]))]
            result["candidates"].append({"service": display, "node": s["node"], "salus_candidates": cands[:5]})

    n = len(services)
    result["counts"] = {"service_total": n, "TRUE": len(result["TRUE"]), "FALSE": len(result["FALSE"]), "未照合": len(result["未照合"])}
    result["check_line"] = f"Salus照合: TRUE {len(result['TRUE'])} + FALSE {len(result['FALSE'])} + 未照合{len(result['未照合'])} = {n}(サービス一覧{n}件と一致)"
    result["ok"] = len(result["TRUE"]) + len(result["FALSE"]) + len(result["未照合"]) == n
    result["salus_total"] = len(salus)
    dump(result)


if __name__ == "__main__":
    main()
