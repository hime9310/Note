# -*- coding: utf-8 -*-
"""sheet 用: アーキテクチャレビュー票の編集指示を機械的に下ごしらえし(prepare)、
編集データ(JSON)からExcelに書く最終行を作って検算する(final)。
使い方:
  prepare: python scripts/build_ticket.py prepare --template work/template.json --env Hub --csp AWS \
             --check work/04_check.md [--hosting work/03_hosting.md] [--answers work/06_answers.md]
  final:   python scripts/build_ticket.py final --template work/template.json --env Hub \
             --ticket work/05_ticket.json --out work/rows.json
template.json = Excel「表内に存在する行を一覧表示」の返り値(行の配列)。
05_ticket.json = {"env":"DCS Hub","edit":[行…],"add":[行…],"drop":["No",…]}(行のキーは8つ)。
"""
import argparse
import json
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import (read_input, read_json_input, rows_from_json, parse_sections, split_fields,  # noqa: E402
                       normalize, get, first_int, dump)

KEYS = ["No.", "ステータス", "環境", "対応区分", "カテゴリ", "指摘概要", "指摘内容", "対応ガイドライン・参考資料"]
COMMON = "DCS共通"


def clean_rows(rows):
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        row = {}
        for k, v in r.items():
            if k.startswith("@") or k in ("ItemInternalId",):
                continue
            row[k] = "" if v is None else str(v)
        no = get(row, "No.", "No", "NO")
        if not no.strip():
            continue
        out.append(row)
    return out


def env_full(env):
    e = env.replace("DCS", "").strip()
    return f"DCS {e}" if e else env


def in_env(row, envf):
    e = normalize(get(row, "環境"))
    return e in (normalize(COMMON), normalize(envf))


def to8(row):
    r = {}
    for k in KEYS:
        r[k] = get(row, k, k.rstrip("."))
    r["No."] = str(r["No."]).strip()
    if not r["ステータス"]:
        r["ステータス"] = "New"
    return r


def parse_requests(check_text):
    """【構成図チェック結果】の 利用者への確認・依頼 を読む。"""
    sec = parse_sections(check_text)
    lines = []
    for k, v in sec.items():
        if k.startswith("利用者への確認"):
            lines = v
            break
    reqs = []
    for line in lines:
        if line.strip() in ("なし", ""):
            continue
        m = re.match(r"No\.?\s*(\d+)\s*[(（]票\s*[:：]\s*(.*?)[)）]\s*[｜|]\s*(.*)$", line)
        if not m:
            reqs.append({"no": "", "ticket": "なし", "raw": line})
            continue
        rest = split_fields(m.group(3))
        d = {"no": m.group(1), "ticket": m.group(2).strip(), "category": "", "summary": "", "content": "", "raw": line}
        for f in rest:
            if f.startswith("カテゴリ"):
                d["category"] = f.split(":", 1)[-1].split("：", 1)[-1].strip()
            elif f.startswith("指摘概要"):
                d["summary"] = f.split(":", 1)[-1].split("：", 1)[-1].strip()
            elif f.startswith("指摘内容"):
                d["content"] = f.split(":", 1)[-1].split("：", 1)[-1].strip()
        reqs.append(d)
    return reqs


def match_template(ticket, rows, envf):
    if not ticket or ticket == "なし":
        return []
    nt = normalize(ticket)
    hits = [r for r in rows if nt and (nt == normalize(get(r, "指摘概要")) )]
    if not hits:
        hits = [r for r in rows if nt and (nt in normalize(get(r, "指摘概要")) or normalize(get(r, "指摘概要")) in nt) and len(normalize(get(r, "指摘概要"))) >= 3]
    # 環境で絞る(同じ指摘概要が Hub/Disconnected で分かれている場合)
    pref = [r for r in hits if normalize(get(r, "環境")) == normalize(envf)]
    if pref:
        return pref
    return [r for r in hits if in_env(r, envf)] or hits


def cmd_prepare(a):
    rows = clean_rows(rows_from_json(read_json_input(a.template)))
    envf = env_full(a.env)
    g5 = [r for r in rows if not in_env(r, envf)]
    kept = [r for r in rows if in_env(r, envf)]
    check = read_input(a.check)
    reqs = parse_requests(check)
    g2, g3 = [], []
    next_no = max([first_int(get(r, "No."), 0) for r in rows] + [0]) + 1
    for q in reqs:
        hits = match_template(q["ticket"], kept, envf)
        if hits:
            r = hits[0]
            g2.append({"template_no": get(r, "No."), "template_env": get(r, "環境"), "template_summary": get(r, "指摘概要"),
                       "template_content": get(r, "指摘内容"), "template_guide": get(r, "対応ガイドライン・参考資料"),
                       "template_category": get(r, "カテゴリ"), "template_kind": get(r, "対応区分"),
                       "request": q, "ambiguous": [get(x, "No.") for x in hits[1:]]})
        else:
            g3.append({"suggested": {"No.": str(next_no), "ステータス": "New", "環境": envf, "対応区分": "対応必須",
                                     "カテゴリ": q.get("category", ""), "指摘概要": q.get("summary", ""),
                                     "指摘内容": q.get("content", ""), "対応ガイドライン・参考資料": ""},
                       "request": q})
            next_no += 1
    hosting = {}
    if a.hosting and os.path.exists(a.hosting):
        h = read_input(a.hosting)
        sec = parse_sections(h)
        for line in sec.get("判定", []):
            if line.startswith("判定環境"):
                hosting["env_judged"] = line.split(":", 1)[-1].strip()
        for k, v in sec.items():
            if k.startswith("Salus"):
                for line in v:
                    if line.startswith("FALSE"):
                        hosting["salus_false"] = [x.strip() for x in line.split(":", 1)[-1].split(",") if x.strip()]
        cand = [r for r in kept if "廃止" in get(r, "指摘概要") or "Salus" in get(r, "指摘概要")]
        if cand:
            hosting["template_row_for_salus"] = {"no": get(cand[0], "No."), "summary": get(cand[0], "指摘概要"), "content": get(cand[0], "指摘内容")}
    result = {
        "env": envf, "csp": a.csp, "template_total": len(rows),
        "group5_env_excluded": [{"no": get(r, "No."), "summary": get(r, "指摘概要"), "env": get(r, "環境")} for r in g5],
        "kept_rows": [{"no": get(r, "No."), "env": get(r, "環境"), "kind": get(r, "対応区分"), "category": get(r, "カテゴリ"), "summary": get(r, "指摘概要")} for r in kept],
        "group2_candidates": g2, "group3_candidates": g3, "hosting": hosting,
        "next_no": next_no, "kinds_in_template": sorted({get(r, "対応区分") for r in rows if get(r, "対応区分")}),
        "r2_hint": f"R2: ①+②+④+⑤ = {len(rows)}(⑤は{len(g5)}件。①②④は残り{len(kept)}件の内訳)",
    }
    dump(result)


def cmd_final(a):
    rows = clean_rows(rows_from_json(read_json_input(a.template)))
    envf = env_full(a.env)
    ticket = read_json_input(a.ticket)
    if isinstance(ticket, list):  # 行の配列だけ渡された場合はそのまま最終行とみなす
        ticket = {"env": envf, "edit": [], "add": ticket, "drop": [], "_rows_only": True}
    warnings = []
    g5 = [r for r in rows if not in_env(r, envf)]
    kept = [to8(r) for r in rows if in_env(r, envf)]
    kept_nos = {r["No."] for r in kept}
    edits = {str(e.get("No.", e.get("No", ""))).strip(): to8(e) for e in ticket.get("edit", []) if isinstance(e, dict)}
    drops = {str(x).strip() for x in ticket.get("drop", [])}
    for no in edits:
        if no not in kept_nos:
            warnings.append(f"②の No.{no} はテンプレートの対象行にありません(⑤か存在しない No)")
    for no in drops:
        if no not in kept_nos:
            warnings.append(f"④の No.{no} はテンプレートの対象行にありません")
    final = []
    for r in kept:
        if r["No."] in drops:
            continue
        final.append(edits.get(r["No."], r))
    adds = [to8(x) for x in ticket.get("add", []) if isinstance(x, dict)]
    for x in adds:
        if x["No."] in kept_nos:
            warnings.append(f"③の No.{x['No.']} はテンプレートの No と重複しています")
        if not x["指摘内容"]:
            warnings.append(f"③の No.{x['No.']} の指摘内容が空です")
        if not x["環境"]:
            x["環境"] = envf
    final += adds
    for r in final:
        for k in KEYS:
            r[k] = str(r.get(k, ""))
    g2 = len([n for n in edits if n in kept_nos])
    g4 = len([n for n in drops if n in kept_nos])
    g1 = len(kept) - g2 - g4
    g3 = len(adds)
    result = {
        "env": envf, "template_total": len(rows),
        "counts": {"g5": len(g5), "g1": g1, "g2": g2, "g3": g3, "g4": g4},
        "r2_line": f"R2: ①{g1}+②{g2}+④{g4}+⑤{len(g5)} = {g1 + g2 + g4 + len(g5)} / {len(rows)}",
        "r2_ok": g1 + g2 + g4 + len(g5) == len(rows),
        "r3_expected": len(final),
        "r3_hint": f"書き込み件数の期待値 = ①{g1}+②{g2}+③{g3} = {len(final)}",
        "warnings": warnings,
        "rows_json": json.dumps(final, ensure_ascii=False, separators=(",", ":")),
    }
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(result["rows_json"])
        result["out"] = a.out
    dump(result)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("prepare")
    p1.add_argument("--template", required=True)
    p1.add_argument("--env", required=True)
    p1.add_argument("--csp", required=True)
    p1.add_argument("--check", required=True)
    p1.add_argument("--hosting")
    p1.add_argument("--answers")
    p2 = sub.add_parser("final")
    p2.add_argument("--template", required=True)
    p2.add_argument("--env", required=True)
    p2.add_argument("--ticket", required=True)
    p2.add_argument("--out")
    a = ap.parse_args()
    if a.cmd == "prepare":
        cmd_prepare(a)
    else:
        cmd_final(a)


if __name__ == "__main__":
    main()
