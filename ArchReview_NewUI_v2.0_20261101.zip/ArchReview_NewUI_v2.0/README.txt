﻿アーキテクチャレビューAgent New experience 版 v2.0 (2026-11-01)
ファイル名はWindowsで文字化けしないよう半角英数字にしています(中身はUTF-8 BOM付き)。
以前お渡しした NewUI v1.0(2026-10-26)は破棄してください。本セットが New experience 版の v2.0 です。

■ 読む順
1. README.txt(このファイル)
2. 01_Design/Design.md … 設計書。方針・全体構成・工程表・データ・検算・出力形式・観点表の読み方・未決
3. 02_Setup/Setup.md … 手順書。0 SharePoint の確認 → 1 ワークフロー新規作成 → 2 エージェント作成 → 3 指示文 → 4 スキル → 5 ツール → 6 一連テスト → 7 困ったとき
4. 05_Tools/Tools.md … ツール13本の設定値(名前・AIの説明・入力の固定/AI)と、ワークフロー「票_Excel作成」の作り方
5. 06_Tests/TestSet.md … 一連テスト16項目(期待・できるファイル・活動トレース・NGのとき見る所)

■ ファイル
README.txt
01_Design/Design.md
02_Setup/Setup.md
03_Instructions/00_Agent.txt      … 指示文(ビルド > 指示 に貼る。案件フォルダのパスを確認)
04_Skills/diagram.zip  (+ diagram/)   … 構成図Mermaid化。SKILL.md に現行の指示文を貼ってから zip し直す(Setup 4-1)
04_Skills/extract.zip  (+ extract/)   … 構成図情報抽出 + check_r0.py
04_Skills/hosting.zip  (+ hosting/)   … ホスティング判定 + teams_to_text.py / salus_match.py / check_hosting.py
04_Skills/check.zip    (+ check/)     … 構成図チェック + filter_points.py / check_count.py
04_Skills/sheet.zip    (+ sheet/)     … 編集指示・Excel作成 + build_ticket.py
04_Skills/answers.zip  (+ answers/)   … 回答回収 + answers_tool.py / teams_to_text.py
04_Skills/knowledge.zip(+ knowledge/) … ナレッジ文案 + references/knowledge_fields.md
  (全スキル共通: scripts/md_tables.py(md の表の読み込み・正規化)、scripts/status_tool.py(00_status.md の更新))
05_Tools/Tools.md
06_Tests/TestSet.md

■ 前提(決めたこと)
- エージェント1体 + スキル7本。接続エージェント・メモリは使わない。ナレッジは dcs-env-definitions.md だけ(Web 検索は削除)
- ツールは SharePoint / Excel Online / Teams の直接アクション12本 + ワークフロー1本(票_Excel作成)。MCP・クラシック版のフローは使わない
- 参照データ: 01_参照データ(md はそのまま、票のテンプレートは xlsx のテーブル T_アーキテクチャレビュー票)。更新ルールは 01_参照データ の README
- 案件の状態: 02_案件データ/RITM番号/00_status.md(ファイルだけ。リストは後で)。案件フォルダは Agent が作る
- Teams スレッド: 最初の指示でリンクを貼る → Python が3つの ID を取り出して状態に保存 → 以降はその ID で読む
- 指示語: クラシック版 v6.3.1 と同じ(観点取得の2つは不要。「RITMxxx の状況」「スレッドは <リンク>」を追加。「Mermaidを貼り付けます」は廃止)
- Python: 標準ライブラリだけ。入力はツールの返り値を work/ に保存したファイル、出力は JSON。数値・判定はスクリプトの結果をそのまま使う

■ 作業の順番
1. Setup 0〜1(SharePoint の確認、ワークフロー「票_Excel作成」の新規作成とテスト)
2. Setup 2〜3(エージェント作成・モデル・ナレッジ・指示文)
3. Setup 4(diagram の SKILL.md に現行指示文を貼る → 7本の zip を登録)
4. Setup 5(ツール13本の追加と設定 → 5-1 の短い動作確認)
5. Setup 6 + TestSet(一連テスト → 安定性)
6. 問題が出たら、工程名・画面・活動トレース・スクリプトの出力(JSON)を共有 → 該当ファイルだけ直して差し替え

■ 指示語の一覧(Eng 向け)
- RITMxxx 添付した構成図をMermaid化して(+画像、+Teamsスレッドのリンク)
- 構成図情報を抽出して
- ホスティング判定して / ホスティング再判定して
- 構成図チェックして / 2次の構成図チェックして
- アーキテクチャレビュー票の編集指示を作成して / 見直して
- アーキテクチャレビュー票を作成して(Excel)
- 回答を回収して
- ナレッジ文案を作成して
- RITMxxx の状況 / 環境は○○で進めて / CSPは○○で進めて / スレッドは <リンク>
- 直前の出力への指摘(『No.5は不要』『RDSが足りない』など)
