﻿---
name: sheet
description: アーキテクチャレビュー票作成。指示語「アーキテクチャレビュー票の編集指示を作成して」(処理名: 票作成)、「アーキテクチャレビュー票の編集指示を見直して」(処理名: 票作成(見直し))、直前の編集指示への指摘(処理名: 修正反映)、「アーキテクチャレビュー票を作成して」(処理名: Excel生成)のとき使う。テンプレートの行(Excel)と【構成図チェック結果】【ホスティング判定結果】から【編集指示】と編集データ(JSON)を作り 05_edit.md / 05_ticket.json に保存する。Excel生成はワークフロー「票_Excel作成」で行う。ホスティング判定・構成図チェック・回答回収はしない。
---

# 役割
処理名に応じて、アーキテクチャレビュー票の 編集指示作成 → 修正反映 → Excel生成 を行い、結果(【編集指示】/【Excel結果】)を返す。ツールでデータを取るだけで終わらない。ホスティング判定・構成図チェック・回答回収・画像読取はしない。

# 処理名: 票作成 / 票作成(見直し) / 修正反映 / Excel生成。Excel生成は指示語「アーキテクチャレビュー票を作成して」のときだけ。

# 材料の取得(足りなければ2行だけ返し、保存しない)
- 共通: ツール「案件_ファイル取得」で 00_status.md(work/00_status.md)を取得し、対象環境と CSP を読む。CSP が未定なら「【編集指示】状態: 要確認」「- CSPが特定できません。『CSPは○○で進めて』と入力してください」。対象環境が未定なら見込みの環境(Hub)で進め、「## 要確認」に書く。判定環境 = 「DCS 」+対象環境(DCS Hub または DCS Disconnected)。
- 票作成・見直し: 04_check.md(work/04_check.md)、03_hosting.md(work/03_hosting.md。無ければ無いまま)を取得する。04 が無ければ「状態: 要確認」「- 先に『構成図チェックして』が必要です」。見直しのときは 05_edit.md と 06_answers.md も取得する(06 が無ければ「状態: 要確認」「- 先に『回答を回収して』が必要です」)。続けて、CSP に合うツール「票_テンプレート行_AWS」「票_テンプレート行_Azure」「票_テンプレート行_GCP」のいずれか1つを1回だけ実行し、返り値を work/template.json に保存する。
- 修正反映: 05_edit.md(直前の編集指示)と work/template.json 用に CSP のテンプレート行を取得する。ワークフローは使わない。
- Excel生成: 05_ticket.json(work/05_ticket.json)と CSP のテンプレート行(work/template.json)を取得する。05_ticket.json が無ければ「【Excel結果】状態: 要確認」「- 先に『アーキテクチャレビュー票の編集指示を作成して』が必要です」。

# 票作成・見直し
1. `python scripts/build_ticket.py prepare --template work/template.json --env <Hub or Disconnected> --csp <CSP> --check work/04_check.md [--hosting work/03_hosting.md]` を実行し、template_total(全行数NN)、group5_env_excluded(⑤)、kept_rows(対象行)、group2_candidates(②の候補: チェック結果の依頼とテンプレート行の対応)、group3_candidates(③の候補: 対応行が無い依頼)、hosting(判定環境・Salus FALSE のサービスと「廃止予定のサービス」の行)、next_no、kinds_in_template(対応区分の値)を得る。
2. 仕分けを決める(No は変えない):
   ⑤環境対象外: group5 のまま(Excel生成でスクリプトが自動で外す)。②③④にしない。
   ②添削: group2 の各候補について、テンプレート行の指摘内容の末尾に、依頼の文案(request.content)を書き足した「修正後の指摘内容」を作る。元の文は消さない。hosting.salus_false があれば、hosting.template_row_for_salus の行にサービス名を書き足して②にする。
   ③追記: group3 の各候補の suggested を使い、カテゴリ・指摘概要・指摘内容を依頼の文で埋める。環境は判定環境、ステータスは New、対応区分は kinds_in_template から選ぶ(記載・修正の依頼は「対応必須」)。対応ガイドライン・参考資料は空欄(Eng が補う)。
   ④不要: 対象行のうち、この案件に明らかに当てはまらない行(理由を書く)。迷う行は①のまま残す。
   ①流用: 残りすべて。
   見直しのとき: 06_answers.md の回答と指示文の指摘を反映する。回答で解消した②③は指摘内容を更新し、回答の内容を送付済み票の正とする。
3. 検算R2: ①+②+④+⑤ = NN(③は含めない)。
4. 【編集指示】を出力する。①と⑤はNoと指摘概要だけ、②③は全列(Excel生成がそのまま使う)。テンプレートの行を全文転記しない。

# 指摘内容の書き方(②③で文を書くとき。Engが実際に書いている票に合わせる)
- 宛先は利用者。丁寧語。1文目に構成図で見つけた事実(例「構成図内にVPC外のLambdaの記載がございますが」)、続けて依頼または確認(例「利用用途をご教示いただけますでしょうか」「構成図への追記をお願いします」「記載削除をご検討いただけますと幸いです」)、必要なら技術的な理由(例「VPC外のLambdaからPrivate Subnet内のEC2へ直接接続できないため」)。
- カテゴリ: 対象サービス名(例 Lambda / Route 53 / AWS Managed Microsoft AD)。指摘概要: 短い名詞句(例「Lambdaの利用について」「アベイラビリティーゾーンサブネット」)。
- ②の環境・対応区分・対応ガイドライン・参考資料はテンプレートの値のまま。③の環境は判定環境、ステータスは New。参考資料URLを推測で作らない。

# 修正反映
指摘を最小変更で反映し、【編集指示】を全体再出力(差分だけにしない)。検算R2を再実施。③の削除で欠番が出てもNoは付け直さない。反映できない点は「## 要確認」に書く。

# 編集データ(JSON)の形(05_ticket.json。Excel生成でスクリプトが読む)
- {"env":"(判定環境)","edit":[②の行],"add":[③の行],"drop":["④のNo",…]}
- edit と add の各行はキー8つ: "No." / "ステータス" / "環境" / "対応区分" / "カテゴリ" / "指摘概要" / "指摘内容" / "対応ガイドライン・参考資料"。値はすべて文字列("No." も文字列)。②③が無ければ []、④が無ければ []。①⑤の行は入れない。理由の列は入れない。
- 作ったら work/05_ticket.json に書き、`python scripts/build_ticket.py final --template work/template.json --env <Hub or Disconnected> --ticket work/05_ticket.json` を実行して r2_ok が true、warnings が空であることを確かめる(違えば直す)。

# Excel生成
1. `python scripts/build_ticket.py final --template work/template.json --env <Hub or Disconnected> --ticket work/05_ticket.json --out work/rows.json` を実行し、rows_json(Excel に書く最終行の JSON 配列。①②③の行、⑤④は除いた後)と r3_expected(期待件数)、warnings を得る。warnings があれば「## 要確認」に書く。
2. ワークフロー「票_Excel作成」を RITM番号・CSP・rowsJson(=work/rows.json の中身をそのまま1行で)・fileName(=「【案件名】(<RITM番号>)アーキテクチャレビュー票(<CSP>).xlsx」。例: 【案件名】(RITM1234567)アーキテクチャレビュー票(AWS).xlsx)で1回だけ実行し、result(書き込み件数)・fileLink(作成した Excel のリンク)・fileName を得る。JSON を自分で作り直さない。Eng に JSON や行データを聞かない。
3. 検算R3: result の書き込み件数 = r3_expected。不一致は状態を 要確認 にして書く。

# 出力(見出しと順は固定。1項目1行の箇条書き)
票作成・見直し・修正反映:
【編集指示】状態: 完了 or 要確認
## 条件
- RITM: / CSP: / 判定環境: (DCS Hub or DCS Disconnected)
- テンプレート: (CSP)(全行数NN)
## ⑤環境対象外(NN件。Excel生成で自動的に外す)
- No｜指摘概要｜環境列の値
## ①流用(NN件)
- No｜指摘概要
## ②添削(NN件)
- No.｜ステータス｜環境｜対応区分｜カテゴリ｜指摘概要｜修正後の指摘内容｜対応ガイドライン・参考資料｜理由
## ③追記(NN件)
- No.｜ステータス｜環境｜対応区分｜カテゴリ｜指摘概要｜指摘内容｜対応ガイドライン・参考資料｜理由
## ④不要(NN件)
- No｜指摘概要｜理由
## 検算
- R2: ①NN+②NN+④NN+⑤NN = NN / NN
## 要確認
- 反映できない点・warnings(無ければ「なし」)

Excel生成:
【Excel結果】状態: 完了 or 要確認
- 書き込み件数: (result の内容)
- ファイル: fileName
- リンク: fileLink
- 検算R3: NN / NN(①NN+②NN+③NN)

# 保存(出力を作った後、返す前に行う)
- 票作成・見直し・修正反映: ツール「案件_ファイル作成」で 05_edit.md(【編集指示】の全文)、続けて 05_ticket.json(編集データの JSON。上の形)を保存する。`python scripts/status_tool.py --current work/00_status.md --ritm <RITM> --step "票作成(状態)" --next "『アーキテクチャレビュー票を作成して』"` の出力を 00_status.md として保存する。
- Excel生成: 00_status.md だけ更新する(`--step "Excel(状態)" --next "『回答を回収して』"`)。Excel 本体はワークフローが保存する。

# 次の操作(出力の後に指示文の出力形式で書く)
- 票作成・見直し・修正反映: 1. 編集指示を確認し、問題なければ『アーキテクチャレビュー票を作成して』 2. 直す所があれば『No.5は不要』『No.12の指摘内容を○○に』のように入力
- Excel生成: 1. Excelを開いて確認し、必要な行の追加・修正と【案件名】の記入をしてMgmt経由で利用者へ送付 2. 回答が返ったら『回答を回収して』

# 個別厳守
- R2の分母はテンプレートの全行数(template_total)、R3の分母はワークフローが返した件数。Noを列挙するときは昇順・全件(範囲でまとめない)。
- ツールの入力は案件フォルダの材料から自分で作る。Engに JSON・行データ・CSP以外の情報を聞かない。作れないときは状態: 要確認と理由を返す。
- 回答の可否・解消の判断はしない(Engが行う)。
