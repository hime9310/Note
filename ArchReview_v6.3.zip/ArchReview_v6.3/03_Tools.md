﻿# ツール設計一覧(v6.3 / 2026-10-14)

## 1. ツール × Agent 対応表

| ツール名(親Agent>ツール) | フロー名(ワークフロー一覧) | 紐づく子Agent(利用できる対象) | 入力 | 出力 |
|---|---|---|---|---|
| Mermaid生成規則取得 | Mermaid生成規則取得 | 構成図Mermaid化Agent_Diagram | (現状のまま) | (現状のまま) |
| T1 ホスティング判定データ取得 | T1ホスティング判定データ取得(Teams＋KO要件＋Salus) | ホスティング判定Agent_Hosting | RITM番号 | threadText / csp / criteria / salusStatus |
| T2 構成図チェックデータ取得 | T2構成図チェック観点取得 | 構成図チェックAgent_Check | RITM番号 / 対象環境 / CSP / 処理 | checkpoints / count / threadText |
| T3 レビュー票データ取得 | T3アーキテクチャレビュー票テンプレート取得 | アーキテクチャレビュー票作成Agent_Sheet | projectName / CSP | reviewSheetMaster / fileName |
| T4 アーキテクチャレビュー票Excel作成 | T4アーキテクチャレビュー票テンプレート作成 | アーキテクチャレビュー票作成Agent_Sheet | RITM番号 / CSP / 票データ(JSON) | result / fileLink |
| T5 回答済みアーキテクチャレビュー票取得 | T5回答済みアーキテクチャレビュー票取得 | アーキテクチャレビュー票作成Agent_Sheet | RITM番号 | answerSheet / fileName |

- ツールを持たないAgent: DTG_アーキテクチャレビュー親Agent / 構成図情報抽出Agent_Extract
- どのAgentにも付けないフロー: サービス提供対象リソース一覧取得 / ホスティング判定基準取得(T1に統合済み。フローの削除は任意)
- 1つのツールを複数の子に付けない。親には付けない

## 2. 全ツール共通の設定(親Agent>ツール>各ツールの画面)

- 説明: 必須。空だと詳細に「!」が付き、公開してもオーケストレーターが使わない
- 利用できる対象: 紐づく子Agent 1つだけ
- 入力: 原則「AIで動的に入力する」+ カスタマイズで説明文を入れる(T3のprojectNameだけ固定値)
- 実行後: 「生成AIで応答を記述する」(「応答しない」だと子が「受領…未完了」の1行で止まる)
- ツール名・入力名の英数字部分は他と重複させない(ToolIdentifierConflict の原因)
- フローの「エージェントに応答する」の出力名は英数字(threadText など)。変えたら子の指示文も合わせる

## 3. ツールごとの設定値とフローの枠

書き方: 「ツール設定」は親Agent>ツール画面に入れる値。「フローの枠」はフローの章立て(ステップ名)で、内容の記入はそちらで。

### Mermaid生成規則取得
- 現状のまま変更しない(構成図Mermaid化Agent の指示文も変更しない)

### T1 ホスティング判定データ取得
ツール設定
- 名前: T1 ホスティング判定データ取得
- 説明: ホスティング判定Agentが処理名「判定」「再判定」「修正」「ナレッジ文案作成」のとき最初に1回だけ使う。RITM番号を受け取り、Teamsスレッド本文(threadText)、スレッド由来のCSP(csp)、ノックアウト要件一覧(criteria)、Salus Status一覧(salusStatus)を1回でまとめて返す。判定はしない。構成図チェック・票作成では使わない。
- 入力 RITM番号: 依頼文のRITM番号。RITM1234567 の形
- 出力: threadText / csp / criteria / salusStatus
- 実行後: 生成AIで応答を記述する
フローの枠
1. Teamsスレッド取得: 
2. スレッド本文の整形 → threadText: 
3. スレッドからCSP抽出 → csp: 
4. ノックアウト要件一覧取得(SharePoint) → criteria: (後回し: 先頭に「全行数: NN」)
5. Salus Status一覧取得(SharePoint) → salusStatus: 
6. エージェントに応答する: 
- 実測サイズ: criteria 約3,000字 / salusStatus 約10,800字 / threadText 約4,800字

### T2 構成図チェックデータ取得
ツール設定
- 名前: T2 構成図チェックデータ取得
- 説明: 構成図チェックAgentが処理名「1次チェック」「2次チェック」「修正」のとき最初に1回だけ使う。RITM番号・対象環境(Hub または Disconnected)・CSP・処理(1次 または 2次)を受け取り、条件に合う構成図チェック観点だけを圧縮した表(checkpoints。1行目に条件と適用行数)、適用行数(count)、Teamsスレッド本文(threadText。無ければ「なし」)を返す。判定はしない。
- 入力 RITM番号: 依頼文のRITM番号。RITM1234567 の形
- 入力 対象環境: Hub または Disconnected。依頼文の対象環境(【ホスティング判定結果】の判定環境)
- 入力 CSP: AWS / Azure / GCP のいずれか。依頼文のCSP
- 入力 処理: 1次 または 2次。依頼文の処理名が1次チェックなら1次、2次チェックなら2次
- 出力: checkpoints / count / threadText
- 実行後: 生成AIで応答を記述する
フローの枠(作成済み)
1. 構成図チェック観点取得(SharePoint)
2. md文字列(作成) → 3. 本表(作成。参照シートより前) → 4. 行の配列(作成) → 5. 表の行(アレイのフィルター処理) → 6. データ行(作成。見出し2行を除く)
7. 適用行(アレイのフィルター処理。環境・CSP・処理) → 8. 圧縮行(選択。列 1,3,4,7,8,10,11,12,13) → 9. 適用行数(作成) → 10. checkpoints(作成)
11. エージェントに応答する(checkpoints / count / threadText=なし)
- 実測: checkpoints 約6,500字 / rows=15。後回し: threadText のTeams取得

### T3 レビュー票データ取得(手順は 01_T3_Setup.md)
ツール設定
- 名前: T3 レビュー票データ取得
- 説明: アーキテクチャレビュー票作成Agentが処理名「票作成」のとき最初に1回だけ使う。CSPを受け取り、該当CSPのアーキテクチャレビュー票テンプレートの全行(reviewSheetMaster)と取得したファイル名(fileName)を返す。データを返すだけで、票の判断や文章の作成はしない。Excel生成・回答回収では使わない。
- 入力 CSP: AIで動的に入力する / AWS / Azure / GCP のいずれか。依頼文のCSP(【ホスティング判定結果】のCSP)
- 入力 projectName: カスタム値で固定(テンプレートのファイル名の【 】の中の言葉)。案件ごとに違う場合は AIで動的に入力する(要・親の改修)
- 出力: reviewSheetMaster / fileName
- 実行後: 生成AIで応答を記述する
フローの枠(作成済み)
1. アーキテクチャレビュー票テンプレート取得(SharePoint ファイル コンテンツの取得(パスを使用)。パス: …/Agent連携用/【projectName】アーキテクチャレビュー票(CSP).md)
2. エージェントに応答する(reviewSheetMaster = base64ToString(body(…)?['$content']) / fileName = concat(…))

### T4 アーキテクチャレビュー票Excel作成
ツール設定
- 名前: T4 アーキテクチャレビュー票Excel作成
- 説明: アーキテクチャレビュー票作成Agentが処理名「Excel生成」のときだけ1回使う。RITM番号・CSP・票の行のJSON配列を受け取り、CSP別の雛形からExcelを作成して行を書き込み、書き込み結果と件数(result)と作成したExcelのリンク(fileLink)を返す。JSONのキーは No. / ステータス / 環境 / 対応区分 / カテゴリ / 指摘概要 / 指摘内容 / 対応ガイドライン・参考資料 の8つ。票作成・回答回収では使わない。
- 入力 RITM番号: 依頼文のRITM番号。RITM1234567 の形
- 入力 CSP: AWS / Azure / GCP のいずれか。依頼文のCSP
- 入力 票データ(JSON): 会話内の最新の【編集指示】の「アーキテクチャレビュー票」①②③の全行をJSON配列の文字列にしたもの。キーは8つ。"No." は編集指示の番号のまま、"ステータス" は "New"
- 出力: result / fileLink
- 実行後: 生成AIで応答を記述する
フローの枠(作成済み)
1. アーキテクチャレビュー票雛形取得(SharePoint): 
2. アーキテクチャレビュー票作成(SharePoint ファイルの作成): 
3. 行データ解析(JSONの解析): 
4. アーキテクチャレビュー票へ書き込み(Excel 表に行を追加): 
5. エージェントに応答する(result / fileLink)

### T5 回答済みアーキテクチャレビュー票取得
ツール設定
- 名前: T5 回答済みアーキテクチャレビュー票取得
- 説明: アーキテクチャレビュー票作成Agentが処理名「回答回収」のときだけ1回使う。RITM番号を受け取り、Teamsスレッドに添付された回答済みアーキテクチャレビュー票(Excel)を探し、票の全行のテキスト(answerSheet)と読み取ったファイル名(fileName)を返す。添付が無ければ answerSheet に「未添付」を返す。回答の良し悪しは判断しない。票作成・Excel生成では使わない。
- 入力 RITM番号: 依頼文のRITM番号。RITM1234567 の形
- 出力: answerSheet / fileName
- 実行後: 生成AIで応答を記述する
フローの枠(作成済み)
1. 添付ファイル検索: 
2. 条件(添付なし?)
   - True: エージェントに応答する(後回し: answerSheet=未添付 / fileName=なし にそろえる)
   - False: 3. 対象ファイル(作成) → 4. 対象ファイル名(作成) → 5. 回答行取得(Excel) → 6. md行変換(選択) → 7. エージェントに応答する 1(answerSheet / fileName)
