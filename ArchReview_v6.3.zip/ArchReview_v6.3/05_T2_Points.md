﻿# T2 構成図チェック観点取得 — points 出力への変更手順(v6.3 / 2026-10-15)

## ねらい
前段の子Agent(構成図チェック観点抽出Agent_Points)が「ツール結果をそのまま返す」だけで済むように、T2の応答を points 1本にまとめる。points には 条件 / Teamsスレッド / 判定材料(1観点1行) / 下書き(draft) が入る。表の形はやめる。

## 前提
- 04_T2_Draft_Add.md の手順(作成「改行」・選択「下書き行」・作成「draft」)が済んでいること。済んでいなければ先にそれを行う。
- fx の欄には「@」を付けずに式だけ書く。式は改行を入れず1行のまま貼る。アクション名は下の通り(式が名前で参照するため)。
- トリガー入力の内部名: text=RITM番号 / text_1=環境 / text_2=CSP / text_3=処理。

---

## 手順1. 選択「圧縮行」の式を差し替える(表 → 1観点1行)
- どこに: 既存の「圧縮行」を開く
- 名前: 圧縮行(変更なし)
- 差出人: 変更なし(body('適用行'))
- マップ(テキスト モード)の式を次に置き換える
```
concat('- No.', trim(split(item(),'|')?[1]), '｜観点: ', trim(split(item(),'|')?[3]), '｜トリガー: ', trim(split(item(),'|')?[10]), '｜AI判定: ', trim(split(item(),'|')?[8]), '｜方法: ', trim(split(item(),'|')?[12]), '｜区分表: ', trim(split(item(),'|')?[11]), '｜出力: ', trim(split(item(),'|')?[13]))
```
- できる行の例: 「- No.13｜観点: アクセスフロー確認｜トリガー: 常時｜AI判定: ○｜方法: …｜区分表: 記載あり→A、記載なし→D｜出力: …」

## 手順2. 作成「checkpoints」の式を差し替える(見出し行・区切り行をやめる)
- どこに: 既存の「checkpoints」を開く
- 名前: checkpoints(変更なし)
- 入力(fx):
```
concat('条件: 環境=', trim(triggerBody()?['text_1']), ' CSP=', trim(triggerBody()?['text_2']), ' 処理=', trim(triggerBody()?['text_3']), ' / 適用行数: ', string(outputs('適用行数')), decodeUriComponent('%0A'), join(body('圧縮行'), decodeUriComponent('%0A')))
```
- 備考: checkpoints は親Agent側では使わなくなるが、サイズ確認用に残しておいてよい

## 手順3. 作成「points」を追加
- どこに: 「draft」の下の ＋ → アクションの追加 → データ操作「作成」
- 名前: points
- 入力(fx): 次の式を1行のまま貼る
```
concat('【構成図チェック観点】状態: 完了', outputs('改行'), '## 条件', outputs('改行'), '- RITM: ', trim(triggerBody()?['text']), ' ｜ 環境: ', trim(triggerBody()?['text_1']), ' ｜ CSP: ', trim(triggerBody()?['text_2']), ' ｜ 処理: ', trim(triggerBody()?['text_3']), ' ｜ 適用行数: ', string(outputs('適用行数')), outputs('改行'), '## Teamsスレッド', outputs('改行'), '- なし', outputs('改行'), '## 判定材料(1観点1行)', outputs('改行'), join(body('圧縮行'), outputs('改行')), outputs('改行'), '## 下書き(ここから下をそのまま使い、[ ] を埋める)', outputs('改行'), outputs('draft'))
```
- 備考: 「## Teamsスレッド」は今は固定で「- なし」。Teams取得を足したら '- なし' の部分をその出力に差し替える

## 手順4. 「エージェントに応答する」の出力を整理
- どこに: 一番下の「エージェントに応答する」
- 追加: 出力を追加する > テキスト / 名前 points / 値(fx) `outputs('points')` / 説明「構成図チェック観点(条件・判定材料・下書き)の全文。そのまま返す」
- 削除: checkpoints と draft の出力を ×(残すと前段の子がどれを返すか迷う)
- 残す: count / threadText / points の3つ

## 手順5. 保存 → テスト → 公開
1. 「下書きを保存する」→「テスト」→ 手動 → RITM1234567 / Hub / AWS / 1次 → 実行
2. 活動で「エージェントに応答する」の points を確認: 1行目「【構成図チェック観点】状態: 完了」、「## 判定材料」と「## 下書き」の下にそれぞれ適用行数と同じ数の行がある
3. 「公開」

## 手順6. 親Agent側
06_Points_Setup.md の通り(新しい子の作成 → T2の付け替え → 指示文 → 公開 → テスト)。
