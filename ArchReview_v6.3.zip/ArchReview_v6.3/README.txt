﻿アーキテクチャレビューAgent v6.3 (2026-10-14)
ファイル名はWindowsで文字化けしないよう半角英数字にしています。

■ ファイル名の対応
README.txt                … このファイル(対応表・作業順・後回し一覧)
01_T3_Setup.md            … T3 レビュー票データ取得 の手順(現状の整理 → 親への付け直し → テスト)
02_Instructions/00_Parent.txt   … DTG_アーキテクチャレビュー親Agent の指示文(変更なし)
02_Instructions/01_Diagram.txt  … 構成図Mermaid化Agent_Diagram(空。現行の指示文をそちらで貼って保管)
02_Instructions/02_Extract.txt  … 構成図情報抽出Agent_Extract(変更なし)
02_Instructions/03_Hosting.txt  … ホスティング判定Agent_Hosting(変更なし)
02_Instructions/04_Check.txt    … 構成図チェックAgent_Check(変更なし)
02_Instructions/05_Sheet.txt    … アーキテクチャレビュー票作成Agent_Sheet(今回修正: T3の出力名に合わせ、申し送りを外した)
03_Tools.md               … ツール設計一覧(ツール×Agent対応表 / 共通設定 / ツールごとの設定値とフローの枠)

前回までのZIP(貼り付け用_Ver6.2 / アーキテクチャレビューAgent_Ver.6.3)は捨ててください。このZIPが最新です。

■ 作業の順番
1. 01_T3_Setup.md の通りに T3 を親Agentへ付け直す
2. 05_Sheet.txt を アーキテクチャレビュー票作成Agent_Sheet に貼る(【/】3か所を「/」で選び直す)
   他のAgentの指示文は今Studioに入っているものと同じなので貼り替え不要(念のためZIPに同梱)
3. 03_Tools.md で T1〜T5 の 説明・入力・実行後 を見直す(実行後はすべて「生成AIで応答を記述する」)
4. 親Agentを公開 → 新しいテストセッションで 判定して → 構成図チェックして → レビュー票を作成して → Excelを作成して

■ 指示文を貼るときの注意
- 【/名前】の箇所は貼り付け後に「/」を入力してツールか子Agentを選び直す(文字のままでは動かない)
  個数: Parent 5 / Hosting 1 / Check 1 / Sheet 3 / Extract 0
- 名前はヒント。実際のツール名が「T3 レビュー票データ取得」のように番号付きでも、その名前を含むものを選ぶ

■ 設定の前提(変えない)
- 親Agent: 一般知識=オン / Web検索=オフ / ツールなし
- 子Agent: 入力定義なし / 出力 result(文字列)あり / 親から呼ぶときの実行後=応答しない
- ツール(親Agent>ツール): 説明=必須 / 入力=AIで動的に入力する / 実行後=生成AIで応答を記述する
- 子Agent名の末尾: _Diagram / _Extract / _Hosting / _Check / _Sheet

■ 後回し(今は不要)
- T5: True側(添付なし)の「エージェントに応答する」も answerSheet=未添付 / fileName=なし にそろえる
- T1: criteria の先頭に「全行数: NN」を付ける
- T2: Teamsスレッド本文(threadText)の取得を足す(今は「なし」固定)
- 申し送り(動作検証必要=○): T3 にサービス提供対象リソース一覧の取得を足してから、05_Sheet の票作成に(c)を戻す
