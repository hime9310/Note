﻿アーキテクチャレビューAgent v6.3 (2026-10-14)
ファイル名はWindowsで文字化けしないよう半角英数字にしています。

■ ファイル名の対応
README.txt                … このファイル(対応表・作業順・後回し一覧)
01_T3_Setup.md            … T3 レビュー票データ取得 の手順(現状の整理 → 親への付け直し → テスト)
02_Instructions/00_Parent.txt   … DTG_アーキテクチャレビュー親Agent の指示文(「観点を取得して」「2次の観点を取得して」を追加。【/】6か所)
02_Instructions/01_Diagram.txt  … 構成図Mermaid化Agent_Diagram(空。現行の指示文をそちらで貼って保管)
02_Instructions/02_Extract.txt  … 構成図情報抽出Agent_Extract(変更なし)
02_Instructions/03_Hosting.txt  … ホスティング判定Agent_Hosting(変更なし)
02_Instructions/04_Check.txt    … 構成図チェックAgent_Check(ツールなし版。【構成図チェック観点】の下書きを埋める)
02_Instructions/05_Sheet.txt    … アーキテクチャレビュー票作成Agent_Sheet(T3の出力名に合わせ、申し送りを外した)
02_Instructions/06_Points.txt   … 構成図チェック観点抽出Agent_Points(新設。T2結果をそのまま返す)
03_Tools.md               … ツール設計一覧(ツール×Agent対応表 / 共通設定 / ツールごとの設定値とフローの枠)
04_T2_Draft_Add.md        … T2に下書き(draft)を足す手順(済みなら不要)
05_T2_Points.md           … T2の応答を points 1本にする手順(圧縮行・checkpoints の式差し替え、points 追加、出力整理)
06_Points_Setup.md        … 新しい子 構成図チェック観点抽出Agent_Points の作成〜テストまでの手順

前回までのZIP(貼り付け用_Ver6.2 / アーキテクチャレビューAgent_Ver.6.3)は捨ててください。このZIPが最新です。

■ 作業の順番(構成図チェックの安定化)
1. 05_T2_Points.md の通りに T2 を変更して公開(04_T2_Draft_Add.md が未了ならそれを先に)
2. 06_Points_Setup.md の通りに 新しい子を作成 → T2を付け替え → 06_Points.txt / 04_Check.txt / 00_Parent.txt を貼る → 公開
3. 新しいテストセッションで 判定して → 観点を取得して → 構成図チェックして
4. 通ったら 01_T3_Setup.md と 05_Sheet.txt で レビュー票作成 へ(T3〜T5の実行後は「生成AIで応答を記述する」)

■ 指示文の【/】の個数
Parent 6 / Points 1 / Hosting 1 / Sheet 3 / Check 0 / Extract 0

■ 指示文を貼るときの注意
- 【/名前】の箇所は貼り付け後に「/」を入力してツールか子Agentを選び直す(文字のままでは動かない)
- 名前はヒント。実際のツール名が「T3 レビュー票データ取得」のように番号付きでも、その名前を含むものを選ぶ

■ 設定の前提(変えない)
- 親Agent: 一般知識=オン / Web検索=オフ / ツールなし
- 子Agent: 入力定義なし / 出力 result(文字列)あり / 親から呼ぶときの実行後=応答しない
- ツール(親Agent>ツール): 説明=必須 / 入力=AIで動的に入力する / 実行後=生成AIで応答を記述する
- 子Agent名の末尾: _Diagram / _Extract / _Hosting / _Points / _Check / _Sheet

■ 後回し(今は不要)
- T5: True側(添付なし)の「エージェントに応答する」も answerSheet=未添付 / fileName=なし にそろえる
- T1: criteria の先頭に「全行数: NN」を付ける
- T2: Teamsスレッド本文(threadText)の取得を足す(今は「なし」固定)
- 申し送り(動作検証必要=○): T3 にサービス提供対象リソース一覧の取得を足してから、05_Sheet の票作成に(c)を戻す
