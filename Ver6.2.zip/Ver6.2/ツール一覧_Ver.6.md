# アーキテクチャレビューAgent ツール一覧 Ver.6(名前・用途・設計)

| 項目 | 内容 |
|---|---|
| 版 | Ver.6(2026-10-08)。旧: ツール一覧v2.3 / ツール設計書v2.0 |
| 方針 | **1子Agent=取得ツール1本**。子が判定に使う資料は1本のフローが1回で全部返す。副作用のある T4 と回答取得の T5 だけ別 |
| 旧ツールとの対応 | T1 = ①+③+④(作成済み「ホスティング判定データ取得(Teams+KO要件+Salus)」)/ T2 = ①+②+参照一覧 / T3 = ①+⑤+⑨ / T4 = ⑥ / T5 = ⑦ / ⑧ナレッジ追記は手動(作らない)。個別①②③④⑤⑨は、T1〜T3の完成後にAgentから外す(フローは残してよい) |
| 作り方の共通 | エージェント フロー。トリガー「エージェントがフローを呼び出したとき」/ 応答「エージェントに応答する」(非同期応答オフ)/ 出力はすべてテキスト / 100秒以内に応答 / SharePointのパスはピッカーで選択 |
| 参照データ | すべてmd表(設計原則11)。Excelで編集 → `xlsx2md.py` で変換 → AI連携用フォルダへ配置。観点表は `--drop-columns "判定トリガー（削除予定）,備考"` でAgent用に軽くする |

---

## 0. 一覧

| ID | ツール名(Copilot Studio上) | 持ち主 | 入力 | 出力 | 状況 |
|---|---|---|---|---|---|
| T1 | ホスティング判定データ取得 | ホスティング判定Agent | RITM番号 / CSP(任意) | threadText / csp / criteria / salusStatus | **作成済み**(名称の末尾(Teams+KO要件+Salus)は任意)。criteria先頭に「全行数: NN」を付ける改修のみ |
| T2 | 構成図チェックデータ取得 | 構成図チェックAgent | RITM番号 / 環境 / CSP / 処理 | threadText / checkpoints / count / refList | **新規** |
| T3 | レビュー票データ取得 | アーキテクチャレビュー票作成Agent | RITM番号 / CSP(任意) | threadText / csp / template / templateCount / resourceList | **新規** |
| T4 | アーキテクチャレビュー票Excel作成 | アーキテクチャレビュー票作成Agent | RITM番号 / CSP / 行データ(JSON) | result(件数)/ fileLink | 作成済み(変更なし) |
| T5 | 回答済みアーキテクチャレビュー票取得 | アーキテクチャレビュー票作成Agent | RITM番号 | answerSheet / fileName | 作成済み(変更なし) |

---

## 1. 共通部品(T1〜T3で同じ作り)

### 1.1 Teams部(ツール①の中身をそのまま使う)

チャネル「共通_Engineering標準化」のメッセージからRITM番号を含む親投稿を特定 → 返信を全件取得 → HTMLをテキスト化 → 添付一覧を整形 → 本文からCSP(AWS / Azure / GCP / 不明)を判定(入力CSPがあれば優先)→ `threadText` と `csp`。見つからなければ `threadText` = 「該当スレッドなし」。

### 1.2 md取得部(1ファイル)

| # | アクション | 名前 | 設定 |
|---|---|---|---|
| 1 | SharePoint「パスによるファイル コンテンツの取得」 | — | サイト: JP CMS / ファイル: AI連携用フォルダの対象md / コンテンツ タイプを推測する: はい |
| 2 | 作成 | `md文字列` | ファイル コンテンツ(base64で返る場合は `base64ToString(body('…')?['$content'])`) |
| 3 | 作成 | `本表` | `first(split(outputs('md文字列'), '<!-- 参照シート ここから -->'))`(参照シートを切り離す。無いファイルでも同じ式でよい) |
| 4 | 作成 | `行の配列` | `split(replace(outputs('本表'), decodeUriComponent('%0D'), ''), decodeUriComponent('%0A'))` |
| 5 | アレイのフィルター処理 | `表の行` | 元: `outputs('行の配列')` / 条件: `item()` が 次の値で始まる `\|`(半角の縦棒1文字) |
| 6 | 作成 | `データ行` | `skip(body('表の行'), 2)`(見出し行・区切り行を除く) |
| 7 | 作成 | `全行数` | `length(outputs('データ行'))` |

応答に入れる本文は `concat('全行数: ', string(outputs('全行数')), decodeUriComponent('%0A'), outputs('本表'))`。参照シートが必要なときは `last(split(outputs('md文字列'), '<!-- 参照シート ここから -->'))` を別出力にする。

---

## T1 ホスティング判定データ取得

| 項目 | 内容 |
|---|---|
| 用途 | 判定・再判定に必要な3資料を1回で返す。順番ミス・呼び忘れ・部分取得をなくす |
| 入力 | RITM番号(テキスト・必須)/ CSP(テキスト・任意) |
| 処理 | 1.1 Teams部 → 1.2 md取得部(ノックアウト要件一覧.md)→ 1.2 md取得部(Salus_Status一覧.md。全行数は不要)→ 応答 |
| 出力 | `threadText` / `csp` / `criteria`(「全行数: NN」+ノックアウト要件一覧の全文)/ `salusStatus`(全文) |
| 参照データ | ノックアウト要件一覧.md(列: ID / No. / 要因 / 具体的なケース / 判断区分 / 備考。IDはKO-01…を先頭列に追加)/ Salus_Status一覧.md |
| 状況 | 作成済み。改修は `criteria` の先頭に全行数を付けるだけ(手順3〜7を挟む)。出力名が本書と違う場合はInstructions集の説明文を実物に合わせる |

## T2 構成図チェックデータ取得(新規)

| 項目 | 内容 |
|---|---|
| 用途 | 対象環境・CSP・1次/2次に該当する観点だけを、適用行数と一緒に返す。Agentに全行・全列を渡さない(サイズ対策) |
| 入力 | RITM番号 / 環境(Hub または Disconnected)/ CSP(AWS / Azure / GCP)/ 処理(1次 または 2次) |
| 処理 | 1.1 Teams部 → 1.2 md取得部(構成図チェック観点.md。Agent用の軽い版)→ 8. アレイのフィルター処理 `適用行`(元: `outputs('データ行')`。条件は下)→ 9. 作成 `適用行数` = `length(body('適用行'))` → 10. 作成 `見出し2行` = `join(take(body('表の行'), 2), decodeUriComponent('%0A'))` → 11. 作成 `参照一覧` = `last(split(outputs('md文字列'), '<!-- 参照シート ここから -->'))` → 応答 |
| 適用行の条件(詳細モード。`text_1`=環境、`text_2`=CSP、`text_3`=処理。実際のトリガー入力名に合わせる。縦棒は半角1文字) | `@and(or(contains(trim(split(item(),'\|')?[6]), triggerBody()?['text_1']), contains(trim(split(item(),'\|')?[6]), '共通')), or(contains(trim(split(item(),'\|')?[5]), triggerBody()?['text_2']), contains(trim(split(item(),'\|')?[5]), '共通')), or(equals(triggerBody()?['text_3'], '2次'), contains(trim(split(item(),'\|')?[9]), '1次')))` |
| Agent用mdの列順(固定。xlsx2md `--drop-columns "判定トリガー（削除予定）,備考"` で作る) | 1 No / 2 大分類 / 3 チェック観点 / 4 判断基準 / 5 対象CSP / 6 環境 / 7 対応するテンプレートの項目(No) / 8 AI判定可否 / 9 チェックタイミング / 10 判定トリガー / 11 ネクストアクション / 12 AI判定方法 / 13 AI出力内容。列を足すときは末尾に |
| 出力 | `threadText` / `checkpoints`(「観点表: ファイル名 / 条件: 環境=… CSP=… 処理=… / 適用行数: NN」+見出し2行+適用行)/ `count`(適用行数)/ `refList`(参照シート「Vnet・VPC外に記載する代表サービス一覧」) |
| 例外 | 適用行数0 → そのまま「適用行数: 0」を返す(Agentが要確認にする) |
| 状況 | 新規。環境列の値は「DCS Hub / DCS Disconnected / DCS共通」なので入力「Hub」「Disconnected」で contains 判定できる |

## T3 レビュー票データ取得(新規)

| 項目 | 内容 |
|---|---|
| 用途 | 票作成に必要な3資料を1回で返す。テンプレート全行数を返して検算R2の分母にする |
| 入力 | RITM番号 / CSP(任意。空ならTeams部のcspを使う) |
| 処理 | 1.1 Teams部 → 作成 `対象CSP` = `if(empty(triggerBody()?['text_1']), outputs('csp'), triggerBody()?['text_1'])` → 1.2 md取得部(テンプレート。ファイル パスを式で選ぶ: `if(equals(outputs('対象CSP'),'AWS'), '<AWSのパス>', if(equals(outputs('対象CSP'),'Azure'), '<Azureのパス>', '<GCPのパス>'))`)→ 1.2 md取得部(サービス提供対象リソース一覧.md。全行数不要)→ 応答 |
| 出力 | `threadText` / `csp`(対象CSP)/ `template`(「全行数: NN」+テンプレート全文)/ `templateCount` / `resourceList` |
| 参照データ | アーキテクチャレビュー票テンプレート(AWS/Azure/GCP).md(列: No / ステータス / 環境 / 対応区分 / カテゴリ / 指摘概要 / 指摘内容 / 対応ガイドライン・参考資料)/ サービス提供対象リソース一覧.md |
| 状況 | 新規 |

## T4 アーキテクチャレビュー票Excel作成

変更なし(旧⑥)。雛形xlsxをコピー → 送付フォルダに「【案件名】(RITMxxxxxxx)アーキテクチャレビュー票(CSP).xlsx」→ JSON解析 → Officeスクリプト「アーキテクチャレビュー_行追加」でテーブル `T_アーキテクチャレビュー票` へ追加 → `result`(件数)/ `fileLink`。「No.」はJSONの値をそのまま転記。

## T5 回答済みアーキテクチャレビュー票取得

変更なし(旧⑦。詳細はツール設計書v1.1)。チャネルフォルダからRITM番号を含む最新の票xlsxを特定 → 全行をmd表 → `answerSheet`(「対象ファイル: / 全行数: NN件 / md表」)/ `fileName`。未添付時は固定メッセージ。

---

## 2. 移行手順

| # | 作業 | 備考 |
|---|---|---|
| 1 | ノックアウト要件一覧.md に ID列(KO-01…)を追加。T1に手順3〜7を挟み `criteria` 先頭に全行数を付ける | 既存の出力名が違えばInstructions集の説明文を合わせる |
| 2 | 観点表Excel → `xlsx2md.py --drop-columns "判定トリガー（削除予定）,備考"` → 構成図チェック観点.md を配置 | 1ファイル(本表+参照シート) |
| 3 | T2を新規作成(Teams部はT1からコピー)。入力4つ。テスト: 環境=Hub, CSP=AWS, 処理=1次 で `count` が目視と一致 | 列位置は上表のとおり |
| 4 | T3を新規作成。テスト: CSP別にテンプレート全行数が一致 | — |
| 5 | 公開 → 各子Agentにツールを追加し、説明文をInstructions集Ver.6の表から貼る → 個別①②③④⑤⑨を各Agentから外す | ⑧は作らない |
| 6 | Instructions集Ver.6を親・子に貼る(構成図Mermaid化Agentは説明文と出力のみ) | — |
| 7 | 通しテスト: 1案件でフェーズ1〜5 → 回答回収 → 2次 → ナレッジ文案 | 状態行と次の操作が噛み合うか確認 |

## 3. 変更時の注意

- ツール名・出力名・列順を変えたら、Instructions集の説明文と子のInstructions(出力名を参照している箇所)を同時に直す。T2は列番号を参照する式も直す。
- 出力が大きくなったら: 列を落とす(xlsx2md `--drop-columns`)→ 参照シートを別出力に → 絞り込み条件を見直す、の順で対処する。
