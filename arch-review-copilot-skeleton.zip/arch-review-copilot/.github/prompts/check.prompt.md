---
agent: check
description: 構成図チェック(1次)を実行する
---
RITM ${input:ritm:RITM1234567} の構成図チェック(1次)を行ってください。
対象環境と CSP は cases/${input:ritm}/output/03_hosting.md の判定結果を使ってください。
結果は cases/${input:ritm}/output/04_check.md に書き、最後に「結論」と「次にEngがやること」だけをチャットに表示してください。
