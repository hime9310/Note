---
agent: hosting
description: ホスティング判定を実行する
---
RITM ${input:ritm:RITM1234567} のホスティング判定を行ってください。
材料: cases/${input:ritm}/output/02_inventory.md、Teamsスレッド(graph-ro で取得)、reference/ko_requirements.md、reference/salus.md。
結果は cases/${input:ritm}/output/03_hosting.md に書き、最後に「要確認」と「ヒアリング文」だけを要約してチャットに表示してください。
