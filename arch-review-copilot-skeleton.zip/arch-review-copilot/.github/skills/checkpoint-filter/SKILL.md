---
name: checkpoint-filter
description: 構成図チェック観点表(reference/checkpoints.md)を 環境・CSP・1次/2次 で絞り込み、判定材料と下書きを作る
---
# いつ使うか
構成図チェック(/check)の最初に必ず1回実行する。観点表を手で読んで絞り込まない。

# 使い方
python scripts/filter_checkpoints.py <RITM> --env Hub|Disconnected --csp AWS|Azure|GCP --phase 1次|2次

# 出力
- cases/<RITM>/output/04_points.md … 判定材料(1観点1行: No｜観点｜トリガー｜AI判定｜方法｜区分表｜出力)
- cases/<RITM>/output/04_draft.md  … 【構成図チェック結果】の下書き([ ] を埋める)
- 標準出力に 適用行数(検算の分母)
