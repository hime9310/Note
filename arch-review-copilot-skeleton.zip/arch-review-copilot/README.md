# arch-review-copilot (PoC skeleton)
GitHub Copilot(VS Code)でアーキテクチャレビューを行うためのリポジトリ雛形。
- .github/agents/        … カスタムエージェント(工程ごと)
- .github/prompts/       … /judge /check などの入口
- .github/skills/        … スクリプトの使い方(スキル)
- mcp_graph_ro/          … 読み取り専用 Graph MCP サーバー(Teamsスレッド・SharePointファイル取得)
- scripts/               … 観点の絞り込み・検算・Excel書き込み(決定的な処理)
- reference/             … KO要件 / 観点表 / テンプレート / Salus(SharePoint から同期またはコピー)
- cases/<RITM>/          … 案件ごとの入出力(リポジトリにはコミットしない。.gitignore 済み)
