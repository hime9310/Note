"""
読み取り専用 Microsoft Graph MCP サーバー(アーキテクチャレビュー用)
- 委任権限(ユーザー本人のサインイン)でのみ動作。書き込み系の API は一切呼ばない
- 対象のチーム/チャネル/サイトは config.json の許可リストに固定
- 起動: python server.py  (VS Code の .vscode/mcp.json から stdio で起動される)
"""
import html
import json
import os
import pathlib
import re
import sys

import msal
import requests
from msal_extensions import PersistedTokenCache, build_encrypted_persistence
from mcp.server.fastmcp import FastMCP

GRAPH = "https://graph.microsoft.com/v1.0"
SCOPES = [
    "ChannelMessage.Read.All",   # チャネルの投稿・返信を読む(管理者同意が必要)
    "Team.ReadBasic.All",        # チーム名の参照(任意)
    "Channel.ReadBasic.All",     # チャネル名の参照(任意)
    "Sites.Read.All",            # SharePoint のファイル読み取り
    "User.Read",                 # サインイン(既定で承認済み)
]
CONFIG_PATH = os.environ.get("ARCHREVIEW_CONFIG", str(pathlib.Path(__file__).with_name("config.json")))
CONFIG = json.load(open(CONFIG_PATH, encoding="utf-8"))

mcp = FastMCP("graph-ro")


# ---------- 認証(MSAL / パブリッククライアント / 認可コード + PKCE) ----------
def _token_cache() -> PersistedTokenCache:
    cache_file = pathlib.Path.home() / ".archreview" / "token_cache.bin"
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    # Windows では DPAPI、macOS は Keychain で暗号化して保存される
    return PersistedTokenCache(build_encrypted_persistence(str(cache_file)))


def _app() -> msal.PublicClientApplication:
    return msal.PublicClientApplication(
        CONFIG["client_id"],
        authority=f"https://login.microsoftonline.com/{CONFIG['tenant_id']}",
        token_cache=_token_cache(),
    )


def _access_token() -> str:
    app = _app()
    accounts = app.get_accounts()
    result = app.acquire_token_silent(SCOPES, account=accounts[0]) if accounts else None
    if not result:
        if CONFIG.get("auth_flow") == "devicecode":
            flow = app.initiate_device_flow(scopes=SCOPES)
            print(flow["message"], file=sys.stderr)          # 表示されたコードをブラウザで入力
            result = app.acquire_token_by_device_flow(flow)
        else:
            # ブラウザが開き本人がサインイン。リダイレクトは http://localhost:<port>(登録時に設定)
            result = app.acquire_token_interactive(SCOPES, port=CONFIG.get("redirect_port", 53682))
    if "access_token" not in result:
        raise RuntimeError(f"サインイン失敗: {result.get('error')} {result.get('error_description')}")
    return result["access_token"]


def _get(url: str, params: dict | None = None) -> dict:
    r = requests.get(url, headers={"Authorization": f"Bearer {_access_token()}"}, params=params, timeout=30)
    r.raise_for_status()
    return r.json()


def _get_all(url: str, params: dict | None = None, limit: int = 500) -> list[dict]:
    items: list[dict] = []
    data = _get(url, params)
    while True:
        items.extend(data.get("value", []))
        nxt = data.get("@odata.nextLink")
        if not nxt or len(items) >= limit:
            return items
        data = _get(nxt)


# ---------- 補助 ----------
def _plain(msg: dict) -> str:
    body = msg.get("body", {}).get("content", "") or ""
    text = re.sub(r"<[^>]+>", "", body) if msg.get("body", {}).get("contentType") == "html" else body
    return html.unescape(text).strip()


def _who(msg: dict) -> str:
    u = (msg.get("from") or {}).get("user") or {}
    return u.get("displayName") or "(不明)"


def _channel(key: str) -> tuple[str, str]:
    c = CONFIG["channels"].get(key)
    if not c:
        raise ValueError(f"許可リストに無いチャネルです: {key}")
    return c["team_id"], c["channel_id"]


# ---------- ツール(すべて読み取り専用) ----------
@mcp.tool()
def find_thread(channel_key: str, ritm: str) -> str:
    """指定チャネル(config のキー)で RITM 番号を含む親投稿を探し、messageId・投稿者・日時・冒頭を返す。"""
    team_id, channel_id = _channel(channel_key)
    msgs = _get_all(f"{GRAPH}/teams/{team_id}/channels/{channel_id}/messages", {"$top": 50}, limit=300)
    hits = [m for m in msgs if ritm in _plain(m) or ritm in (m.get("subject") or "")]
    if not hits:
        return f"{ritm} を含む投稿は見つかりませんでした。"
    lines = [f"- messageId: {m['id']} ｜ {_who(m)} ｜ {m.get('createdDateTime','')} ｜ {_plain(m)[:80]}" for m in hits]
    return "\n".join(lines)


@mcp.tool()
def get_thread(channel_key: str, message_id: str) -> str:
    """親投稿と全返信を時系列の Markdown で返す(ホスティング判定の threadText 相当)。"""
    team_id, channel_id = _channel(channel_key)
    base = f"{GRAPH}/teams/{team_id}/channels/{channel_id}/messages/{message_id}"
    root = _get(base)
    replies = _get_all(f"{base}/replies", {"$top": 50})
    replies.sort(key=lambda m: m.get("createdDateTime", ""))
    out = [f"# Teamsスレッド(messageId: {message_id})", "", f"## 親投稿 ｜ {_who(root)} ｜ {root.get('createdDateTime','')}", _plain(root), ""]
    for i, m in enumerate(replies, 1):
        out += [f"## 返信{i} ｜ {_who(m)} ｜ {m.get('createdDateTime','')}", _plain(m), ""]
    return "\n".join(out)


@mcp.tool()
def list_folder(site_key: str, path: str) -> str:
    """SharePoint の指定フォルダ(サイト基点の相対パス)の一覧を返す。"""
    site = CONFIG["sites"][site_key]
    full = f"{site['base_path']}/{path}".strip("/")
    items = _get_all(f"{GRAPH}/sites/{site['site_id']}/drive/root:/{full}:/children")
    return "\n".join(f"- {'[D]' if 'folder' in it else '[F]'} {it['name']} ({it.get('size', 0)} bytes)" for it in items)


@mcp.tool()
def get_file(site_key: str, path: str) -> str:
    """SharePoint のファイルを取得する。md/txt はそのまま本文を返し、xlsx 等は cases/ 配下に保存して保存先パスを返す。"""
    site = CONFIG["sites"][site_key]
    full = f"{site['base_path']}/{path}".strip("/")
    r = requests.get(
        f"{GRAPH}/sites/{site['site_id']}/drive/root:/{full}:/content",
        headers={"Authorization": f"Bearer {_access_token()}"}, timeout=60,
    )
    r.raise_for_status()
    name = pathlib.PurePosixPath(path).name
    if name.lower().endswith((".md", ".txt", ".csv")):
        return r.content.decode("utf-8-sig")
    dest = pathlib.Path(CONFIG.get("download_dir", "cases")) / "_downloads" / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(r.content)
    return f"saved: {dest}"


if __name__ == "__main__":
    mcp.run()  # stdio
