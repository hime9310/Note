"""構成図チェック観点表(md 表)を 環境・CSP・処理 で絞り込み、判定材料と下書きを書く(Copilot Studio の T2 相当)。"""
import argparse
import pathlib
import re

COLS = {"no": 1, "cat": 2, "point": 3, "criteria": 4, "csp": 5, "env": 6, "ticket": 7, "ai": 8, "timing": 9, "trigger": 10, "next": 11, "method": 12, "output": 13}


def rows(md: str):
    main = md.split("<!-- 参照シート ここから -->")[0]
    table = [l for l in main.replace("\r", "").split("\n") if l.lstrip().startswith("|")]
    for line in table[2:]:  # 見出し行と区切り行を除く
        cells = [c.strip() for c in line.split("|")]
        if len(cells) > 13 and cells[1]:
            yield cells


def applies(c, env, csp, phase):
    return (env in c[COLS["env"]] or "共通" in c[COLS["env"]]) and (csp in c[COLS["csp"]] or "共通" in c[COLS["csp"]]) and (phase == "2次" or "1次" in c[COLS["timing"]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ritm"); ap.add_argument("--env", required=True); ap.add_argument("--csp", required=True); ap.add_argument("--phase", default="1次")
    a = ap.parse_args()
    md = pathlib.Path("reference/checkpoints.md").read_text(encoding="utf-8-sig")
    sel = [c for c in rows(md) if applies(c, a.env, a.csp, a.phase)]
    out = pathlib.Path("cases") / a.ritm / "output"; out.mkdir(parents=True, exist_ok=True)

    points = [f"- No.{c[1]}｜観点: {c[3]}｜トリガー: {c[10]}｜AI判定: {c[8]}｜方法: {c[12]}｜区分表: {c[11]}｜出力: {c[13]}" for c in sel]
    (out / "04_points.md").write_text(f"## 条件\n- RITM: {a.ritm} ｜ 環境: {a.env} ｜ CSP: {a.csp} ｜ 処理: {a.phase} ｜ 適用行数: {len(sel)}\n## 判定材料(1観点1行)\n" + "\n".join(points) + "\n", encoding="utf-8")

    def line(c):
        t = f"(票No: {c[7]})" if c[7] and c[7] != "-" else ""
        return f"- No.{c[1]} {c[3]} → [区分]{t}｜確認ポイント: {c[4]}｜構成図の状態: [判定と根拠]｜次の対応: [対応]"
    phase_desc = "2次チェック(利用者の回答・修正後の構成図を同じ観点で再確認)" if a.phase == "2次" else "1次チェック(票を送る前に、構成図に必要な記載が揃っているかを観点表で確認)"
    draft = [
        "【構成図チェック結果】状態: [完了 or 要確認]", "## このチェックについて",
        f"- 処理: {phase_desc} ｜ {a.ritm} ｜ 環境: {a.env} ｜ CSP: {a.csp}", f"- 関わる観点: {len(sel)}件",
        "- 結論: 対応が必要 [NN]件(票で確認[NN]・利用者へ依頼[NN]・Eng目視確認[NN]・要人手確認[NN])、問題なし [NN]件、対象外 [NN]件",
        "- 次にEngがやること: [1〜2文]",
        "- 区分の意味: 問題なし=対応不要 ｜ 票で確認=票で利用者に確認 ｜ 利用者へ依頼=票で記載・修正を依頼 ｜ Eng目視確認=Engが目で確認(票に入れない) ｜ 要人手確認=AIの判定案をEngが確定 ｜ 対象外=この案件に当てはまらない",
        "## 結果サマリ", "- 票で確認([NN]件): [No.X 観点名, …]", "- 利用者へ依頼([NN]件): [No.X 観点名, …]", "- Eng目視確認([NN]件): [No.X 観点名, …]",
        "- 要人手確認([NN]件): [No.X 観点名, …]", "- 問題なし([NN]件): [No列挙]", "- 対象外([NN]件): [No列挙(利用なし / 回答なし)]",
        "## 利用者への確認・依頼(票の指摘内容の文案)", "- [No.X(票No: Y)｜カテゴリ: サービス名｜指摘概要: 件名｜指摘内容: 文案]",
        "## 観点ごとの判定(No順。1観点1行)", *[line(c) for c in sel],
        "## 要確認", "- [無ければ「なし」]", "## 検算",
        f"- 票で確認[NN] + 利用者へ依頼[NN] + Eng目視確認[NN] + 要人手確認[NN] + 問題なし[NN] + 対象外[NN] = [NN](適用行数 {len(sel)} と一致)",
    ]
    (out / "04_draft.md").write_text("\n".join(draft) + "\n", encoding="utf-8")
    print(f"適用行数: {len(sel)}")


if __name__ == "__main__":
    main()
