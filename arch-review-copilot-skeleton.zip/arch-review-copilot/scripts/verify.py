"""04_check.md の検算: 区分ごとの件数の合計が 04_points.md の適用行数と一致するか、[ ] が残っていないかを確認する。"""
import pathlib
import re
import sys

ritm = sys.argv[1]
out = pathlib.Path("cases") / ritm / "output"
check = (out / "04_check.md").read_text(encoding="utf-8")
points = (out / "04_points.md").read_text(encoding="utf-8")
expected = int(re.search(r"適用行数: (\d+)", points).group(1))
counts = {k: int(v) for k, v in re.findall(r"- (票で確認|利用者へ依頼|Eng目視確認|要人手確認|問題なし|対象外)\((\d+)件\)", check)}
total = sum(counts.values())
blanks = re.findall(r"\[[^\]]*\]", check)
print(f"区分合計 {total} / 適用行数 {expected} → {'一致' if total == expected else '不一致'}")
print(f"未記入の [ ]: {len(blanks)}件" + (f" 例: {blanks[:3]}" if blanks else ""))
sys.exit(0 if total == expected and not blanks else 1)
