"""05_ticket.json(票の行の配列)を、テンプレート xlsx にコピーして書き込む(Copilot Studio の T4 相当)。"""
import json
import pathlib
import shutil
import sys

from openpyxl import load_workbook

COLUMNS = ["No.", "ステータス", "環境", "対応区分", "カテゴリ", "指摘概要", "指摘内容", "対応ガイドライン・参考資料"]

ritm, csp = sys.argv[1], sys.argv[2]
out = pathlib.Path("cases") / ritm / "output"
template = pathlib.Path("reference") / f"【案件名】(RITMxxxxxxx)アーキテクチャレビュー票({csp}).xlsx"
dest = out / f"【案件名】({ritm})アーキテクチャレビュー票({csp}).xlsx"
shutil.copy(template, dest)

rows = json.load(open(out / "05_ticket.json", encoding="utf-8"))
wb = load_workbook(dest)
ws = wb.active
header = {str(c.value).strip(): i + 1 for i, c in enumerate(ws[1]) if c.value}
start = ws.max_row + 1
for r_i, row in enumerate(rows):
    for key in COLUMNS:
        if key in header:
            ws.cell(row=start + r_i, column=header[key], value=row.get(key, ""))
wb.save(dest)
print(f"書き込み件数: {len(rows)} / 保存先: {dest}")
