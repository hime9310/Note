# -*- coding: utf-8 -*-
"""diagram / status 用: Teams スレッドのリンクから チーム(groupId)・チャネル ID・メッセージ ID を取り出す。

使い方: python scripts/parse_teams_link.py --url "<リンク>"
出力(JSON): {"ok": true/false, "team": ..., "channel": ..., "message": ..., "reason": ...}

リンクの例:
  https://teams.microsoft.com/l/message/19%3Aabc...%40thread.tacv2/1700000000000?tenantId=...&groupId=xxxx&parentMessageId=1700000000000&...
  返信のリンクが貼られた場合でも parentMessageId(最初の投稿の ID)を message として使う。
"""
import argparse
import os
import re
import sys
from urllib.parse import parse_qs, unquote, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump  # noqa: E402


def parse(url):
    url = url.strip().strip("<>\"'")
    out = {"ok": False, "team": "", "channel": "", "message": "", "reason": "", "url": url}
    try:
        p = urlparse(url)
        qs = {k: v[0] for k, v in parse_qs(p.query).items()}  # ?groupId=...&parentMessageId=... を辞書に
        path = unquote(p.path)                                  # %3A → : のように戻す

        # 1. パスの /l/message/<チャネルID>/<メッセージID> を読む
        m = re.search(r"/l/message/([^/]+)/(\d+)", path)
        if m:
            out["channel"], out["message"] = m.group(1), m.group(2)
        # 2. チャネル直リンク(/l/channel/<チャネルID>/...)の場合
        if not out["channel"]:
            m2 = re.search(r"/l/channel/([^/]+)/", path)
            if m2:
                out["channel"] = m2.group(1)
        # 3. チーム ID と、返信リンクなら親投稿の ID
        out["team"] = qs.get("groupId", "")
        if qs.get("parentMessageId"):
            out["message"] = qs["parentMessageId"]

        if out["team"] and out["channel"] and out["message"]:
            out["ok"] = True
        else:
            missing = [k for k in ("team", "channel", "message") if not out[k]]
            out["reason"] = "リンクから取り出せない項目: " + ", ".join(missing)
    except Exception as e:
        out["reason"] = f"解析エラー: {e}"
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    a = ap.parse_args()
    dump(parse(a.url))


if __name__ == "__main__":
    main()
