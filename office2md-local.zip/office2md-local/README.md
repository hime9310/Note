# Office → Markdown 変換キット

`input` フォルダに入れた Word / Excel / PowerPoint を Markdown に変換し、`output` フォルダに出力します。
画像は `images` フォルダに書き出され、Markdown から正しく参照されます。
変換はすべて PC の中で行われ、ファイルが外部に送信されることはありません。

---

## フォルダ構成

```
office2md-local/
├─ convert.bat        ← Windows：ダブルクリックで変換
├─ convert.command    ← Mac：ダブルクリックで変換
├─ input/             ← 変換したいファイルをここに入れる（サブフォルダも可）
├─ output/            ← 変換結果がここに出る
├─ tools/             ← 変換スクリプト本体（触らなくてOK）
└─ README.md          ← この説明
```

### 変換するとこうなります

```
input/                              output/
├─ 報告書.docx          ──▶          ├─ 報告書.md
│                                   ├─ images/
│                                   │   └─ 報告書/
│                                   │       ├─ image_001.png
│                                   │       └─ image_002.jpg
├─ 営業/                            ├─ 営業/
│   ├─ 提案資料.pptx    ──▶          │   ├─ 提案資料.md
│   └─ 売上表.xlsx      ──▶          │   ├─ 売上表.md
│                                   │   └─ images/提案資料/…, images/売上表/…
│                                   ├─ INDEX.md                 … 全ドキュメントの一覧（リンク付き）
│                                   └─ _conversion_report.csv   … 変換結果（Excel で開けます）
```

- `input` のフォルダ構成が、そのまま `output` に再現されます。
- 画像は文書ごとのフォルダ（`images/文書名/`）に入るので、文書が増えても混ざりません。

---

## 手順

### ステップ 0：準備（初回のみ）

anydoc は導入済みとのことなので、バージョンだけ確認します。コマンドプロンプトで：

```bash
python -m pip install --upgrade -r tools/requirements.txt
```

（`tools` フォルダがある場所で実行してください。0.2.4 以上が必要です）

### ステップ 1：まず 1 ファイルで試す

1. `input` フォルダに Word ファイルを **1 つだけ** 入れる
2. `convert.bat` をダブルクリック
3. 黒い画面に次のように出れば成功です

   ```
   対象 1 件 / 変換 1 件 / 変更なしスキップ 0 件
   [1/1] OK 報告書.docx

   === 結果 ===
   変換成功 1 / 変更なしスキップ 0 / 失敗 0
   ```

4. `output` フォルダを開いて確認
   - `報告書.md` を **VS Code** で開き、`Ctrl + Shift + V` でプレビュー
     （VS Code が無ければ、メモ帳でも中身は読めます）
   - 見出し・表・リンク・画像が元のファイルと合っているか見比べる

### ステップ 2：ファイルを増やす

1. `input` に Word / Excel / PowerPoint を追加（フォルダごと入れても OK）
2. もう一度 `convert.bat` をダブルクリック
3. **新しく入れたファイルと、内容が変わったファイルだけ**が変換されます
   （変換済みで変更がないファイルは「変更なしスキップ」になります）
4. `output/_conversion_report.csv` を Excel で開き、`status` 列を確認

| status | 意味 |
| --- | --- |
| `ok` | 変換成功 |
| `skipped` | 前回から変更がないのでスキップ |
| `password` | パスワード付きのため対象外（変換しません） |
| `error` | 変換失敗（`error` 列に理由） |
| `orphan` | `input` から元ファイルが無くなった（出力は残っています） |

### ステップ 3：GitHub に載せる

GitHub に載せるのは **`output` フォルダの中身だけ** です（原本は入れません）。
`INDEX.md` がトップの一覧ページになります。

---

## 対応形式

| 種類 | 拡張子 | 画像 |
| --- | --- | --- |
| Word | .docx .docm | 元の位置に表示 |
| Excel | .xlsx .xlsm | 各シートの表の下に「（セル D2）」のように位置付きで表示 |
| PowerPoint | .pptx .pptm | 各スライドの元の位置に表示（ノートも出力） |
| 旧形式 | .doc .xls .ppt .xlsb .rtf | LibreOffice が入っていれば画像込みで変換、無ければ文字のみ |

> 旧形式の画像も必要な場合は、[LibreOffice](https://ja.libreoffice.org/) をインストールしてください（自動で使われます）。

---

## よくある質問

**Q. 変換をやり直したい**
`output` の中身を全部消してから `convert.bat` を実行するか、コマンドプロンプトで次を実行します。

```bash
python tools/batch_convert.py --force
```

**Q. `input` から消したファイルの出力も消したい**

```bash
python tools/batch_convert.py --prune
```

**Q. 共有フォルダから直接変換したい**（`input` にコピーしなくてよい）

```bash
python tools/batch_convert.py "\\fileserver\共有\文書" output
```

**Q. 同じフォルダに「提案書.docx」と「提案書.xlsx」がある**
`提案書.docx.md` と `提案書.xlsx.md` のように拡張子を残して区別されます。

---

## 変換できないもの・注意点

- Excel / PowerPoint の **グラフ・図形・SmartArt** は画像ではないため出力されません（図形内の文字は出る場合があります）
- **EMF / WMF 形式**の画像は保存されますが、ブラウザ（GitHub）では表示されません
- 行数の多い Excel は非常に長い表になります
- `output` 内の `.office2md-manifest.json` は差分変換の記録です。消すと次回は全件変換になります
