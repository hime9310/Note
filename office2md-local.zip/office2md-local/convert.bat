@echo off
rem ------------------------------------------------------------
rem  Double-click: convert files in input\ to Markdown in output\
rem ------------------------------------------------------------
chcp 65001 > nul
set PYTHONUTF8=1
cd /d "%~dp0"

set PY=
python -c "import anydoc" >nul 2>nul && set PY=python
if not defined PY py -c "import anydoc" >nul 2>nul && set PY=py
if not defined PY (
  echo [ERROR] Python with anydoc was not found.
  echo Run this command, then try again:
  echo   python -m pip install -r tools\requirements.txt
  echo.
  pause
  exit /b 1
)

%PY% tools\batch_convert.py %*
echo.
pause
