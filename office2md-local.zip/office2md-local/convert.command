#!/bin/bash
# Mac 用: ダブルクリックで input/ のファイルを output/ に Markdown 変換
cd "$(dirname "$0")" || exit 1
python3 tools/batch_convert.py "$@"
echo
read -r -p "Enter キーで閉じます..."
