#!/usr/bin/env python3
"""
batch_convert.py — フォルダ内の Word / Excel / PowerPoint をまとめて Markdown に変換する（office2md.py を使用）

    python batch_convert.py [元フォルダ] [出力フォルダ] [オプション]
    （省略時は このキットの input/ → output/）

例:
    python batch_convert.py
    python batch_convert.py //fileserver/共有/文書 ./docs --workers 8 --prune

出力イメージ（フォルダ構成はそのまま再現）:
    元フォルダ/営業/週報.docx        →  出力/営業/週報.md
                                         出力/営業/images/週報/image_001.png
    元フォルダ/経理/予算.xlsx        →  出力/経理/予算.md
                                         出力/経理/images/予算/image_001.png
    出力/INDEX.md                     … 全ドキュメントへのリンク一覧
    出力/_conversion_report.csv       … 1 ファイル 1 行の変換結果（Excel で開けます）

主な機能:
    ・差分変換 … 前回から中身が変わっていないファイルはスキップ（--force で全件やり直し）
    ・並列処理 … --workers で同時変換数を指定（既定: CPU 数）
    ・旧形式   … .doc / .xls / .xlsb / .ppt / .rtf は LibreOffice があれば新形式に変換してから処理。
                 無ければ anydoc で文字だけ変換（画像は出力されない）し、レポートに注記
    ・パスワード付き … 変換せず「password（対象外）」としてレポートに記録
    ・--prune  … 元ファイルが消えた/移動した Markdown と画像を出力から削除
    ・失敗しても止まらず、理由をレポートに残す（破損ファイルなど）
"""

import argparse
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

import anydoc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import office2md  # noqa: E402

NEW_FORMATS = set(office2md.SUPPORTED)
LEGACY_FORMATS = {".doc": "docx", ".rtf": "docx", ".xls": "xlsx", ".xlsb": "xlsx", ".ppt": "pptx"}
KIT_ROOT = Path(__file__).resolve().parent.parent
ALL_FORMATS = NEW_FORMATS | set(LEGACY_FORMATS)

MANIFEST = ".office2md-manifest.json"
REPORT = "_conversion_report.csv"
INDEX = "INDEX.md"
SKIP_DIRS = {".git", "__pycache__", "node_modules"}


# ------------------------------------------------------------------ 収集
def find_sources(src_root: Path) -> list[Path]:
    files = []
    for dirpath, dirnames, filenames in os.walk(src_root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(filenames):
            if name.startswith("~$") or name.startswith("."):  # Office の一時ファイル等
                continue
            if Path(name).suffix.lower() in ALL_FORMATS:
                files.append(Path(dirpath) / name)
    return files


def plan_outputs(src_root: Path, sources: list[Path]) -> dict[Path, tuple[str, str]]:
    """元ファイル → (出力 .md の相対パス, 画像フォルダの相対パス)。
    同じフォルダに「報告書.docx」と「報告書.xlsx」がある場合は拡張子を残して衝突を避ける。"""
    stems: dict[tuple[Path, str], int] = {}
    for s in sources:
        key = (s.parent, s.stem.lower())
        stems[key] = stems.get(key, 0) + 1
    plan = {}
    for s in sources:
        rel_dir = s.parent.relative_to(src_root)
        base = s.stem if stems[(s.parent, s.stem.lower())] == 1 else s.name
        md_rel = (rel_dir / f"{base}.md").as_posix()
        img_rel = (rel_dir / "images" / base).as_posix()
        plan[s] = (md_rel, img_rel)
    return plan


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------ LibreOffice
def find_soffice(explicit: str | None) -> str | None:
    if explicit:
        return explicit
    for name in ("soffice", "libreoffice"):
        p = shutil.which(name)
        if p:
            return p
    for p in (
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
    ):
        if Path(p).exists():
            return p
    return None


def legacy_to_new(soffice: str, src: Path, target_ext: str) -> bytes:
    """LibreOffice で .doc→.docx / .xls→.xlsx に変換したバイト列を返す（元ファイルは変更しない）"""
    with tempfile.TemporaryDirectory() as tmp:
        profile = Path(tmp, "profile").as_uri()  # 並列実行時にプロファイルが衝突しないよう個別に用意
        cmd = [soffice, f"-env:UserInstallation={profile}", "--headless",
               "--convert-to", target_ext, "--outdir", tmp, str(src)]
        subprocess.run(cmd, check=True, capture_output=True, timeout=300)
        out = Path(tmp, f"{src.stem}.{target_ext}")
        if not out.exists():
            raise RuntimeError("LibreOffice での変換に失敗しました")
        return out.read_bytes()


# ------------------------------------------------------------------ 1 ファイル分の処理（別プロセスで実行）
def convert_one(job: dict) -> dict:
    src = Path(job["src"])
    out_root = Path(job["out_root"])
    md_rel, img_rel = job["md_rel"], job["img_rel"]
    md_path = out_root / md_rel
    started = time.time()
    row = {"source": job["src_rel"], "markdown": md_rel, "status": "ok", "images": 0,
           "warnings": "", "error": "", "seconds": 0.0, "sha256": job["sha256"]}
    try:
        # 前回の画像を消してから作り直す（画像が減った場合に古いものが残らないように）
        shutil.rmtree(out_root / img_rel, ignore_errors=True)
        md_path.parent.mkdir(parents=True, exist_ok=True)
        img_from_md = Path(os.path.relpath(out_root / img_rel, md_path.parent)).as_posix()
        warnings = []

        ext = src.suffix.lower()
        if ext in NEW_FORMATS:
            r = office2md.convert(src, md_path.parent, img_from_md, md_path.name)
        elif job["soffice"]:
            # パスワード付きなら LibreOffice に渡す前にここで EncryptedError になる
            anydoc.to_markdown(src)
            target = LEGACY_FORMATS[ext]
            data = legacy_to_new(job["soffice"], src, target)
            r = office2md.convert(src, md_path.parent, img_from_md, md_path.name, data=data, suffix="." + target)
            warnings.append(f"旧形式({ext})を LibreOffice で .{target} に変換して処理")
        else:
            md_path.write_text(anydoc.to_markdown(src), encoding="utf-8")
            r = {"images": 0, "warnings": []}
            warnings.append(f"旧形式({ext}): LibreOffice が無いため文字のみ変換（画像なし）")

        # 元ファイルの情報を Markdown 先頭にコメントで残す（GitHub 上では表示されない）
        note = f"<!-- source: {job['src_rel']} | converted: {job['now']} -->\n\n"
        md_path.write_text(note + md_path.read_text(encoding="utf-8"), encoding="utf-8")

        row["images"] = r["images"]
        row["warnings"] = " / ".join(warnings + r["warnings"])
    except Exception as e:  # パスワード付き・破損など。止めずに記録して次へ
        if isinstance(e, anydoc.EncryptedError):
            row["status"] = "password"
            row["warnings"] = "パスワード付きのため対象外"
        else:
            row["status"] = "error"
            row["error"] = f"{type(e).__name__}: {e}".strip()[:500]
        md_path.unlink(missing_ok=True)
        shutil.rmtree(out_root / img_rel, ignore_errors=True)
    row["seconds"] = round(time.time() - started, 2)
    return row


# ------------------------------------------------------------------ 索引
def write_index(out_root: Path, manifest: dict) -> None:
    by_dir: dict[str, list[tuple[str, str]]] = {}
    for src_rel, info in manifest.items():
        if info.get("status") != "ok":
            continue
        md_rel = info["markdown"]
        folder = str(Path(md_rel).parent.as_posix())
        by_dir.setdefault(folder, []).append((Path(src_rel).name, md_rel))
    lines = ["# ドキュメント一覧", "",
             f"自動生成: {datetime.now():%Y-%m-%d %H:%M}　/　{sum(len(v) for v in by_dir.values())} 件", ""]
    for folder in sorted(by_dir):
        lines.append(f"## {'（ルート）' if folder == '.' else folder}")
        lines.append("")
        for name, md_rel in sorted(by_dir[folder]):
            lines.append(f"- [{office2md.md_alt(name)}]({office2md.md_path_for_link(md_rel)})")
        lines.append("")
    (out_root / INDEX).write_text("\n".join(lines), encoding="utf-8")


# ------------------------------------------------------------------ メイン
def main() -> None:
    p = argparse.ArgumentParser(description="フォルダ内の Word/Excel/PowerPoint を一括で Markdown に変換")
    p.add_argument("src", type=Path, nargs="?", default=KIT_ROOT / "input",
                   help="元ファイルのフォルダ（既定: キットの input/）")
    p.add_argument("out", type=Path, nargs="?", default=KIT_ROOT / "output",
                   help="Markdown の出力先フォルダ（既定: キットの output/）")
    p.add_argument("--workers", type=int, default=os.cpu_count() or 4, help="同時に変換する数")
    p.add_argument("--force", action="store_true", help="変更が無いファイルも含めて全部変換し直す")
    p.add_argument("--prune", action="store_true", help="元ファイルが無くなった出力を削除する")
    p.add_argument("--soffice", help="LibreOffice の soffice のパス（自動検出できない場合）")
    p.add_argument("--no-legacy", action="store_true", help=".doc/.xls など旧形式を対象外にする")
    p.add_argument("--no-index", action="store_true", help="INDEX.md を作らない")
    p.add_argument("--fail-on-error", action="store_true", help="1 件でも失敗したら終了コード 1 を返す")
    a = p.parse_args()

    if not hasattr(anydoc, "to_document"):
        sys.exit("anydoc が古いバージョンです。次のコマンドで更新してください:\n"
                 '  python -m pip install --upgrade "firecrawl-anydoc>=0.2.4,<0.3"')

    src_root, out_root = a.src.resolve(), a.out.resolve()
    if not src_root.is_dir():
        sys.exit(f"元フォルダが見つかりません: {src_root}")
    print(f"入力: {src_root}\n出力: {out_root}")
    if out_root == src_root or src_root in out_root.parents:
        print("注意: 出力先が元フォルダの中にあります。生成物は変換対象になりませんが、別フォルダを推奨します。")
    out_root.mkdir(parents=True, exist_ok=True)

    manifest_path = out_root / MANIFEST
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}

    sources = [s for s in find_sources(src_root) if out_root not in s.parents]
    if a.no_legacy:
        sources = [s for s in sources if s.suffix.lower() in NEW_FORMATS]
    plan = plan_outputs(src_root, sources)
    if not sources:
        print(f"\n変換するファイルがありません。{src_root} に Word / Excel / PowerPoint を入れてください。")
        return

    soffice = None
    if not a.no_legacy and any(s.suffix.lower() in LEGACY_FORMATS for s in sources):
        soffice = find_soffice(a.soffice)
        print(f"LibreOffice: {soffice or '見つかりません（旧形式は文字のみ変換します）'}")

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    jobs, rows = [], []
    for s in sources:
        src_rel = s.relative_to(src_root).as_posix()
        md_rel, img_rel = plan[s]
        digest = sha256(s)
        prev = manifest.get(src_rel)
        if (not a.force and prev and prev.get("sha256") == digest and prev.get("status") == "ok"
                and prev.get("markdown") == md_rel and (out_root / md_rel).exists()):
            rows.append({**prev, "source": src_rel, "status": "skipped"})
            continue
        jobs.append({"src": str(s), "src_rel": src_rel, "out_root": str(out_root), "md_rel": md_rel,
                     "img_rel": img_rel, "sha256": digest, "soffice": soffice, "now": now})

    print(f"対象 {len(sources)} 件 / 変換 {len(jobs)} 件 / 変更なしスキップ {len(sources) - len(jobs)} 件")

    done = 0
    with ProcessPoolExecutor(max_workers=max(1, a.workers)) as pool:
        futures = [pool.submit(convert_one, j) for j in jobs]
        for f in as_completed(futures):
            row = f.result()
            rows.append(row)
            done += 1
            mark = {"ok": "OK ", "password": "対象外(パスワード) "}.get(row["status"], "NG ")
            print(f"[{done}/{len(jobs)}] {mark}{row['source']}" + (f"  … {row['error']}" if row["error"] else ""))
            manifest[row["source"]] = {k: row[k] for k in ("sha256", "markdown", "status", "images", "warnings", "error")}
            manifest[row["source"]]["image_dir"] = plan[src_root / row["source"]][1]

    # 元ファイルが無くなったもの
    current = {s.relative_to(src_root).as_posix() for s in sources}
    gone = [k for k in manifest if k not in current]
    for k in gone:
        if a.prune:
            info = manifest.pop(k)
            (out_root / info["markdown"]).unlink(missing_ok=True)
            if info.get("image_dir"):
                shutil.rmtree(out_root / info["image_dir"], ignore_errors=True)
            rows.append({"source": k, "markdown": info["markdown"], "status": "removed"})
        else:
            rows.append({"source": k, "markdown": manifest[k]["markdown"], "status": "orphan",
                         "warnings": "元ファイルが見つかりません（--prune で削除）"})

    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=1, sort_keys=True), encoding="utf-8")

    cols = ["source", "markdown", "status", "images", "warnings", "error", "seconds"]
    with open(out_root / REPORT, "w", encoding="utf-8-sig", newline="") as f:  # utf-8-sig: Excel で文字化けしない
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in sorted(rows, key=lambda r: r["source"]):
            w.writerow(r)

    if not a.no_index:
        write_index(out_root, manifest)

    count = {s: sum(1 for r in rows if r["status"] == s)
             for s in ("ok", "skipped", "error", "password", "orphan", "removed")}
    print("\n=== 結果 ===")
    print(f"変換成功 {count['ok']} / 変更なしスキップ {count['skipped']} / 失敗 {count['error']}"
          + (f" / パスワード付き(対象外) {count['password']}" if count["password"] else "")
          + (f" / 元ファイル無し {count['orphan']}" if count["orphan"] else "")
          + (f" / 削除 {count['removed']}" if count["removed"] else ""))
    print(f"レポート: {out_root / REPORT}")
    sys.exit(1 if (a.fail_on_error and count["error"]) else 0)


if __name__ == "__main__":
    main()
