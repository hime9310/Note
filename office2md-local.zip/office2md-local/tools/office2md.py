#!/usr/bin/env python3
"""
office2md.py — Word / Excel / PowerPoint を anydoc で Markdown に変換し、
埋め込み画像を images/ フォルダに書き出して、Markdown から正しく参照させる。

使い方:
    pip install firecrawl-anydoc
    python office2md.py report.docx                # → report/report.md + report/images/
    python office2md.py report.docx -o out_dir     # 出力先を指定
    python office2md.py book.xlsx --images-dir img # 画像フォルダ名を変更

対応: .docx .docm .xlsx .xlsm .pptx .pptm（Office Open XML 形式）
      ※ 旧形式 .doc / .xls / .ppt は batch_convert.py が LibreOffice で新形式にしてから渡します。

仕組み:
    anydoc は埋め込み画像を「代替テキスト」として Markdown に出すだけなので、
    1) 変換前に、各画像の代替テキストを一意の目印 (ANYDOCIMG0001X など) に書き換えた一時コピーを作る
    2) anydoc で Markdown と文書モデル(画像データ入り)を取得
    3) 目印 → 画像データ を対応付けて images/ に保存
    4) Markdown 内の目印を ![元の代替テキスト](images/xxx.png) に置換
    元ファイルは一切変更しません。
"""

import argparse
import html
import io
import re
import sys
import zipfile
from pathlib import Path

import anydoc

PLACEHOLDER = "ANYDOCIMG{:04d}X"
PLACEHOLDER_RE = re.compile(r"ANYDOCIMG(\d{4})X")

# 画像の代替テキストを持つ XML 要素
#   Word : <wp:docPr ... descr="...">
#   Excel: <xdr:cNvPr ... descr="...">
TAG_RE = re.compile(rb"<(wp:docPr|xdr:cNvPr)\b[^>]*?/?>")
#   PowerPoint: <p:pic><p:nvPicPr><p:cNvPr ... descr="...">
PPT_PIC_RE = re.compile(rb"(<p:nvPicPr>\s*)(<p:cNvPr\b[^>]*?/?>)")
DESCR_RE = re.compile(rb'\sdescr="([^"]*)"')

EXT_BY_MEDIA = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/bmp": ".bmp",
    "image/tiff": ".tif",
    "image/svg+xml": ".svg",
    "image/webp": ".webp",
    "image/x-emf": ".emf",
    "image/emf": ".emf",
    "image/x-wmf": ".wmf",
    "image/wmf": ".wmf",
}


def tag_images(data: bytes) -> tuple[bytes, dict[str, str]]:
    """全画像の代替テキストを目印に置き換えたコピーを返す。{目印: 元の代替テキスト}"""
    originals: dict[str, str] = {}
    counter = 0

    def replace(m: re.Match) -> bytes:
        return retag(m.group(0))

    def retag(tag: bytes) -> bytes:
        nonlocal counter
        counter += 1
        key = PLACEHOLDER.format(counter)
        old = DESCR_RE.search(tag)
        originals[key] = html.unescape(old.group(1).decode("utf-8")) if old else ""
        tag = DESCR_RE.sub(b"", tag)
        closing = b"/>" if tag.endswith(b"/>") else b">"
        body = tag[: -len(closing)].rstrip()
        return body + f' descr="{key}"'.encode() + closing

    def replace_ppt(m: re.Match) -> bytes:
        # PowerPoint はタイトルやテキストボックスにも cNvPr があるため、画像(p:pic)のものだけ書き換える
        return m.group(1) + retag(m.group(2))

    src = zipfile.ZipFile(io.BytesIO(data))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            content = src.read(info.filename)
            name = info.filename
            if name.endswith(".xml"):
                # 本文・ヘッダー/フッター・脚注(Word) と 描画パーツ(Excel)
                if name.startswith("word/") or name.startswith("xl/drawings/"):
                    content = TAG_RE.sub(replace, content)
                # スライド(PowerPoint)
                elif name.startswith("ppt/slides/"):
                    content = PPT_PIC_RE.sub(replace_ppt, content)
            dst.writestr(info, content)
    return buf.getvalue(), originals


def collect_images(doc) -> dict[str, int]:
    """文書モデルを走査して {目印: asset_id} を作る（表・リスト・引用・脚注の中も含む）"""
    found: dict[str, int] = {}

    def inlines(items):
        for il in items or []:
            if il.kind == "image" and il.source and il.source.kind == "asset":
                m = PLACEHOLDER_RE.search(il.alt or "")
                if m:
                    found[m.group(0)] = il.source.asset_id
            inlines(il.content)  # リンクの中の画像

    def blocks(items):
        for b in items or []:
            inlines(b.content)
            blocks(b.blocks)
            if b.list:
                for item in b.list.items:
                    blocks(item.blocks)
            if b.table:
                for row in b.table.grid:
                    for slot in row:
                        if slot.cell:
                            blocks(slot.cell.blocks)

    blocks(doc.blocks)
    for note in doc.notes or []:
        blocks(note.blocks)
    return found


def excel_images(data: bytes) -> list[tuple[str, str, str, bytes, str]]:
    """Excel のシート上に置かれた画像を直接取り出す。
    anydoc はセル外に浮いている画像を文書モデルに含めないため、こちらで補う。
    戻り値: [(シート名, 左上セル, 代替テキスト, 画像データ, 拡張子)]"""
    import posixpath
    import xml.etree.ElementTree as ET

    NS = {
        "m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
        "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
        "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    }
    z = zipfile.ZipFile(io.BytesIO(data))
    names = set(z.namelist())

    def rels(part: str) -> dict[str, str]:
        d, f = posixpath.split(part)
        path = posixpath.join(d, "_rels", f + ".rels")
        if path not in names:
            return {}
        out = {}
        for r in ET.fromstring(z.read(path)).findall("rel:Relationship", NS):
            if r.get("TargetMode") == "External":
                continue
            target = r.get("Target", "")
            full = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(d, target))
            out[r.get("Id")] = full
        return out

    def col_name(i: int) -> str:
        s = ""
        i += 1
        while i:
            i, r = divmod(i - 1, 26)
            s = chr(65 + r) + s
        return s

    results = []
    wb_rels = rels("xl/workbook.xml")
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    for sh in wb.findall("m:sheets/m:sheet", NS):
        sheet_name = sh.get("name")
        sheet_part = wb_rels.get(sh.get(f"{{{NS['r']}}}id"))
        if not sheet_part or sheet_part not in names:
            continue
        sheet_rels = rels(sheet_part)
        for dr in ET.fromstring(z.read(sheet_part)).findall("m:drawing", NS):
            drawing_part = sheet_rels.get(dr.get(f"{{{NS['r']}}}id"))
            if not drawing_part or drawing_part not in names:
                continue
            d_rels = rels(drawing_part)
            root = ET.fromstring(z.read(drawing_part))
            anchors = [e for e in root if e.tag.split("}")[1] in ("twoCellAnchor", "oneCellAnchor", "absoluteAnchor")]
            for anc in anchors:
                frm = anc.find("xdr:from", NS)
                cell = ""
                if frm is not None:
                    c = int(frm.findtext("xdr:col", "0", NS))
                    r = int(frm.findtext("xdr:row", "0", NS))
                    cell = f"{col_name(c)}{r + 1}"
                for pic in anc.iter(f"{{{NS['xdr']}}}pic"):
                    blip = pic.find(".//a:blip", NS)
                    media = d_rels.get(blip.get(f"{{{NS['r']}}}embed")) if blip is not None else None
                    if not media or media not in names:
                        continue
                    nv = pic.find("xdr:nvPicPr/xdr:cNvPr", NS)
                    alt = (nv.get("descr") or "") if nv is not None else ""
                    if PLACEHOLDER_RE.fullmatch(alt):
                        alt = ""
                    ext = posixpath.splitext(media)[1].lower().replace(".jpeg", ".jpg") or ".bin"
                    results.append((sheet_name, cell, alt, z.read(media), ext))
    return results


def insert_after_sheet(markdown: str, sheet: str, block: str) -> str:
    """'## シート名' セクションの末尾にブロックを差し込む。見つからなければ末尾に追加。"""
    lines = markdown.split("\n")
    start = next((i for i, l in enumerate(lines) if re.fullmatch(r"#{1,6}\s+" + re.escape(sheet) + r"\s*", l)), None)
    if start is None:
        return markdown.rstrip("\n") + f"\n\n## {sheet}（画像）\n\n{block}\n"
    level = len(lines[start]) - len(lines[start].lstrip("#"))
    end = len(lines)
    for i in range(start + 1, len(lines)):
        m = re.match(r"(#{1,6})\s", lines[i])
        if m and len(m.group(1)) <= level:
            end = i
            break
    while end > start + 1 and lines[end - 1].strip() == "":
        end -= 1
    lines[end:end] = ["", block]
    return "\n".join(lines)


def md_alt(text: str) -> str:
    return text.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]").replace("\n", " ").strip()


def md_path_for_link(path: str) -> str:
    """Markdown のリンク先として安全な形にする（空白・括弧を含む場合は <...> で囲む）"""
    path = path.replace("\\", "/")
    if re.search(r"[\s()<>]", path):
        return "<" + path.replace("<", "%3C").replace(">", "%3E") + ">"
    return path


SUPPORTED = {".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"}


def convert(
    src: Path,
    out_dir: Path,
    images_dir_name: str = "images",
    md_name: str | None = None,
    data: bytes | None = None,
    suffix: str | None = None,
) -> dict:
    """1 ファイルを変換する。

    src             : 元ファイル（名前と拡張子の判定に使う）
    out_dir         : Markdown を置くフォルダ
    images_dir_name : out_dir からの画像フォルダの相対パス（"images/報告書" のように階層も可）
    md_name         : 出力する .md のファイル名（既定: 元ファイル名.md）
    data / suffix   : 事前に新形式へ変換したバイト列を渡す場合（.doc→.docx など）
    戻り値          : {"markdown": Path, "images": 枚数, "warnings": [...]}
    """
    suffix = (suffix or src.suffix).lower()
    if suffix not in SUPPORTED:
        raise ValueError(f"未対応の形式です: {suffix}（{' '.join(sorted(SUPPORTED))} に対応）")
    if data is None:
        data = src.read_bytes()
    if not zipfile.is_zipfile(io.BytesIO(data)):
        # パスワード付きの Office ファイルは ZIP ではなく暗号化コンテナになっている。
        # anydoc に判定させると EncryptedError / MalformedError などの正しい理由が分かる
        anydoc.to_markdown_bytes(data, anydoc.format_from_extension(suffix))
        raise ValueError("ファイルが壊れているか、拡張子と中身の形式が違います")

    tagged, originals = tag_images(data)
    markdown = anydoc.to_markdown_bytes(tagged)
    doc = anydoc.to_document(tagged)
    key_to_asset = collect_images(doc)

    out_dir.mkdir(parents=True, exist_ok=True)
    img_dir = out_dir / images_dir_name
    asset_to_file: dict[int, str] = {}
    unknown_formats = set()

    def file_for(asset_id: int) -> str:
        # 同じ画像が何度出てきても 1 ファイルだけ保存する
        if asset_id not in asset_to_file:
            asset = doc.assets[asset_id]
            ext = EXT_BY_MEDIA.get(asset.media_type) or Path(asset.origin_part).suffix or ".bin"
            if ext in {".emf", ".wmf", ".tif", ".bin"}:
                unknown_formats.add(ext)
            img_dir.mkdir(parents=True, exist_ok=True)
            name = f"image_{len(asset_to_file) + 1:03d}{ext}"
            (img_dir / name).write_bytes(asset.data)
            asset_to_file[asset_id] = md_path_for_link(f"{images_dir_name}/{name}")
        return asset_to_file[asset_id]

    missing = []

    def replace(m: re.Match) -> str:
        key = m.group(0)
        if key not in key_to_asset:
            missing.append(key)
            return md_alt(originals.get(key, ""))
        alt = md_alt(originals.get(key, "")) or f"image {int(m.group(1))}"
        return f"![{alt}]({file_for(key_to_asset[key])})"

    markdown = PLACEHOLDER_RE.sub(replace, markdown)

    # Excel: anydoc がシート上の画像を拾わない場合は、ファイルから直接取り出して
    # 各シートのセクション末尾に「セル位置付き」で差し込む
    excel_count = 0
    if suffix in {".xlsx", ".xlsm"} and not asset_to_file:
        import hashlib

        saved: dict[str, str] = {}
        per_sheet: dict[str, list[str]] = {}
        for sheet, cell, alt, img, ext in excel_images(data):
            digest = hashlib.sha1(img).hexdigest()
            if digest not in saved:
                img_dir.mkdir(parents=True, exist_ok=True)
                name = f"image_{len(saved) + 1:03d}{ext}"
                (img_dir / name).write_bytes(img)
                saved[digest] = md_path_for_link(f"{images_dir_name}/{name}")
                if ext in {".emf", ".wmf", ".tif"}:
                    unknown_formats.add(ext)
            excel_count += 1
            label = md_alt(alt) or f"{sheet} {cell}".strip()
            where = f"（セル {cell}）" if cell else ""
            per_sheet.setdefault(sheet, []).append(f"![{label}]({saved[digest]}){where}")
        for sheet, items in per_sheet.items():
            markdown = insert_after_sheet(markdown, sheet, "\n\n".join(items))
        asset_to_file = {i: v for i, v in enumerate(saved.values())}
        missing = []

    md_path = out_dir / (md_name or f"{src.stem}.md")
    md_path.write_text(markdown, encoding="utf-8")

    warnings = []
    if missing:
        warnings.append(f"画像データを特定できなかった箇所が {len(missing)} 件（図形やグラフの可能性）")
    if unknown_formats:
        warnings.append(f"{'/'.join(sorted(unknown_formats))} 形式の画像はブラウザで表示できない場合あり")
    return {"markdown": md_path, "images": len(asset_to_file), "image_dir": img_dir, "warnings": warnings}


def main() -> None:
    p = argparse.ArgumentParser(description="Word/Excel → Markdown + images フォルダ（anydoc 使用）")
    p.add_argument("input", type=Path, help="変換する .docx / .xlsx ファイル")
    p.add_argument("-o", "--out", type=Path, help="出力フォルダ（既定: 入力ファイル名のフォルダ）")
    p.add_argument("--images-dir", default="images", help="画像フォルダ名（既定: images）")
    a = p.parse_args()
    out = a.out or a.input.with_suffix("")
    try:
        r = convert(a.input, out, a.images_dir)
    except ValueError as e:
        sys.exit(str(e))
    print(f"Markdown : {r['markdown']}")
    print(f"画像     : {r['images']} 枚 → {r['image_dir'] if r['images'] else '(なし)'}")
    for w in r["warnings"]:
        print(f"注意     : {w}")


if __name__ == "__main__":
    main()
